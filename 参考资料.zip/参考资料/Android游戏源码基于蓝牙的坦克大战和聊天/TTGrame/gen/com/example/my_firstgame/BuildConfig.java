/** Automatically generated file. DO NOT MODIFY */
package com.example.my_firstgame;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}