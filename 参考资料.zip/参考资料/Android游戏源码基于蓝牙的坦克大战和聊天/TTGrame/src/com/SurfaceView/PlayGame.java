package com.SurfaceView;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import com.Thread.Bullet_go;
import com.Thread.Listener_bluetooth;
import com.Thread.Normal_tank_go;
import com.Thread.Time_thread;
import com.Thread.chage_Info_thread_recive;
import com.Thread.chage_Info_thread_send;
import com.Thread.change_face;
import com.Thread.hero_Tank_Go;
import com.entity.Boundary;
import com.entity.Bullet;
import com.entity.Deal_Bluetooth_Info;
import com.entity.Draw_Enemy;
import com.entity.Herotank;
import com.entity.NormalTank;
import com.entity.reward;
import com.example.my_firstgame.*;
import com.tools.Constant;

public class PlayGame extends SurfaceView implements SurfaceHolder.Callback {

	private static int count  = 0 ;
	private long time = 0;//���������˳�
	private SurfaceHolder holder ;
    private 	Paint paint ;
 	private Boundary face = null ;
 	private Herotank  herotank = null;
 	private hero_Tank_Go hero_go_thread = null;
	private NormalTank tank1 = null,tank2= null;
	private  change_face change ; 
	private Time_thread time_thread;
	private reward reward_send ;
	//�ӵ��ߵ��̶߳���
	private Bullet_go bullet_go_hero,bullet_go_normal1 , bullet_go_normal2 ;
	//�ӵ�����
	private Bullet hero_bullet , normal_bullet1,normal_bullet2;
	private Normal_tank_go tank1_thread = null, tank2_thread = null;
	public static Bitmap  Number  [] ;
	private Boundary boundary;
	private float  getupx,getupy  ,getdownx ,getdowny,getmovex,getmovey;
	public boolean can_start = false;
	private int flag_d,flag_u,flag;
	private Draw_Enemy draw_enemy ;
	private Deal_Bluetooth_Info deal_blue ;
	private chage_Info_thread_send change_info;
	private chage_Info_thread_recive get_change_info;
	
	private Object o = new Object();
	
	public static Bitmap home;
	  //�ӵ�����
	public static  Bitmap   NormalBullet;
	  public static Bitmap HeroBullet;
	  // Ӣ��̹��ͼƬ�ļ���
	  public static Bitmap[] HeroTank_1;
	  public static Bitmap[] HeroTank_2;
	  public static Bitmap[] HeroTank_3;
	  public static Bitmap[] HeroTank_4;
	  public static Bitmap temp;
	  //�ϰ������
	   public static Bitmap grass;
	   public static Bitmap ice;
	   public static Bitmap stone;
	   public static Bitmap brick;
	   public static Bitmap sea;
	   public static Bitmap protect;
	  //��̹ͨ�˵ļ���
	   public static Bitmap [] AttackTank ;
	   public static Bitmap [] FastTank   ;
	   public static Bitmap [] StrongTank ;
	   public static Bitmap [] redAttackTank  ;
	   public  static Bitmap [] redFastTank   ; 
	   public static Bitmap [] redStrongTank  ; 
	  //���������
	   public  static Bitmap [] reward   ;
	 
	  //��ť����
	   public static Bitmap herotankStopbutton ;
	   public static Bitmap killallenemybutton;
      //��ըЧ��
	   public  static Bitmap explode [];
      
      //��װը��
	   public static Bitmap bomb;
	  private boolean hero_shoot = false ;
	
	
	public PlayGame(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
		this.setFocusableInTouchMode(true);
		holder = this.getHolder();  
        holder.addCallback(this);
	}

	@Override 
	public void onDraw(Canvas canvas){
		super.onDraw(canvas);
		
		canvas.drawColor(Color.argb(255, 0, 0, 0));
		
		face.DrawslefBelow(canvas,paint);
		
	    herotank.Drawself(canvas, paint);
		tank1.Drawself(canvas,paint);
		tank2.Drawself(canvas,paint);
		
		Cancel_all_bir_place();
		//��Ļ����  �����ӵ�
			hero_bullet.Drawself(canvas,paint);
		
		
	
			if(Constant.Random(150) == 0){
				normal_bullet1.shoot();
				normal_bullet1.Drawself(canvas, paint);			
		    }
		
		else{//����Ѿ������ˡ����ͼ�������
			normal_bullet1.Drawself(canvas, paint);	
		}
		
		//if(!normal_bullet2.flying&&!normal_bullet2.flying2 ){
			if(Constant.Random(200) == 0){
				normal_bullet2.shoot();
				normal_bullet2.Drawself(canvas, paint);			
				
		   }
			else{
				normal_bullet2.Drawself(canvas, paint);	
			}

		
	//	draw_enemy.Drawself(canvas, paint);//���з�

		
		face.DrawselfAbove(canvas, paint);
		reward_send.Drawself(canvas, paint);
	}
	
	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
	    initBitmap();    //����ͼƬ
	   // time_thread = new Time_thread();
	  //  time_thread.start();
	    
		paint = new Paint();
		paint.setAntiAlias(true);
		paint.setColor(Color.WHITE);
		
		face = new Boundary();   //���ý��溯��
		herotank = new Herotank(face);
		hero_go_thread = new hero_Tank_Go(herotank);
		hero_go_thread.start();
		tank1 = new NormalTank(1,face);//����1�Ǹ�̹�˱��
		tank1_thread = new Normal_tank_go(tank1);
		tank1_thread.start();
		tank2 = new NormalTank(2,face);
		tank2_thread = new Normal_tank_go(tank2);
		tank2_thread.start();
		change = new change_face(this,holder);
		
		Cancel_all_bir_place();
	    hero_bullet = new Bullet(herotank,face);
		bullet_go_hero = new Bullet_go(hero_bullet);
		bullet_go_hero.start();
		normal_bullet1 = new Bullet(tank1,face);
		bullet_go_normal1 = new Bullet_go(normal_bullet1);
		bullet_go_normal1.start();
		normal_bullet2 = new Bullet(tank2,face);
		bullet_go_normal2 = new Bullet_go(normal_bullet2);
		bullet_go_normal2.start();
		reward_send = new reward();
		boundary = new Boundary();
		change.start();
		deal_blue = new Deal_Bluetooth_Info(herotank,tank1,tank2,hero_bullet,normal_bullet1,normal_bullet2,boundary);
		/*draw_enemy = new Draw_Enemy();
		change_info = new chage_Info_thread_send();
		change_info.start();
		get_change_info = new chage_Info_thread_recive();
		get_change_info.start();*/
		
		 //bu.tankInMap(800, 481);
		can_start = true;//��־���Կ�ʼ�ˡ���Ȼ���߳�Щ���ܿ�ʼ  �����־��change����info�д�����
	}

	
	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		System.out.println("������Ϸ�е�destory�С���");
		if(change != null){
			 change.stop_();
		}
		if(tank1_thread !=null){
			
			tank1_thread.stop_();
		}
		if(tank2_thread != null){
		    tank2_thread.stop_();
		}
		if(hero_go_thread != null){
			hero_go_thread.stop_();
		}
		if(bullet_go_hero != null){
			bullet_go_hero.stop_();
		}
		if(bullet_go_normal1 != null){
			bullet_go_normal1.stop_();
		}
		if(bullet_go_normal2 != null){
			bullet_go_normal2.stop_();
		}
		if(time_thread != null){
			time_thread.stop_();
		}
		
		
		
	}

//**************************************************************************************************************************************
	private void initBitmap(){

		home = BitmapFactory.decodeResource(this.getResources(), R.drawable.home);
		temp = BitmapFactory.decodeResource(this.getResources(), R.drawable.psbe);
		
		protect = BitmapFactory.decodeResource(this.getResources(), R.drawable.covering);
		
		
		//���ּ���
		 Number = new Bitmap[]
				 {
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.number0),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.number1),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.number2),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.number3),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.number4),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.number5),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.number6),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.number7),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.number8),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.number9),
				  
		  };
		  //�ӵ�����
		 NormalBullet = BitmapFactory.decodeResource(this.getResources(), R.drawable.b);
		 HeroBullet = BitmapFactory.decodeResource(this.getResources(), R.drawable.hb);
		  // Ӣ��̹��ͼƬ�ļ���
		
	    HeroTank_1  = new Bitmap[]{
	    		
	    		BitmapFactory.decodeResource(this.getResources(), R.drawable.heroup1),
	    		BitmapFactory.decodeResource(this.getResources(), R.drawable.herodown1),
	  		    BitmapFactory.decodeResource(this.getResources(), R.drawable.heroleft1),
	  		    BitmapFactory.decodeResource(this.getResources(), R.drawable.heroright1),
	  		  
	    };
		

         HeroTank_2  = new Bitmap[]{
	    		
	    		BitmapFactory.decodeResource(this.getResources(), R.drawable.heroup2),
	    		BitmapFactory.decodeResource(this.getResources(), R.drawable.herodown2),
	  		    BitmapFactory.decodeResource(this.getResources(), R.drawable.heroleft2),
	  		    BitmapFactory.decodeResource(this.getResources(), R.drawable.heroright2),
	  		    
	    };
	    
  
          HeroTank_3= new Bitmap[]{
  		
	  		BitmapFactory.decodeResource(this.getResources(), R.drawable.heroup3),
	  		  BitmapFactory.decodeResource(this.getResources(), R.drawable.herodown3),
			    BitmapFactory.decodeResource(this.getResources(), R.drawable.heroleft3),
			    BitmapFactory.decodeResource(this.getResources(), R.drawable.heroright3),
			    
			  
	        };
  
  
          HeroTank_4= new Bitmap[]{
  		
		  		BitmapFactory.decodeResource(this.getResources(), R.drawable.heroup4),
		  		 BitmapFactory.decodeResource(this.getResources(), R.drawable.herodown4),
				    BitmapFactory.decodeResource(this.getResources(), R.drawable.heroleft4),
				    BitmapFactory.decodeResource(this.getResources(), R.drawable.heroright4),
				   
		        };
		  
		  //�ϰ������
		  
			  brick =	  BitmapFactory.decodeResource(this.getResources(), R.drawable.brick);
				ice   =   BitmapFactory.decodeResource(this.getResources(), R.drawable.ice);
		      sea   =		  BitmapFactory.decodeResource(this.getResources(), R.drawable.sea);
		      stone   =	  BitmapFactory.decodeResource(this.getResources(), R.drawable.stone);
		      grass   =	  BitmapFactory.decodeResource(this.getResources(), R.drawable.grass);
				  
		  
		  //��̹ͨ�˵ļ���
		   AttackTank   =  new Bitmap[]   {
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.up1),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.down1),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.left1),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.right1)
		  };
		  
		  
		  FastTank   =   new Bitmap[]    {
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.up2),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.down2),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.left2),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.right2)
		  };
		  
		
		  StrongTank   =    new Bitmap[]   {
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.up3),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.down3),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.left3),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.right3)
		  };
		  
		  redAttackTank   =     new Bitmap[]  {
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.upred1),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.downred1),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.leftred1),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.rightred1)
		  };
		  
		  
		  redFastTank   =    new Bitmap[]   {
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.upred2),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.downred2),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.leftred2),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.rightred2)
		  };
		  
		  redStrongTank   =    new Bitmap[]   {
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.upred3),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.downred3),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.leftred3),
				  BitmapFactory.decodeResource(this.getResources(), R.drawable.rightred3)
		  }; 
		  
		  
		  //���������
		 reward    =     new Bitmap[] {
		
		 
		  BitmapFactory.decodeResource(this.getResources(), R.drawable.bomb),
		  BitmapFactory.decodeResource(this.getResources(), R.drawable.protector),
		  BitmapFactory.decodeResource(this.getResources(), R.drawable.life),
		  BitmapFactory.decodeResource(this.getResources(), R.drawable.timer),
		  BitmapFactory.decodeResource(this.getResources(), R.drawable.star),
	      BitmapFactory.decodeResource(this.getResources(), R.drawable.shovel),
		 
		  
			  
			  };
          
          
          //��ըЧ��
           explode  =  new Bitmap[] {
        		  BitmapFactory.decodeResource(this.getResources(), R.drawable.explode0),
        		  BitmapFactory.decodeResource(this.getResources(), R.drawable.explode1),
        		  BitmapFactory.decodeResource(this.getResources(), R.drawable.explode2),
        		  BitmapFactory.decodeResource(this.getResources(), R.drawable.explode3),
        		  BitmapFactory.decodeResource(this.getResources(), R.drawable.explode4),
        		  BitmapFactory.decodeResource(this.getResources(), R.drawable.explode5),

          };
           //��ť����
          //��װը��
           bomb =   BitmapFactory.decodeResource(this.getResources(), R.drawable.bullet);
        
		   herotankStopbutton  =   BitmapFactory.decodeResource(this.getResources(), R.drawable.reddot);
           killallenemybutton  =  BitmapFactory.decodeResource(this.getResources(), R.drawable.fire);
          

         
	}
	//**************************************************************************************************************************************
	private void  Cancel_all_bir_place(){
		if(Constant.hero_bir_position != -1){
			Constant.hero_bir_position = -1 ;
			Constant.normaltank_bir_position = -1;
		}
	}
//**************************************************************************************************************************************
	@Override
	public boolean onTouchEvent(MotionEvent event) {
       
        switch(event.getAction()){
		
		case MotionEvent.ACTION_DOWN:
			getdownx=event.getX();
			getdowny=event.getY();
			
			// flag=0;
			 flag_d = 1;
			break;
		case MotionEvent.ACTION_UP:
			//Log.v("1", "action_up");
		 
		    getupx=event.getX();
			getupy=event.getY();
			flag_u = 1;
			flag = 0 ;
		    break;
			
		case MotionEvent.ACTION_MOVE:
			 flag ++;
			 getmovex=event.getX();
		     getmovey=event.getY();
		     flag_u = 0 ;
		     flag_d = 0 ;
		     
		     if(getdownx <= Constant.Operate_width){//���������¼�
		    	 
		     }
		     
		     else{//��ߴ���Ļ���¼�
		    		if(flag >=4){  
						
						if(Math.abs(getmovex - getdownx) <= 4 &&  Math.abs(getmovey-getdownx )<= 4 ){
							
							 deal_click(getmovex,getmovey);
						}
						else{
							
							if(Math.abs(getmovex-getdownx)>Math.abs(getmovey-getdowny)){//ˮƽλ�ƽϴ�  ���Ǻ�����¼�
								
								if(getmovex-getdownx>=0){//right
									herotank.move();
									herotank.setDirection(3);
									
								}
								else{//left
									herotank.move();
									herotank.setDirection(2);
									
								}
						    }
						    else{
								
						    	if(getmovey-getdowny<=0){//top
						    		herotank.move();
						    		herotank.setDirection(0);
									
								}
								else{
									herotank.move();
									herotank.setDirection(1);
									 
								}
						    }
						}
						
				}
		    	
				
		     }
		     
		
			
		    break;
		}
		
		
		if(flag_d == 1 && flag_u ==1){  //һ��������down up �¼�
			//click
			
			deal_click(getupx,getupy);
			
		}
		
		
		
		synchronized(o){
			try {
				o.wait(20);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
		
		return true;
		
	}
	
	//**************************************************************************************************************************************
   
	private void deal_click(float x , float y){
		
		 
		
		if(x < Constant.Operate_width){// ������������¼�
				if(
						Constant.pointinarea(x, y, 0, Constant.Screen_Y-boundary.Button_stop.getHeight(),
				        boundary.Button_stop.getWidth(),boundary.Button_stop.getHeight())
				  )
				{
					hero_bullet.shoot();

			//      herotank.stopmove();
		        }
		}
		else{
			//�ӵ������¼�
					}
	
	}
	@Override
	  public boolean onKeyDown(int keyCode, KeyEvent event) {   
	        //�ڻ�ӭ��������BACK��   
	        if(keyCode==KeyEvent.KEYCODE_BACK) {
	        	if( System.currentTimeMillis() - time < 2000){
	        		
	        		
		        	if(!Listener_bluetooth.getflag()){//ֹͣ�߳�
		    				Listener_bluetooth.stop_();
		    		}
		    		if(chage_Info_thread_recive.getflag()){
		    			chage_Info_thread_recive.stop_();
		    			System.out.println("���ڽ�����Ϣ�߳���    �ұ�ͣ�����ס���");
		    		}
		    		
		    		if(chage_Info_thread_send.getflag()){
		    			System.out.println("���Ƿ�����Ϣ�߳�  �ұ�ͣ����");
		    			chage_Info_thread_send.stop_();
		    		}
		        		
	                    int i = 1/0;//�˳�����
	        	}
	        	else{
	        			time = System.currentTimeMillis();
	        		System.out.println("�ٰ�һ���˳�����");
	        	}
	        
	        	//System.out.println("�Ұ��˷��ؼ�");
	            return true;   
	        }   
	        return true;   
	    }   
	
}








