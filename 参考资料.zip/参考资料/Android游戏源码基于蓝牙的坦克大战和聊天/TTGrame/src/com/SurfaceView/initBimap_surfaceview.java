package com.SurfaceView;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import com.example.my_firstgame.R;
import com.tools.Constant;

public class initBimap_surfaceview extends SurfaceView implements SurfaceHolder.Callback{

	
	 public static Bitmap  Number  [] ;
		public static Bitmap home;
		  //�ӵ�����
		  public static  Bitmap   NormalBullet;
		  public static Bitmap HeroBullet;
		  // Ӣ��̹��ͼƬ�ļ���
		  public static Bitmap[] HeroTank_1;
		  public static Bitmap[] HeroTank_2;
		  public static Bitmap[] HeroTank_3;
		  public static Bitmap[] HeroTank_4;
		  public static Bitmap temp;
		  //�ϰ������
		   public static Bitmap grass;
		   public static Bitmap ice;
		   public static Bitmap stone;
		   public static Bitmap brick;
		   public static Bitmap sea;
		   public static Bitmap protect;
		   public static Bitmap tank_shengming;
		   public static Bitmap kill_tank ;
		  //��̹ͨ�˵ļ���
		   public static Bitmap [] AttackTank ;
		   public static Bitmap [] FastTank   ;
		   public static Bitmap [] StrongTank ;
		   public static Bitmap [] redAttackTank  ;
		   public  static Bitmap [] redFastTank   ; 
		   public static Bitmap [] redStrongTank  ; 
		   public static Bitmap double_people ;
		   public static Bitmap exit ;
		   public static Bitmap help ;
		  
		   public static Bitmap jiemian ;
		   
		   public static Bitmap fanshang ;
		   public static Bitmap hiding ;
		   public static Bitmap bu_protect ; 
		   public static Bitmap zhenshi ;
		   public static Bitmap stop ;
		   public static Bitmap bu_bomb ;
		   public static Bitmap kill_all;
		   public static Bitmap stop_all;
		   public static Bitmap jineng_fanshang;
		   
		  //���������
		   public  static Bitmap [] reward_   ;
		 
		  //��ť����
		   public static Bitmap herotankStopbutton ;
		   public static Bitmap killallenemybutton;
	      //��ըЧ��
		   public  static Bitmap explode [];
	      
	      //��װը��
		   public static Bitmap bomb;
	 
	
	public initBimap_surfaceview(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void surfaceChanged(SurfaceHolder arg0, int arg1, int arg2, int arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void surfaceCreated(SurfaceHolder arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder arg0) {
		// TODO Auto-generated method stub
		
	}

	
	public  void initBitmap(){
		 
		home = Constant.init_bitmap(this, R.drawable.home);
		temp = Constant.init_bitmap(this, R.drawable.psbe);
		
		  brick =	 Constant.init_bitmap(this, R.drawable.brick);
		  ice   =  Constant.init_bitmap(this,R.drawable.ice);
	      sea   =	Constant.init_bitmap(this, R.drawable.sea);
	      stone   =	 Constant.init_bitmap(this, R.drawable.stone);
	      grass   =	 Constant.init_bitmap(this, R.drawable.grass);
			  
	      
		double_people = Constant.init_bitmap(this, R.drawable.double_);
		exit = Constant.init_bitmap(this, R.drawable.exit);
		help = Constant.init_bitmap(this, R.drawable.help);
		
		
		protect =Constant.init_bitmap(this, R.drawable.covering);
		
		//jiemian = Constant.init_bitmap(this, R.drawable.tank_jiemian);
		//tank_shengming =  BitmapFactory.decodeResource(this.getResources(), R.drawable.shengming);
		//kill_tank =  BitmapFactory.decodeResource(this.getResources(), R.drawable.jisha);
		
		//���ּ���
		 Number = new Bitmap[]
				 {
				 Constant.init_bitmap(this, R.drawable.number0),
				 Constant.init_bitmap(this, R.drawable.number1),
				 Constant.init_bitmap(this, R.drawable.number2),
				 Constant.init_bitmap(this, R.drawable.number3),
				 Constant.init_bitmap(this, R.drawable.number4),
				 Constant.init_bitmap(this, R.drawable.number5),
				 Constant.init_bitmap(this, R.drawable.number6),
				 Constant.init_bitmap(this, R.drawable.number7),
				 Constant.init_bitmap(this, R.drawable.number8),
				 Constant.init_bitmap(this, R.drawable.number9),
				  
		  };
		  //�ӵ�����
		 NormalBullet = Constant.init_bitmap(this, R.drawable.b);
		 HeroBullet = Constant.init_bitmap(this, R.drawable.hb);
		  // Ӣ��̹��ͼƬ�ļ���
		
	    HeroTank_1  = new Bitmap[]{
	    		
	    		Constant.init_bitmap(this, R.drawable.heroup1),
	    		Constant.init_bitmap(this, R.drawable.herodown1),
	    		Constant.init_bitmap(this, R.drawable.heroleft1),
	    		Constant.init_bitmap(this, R.drawable.heroright1),
	  		  
	    };
		

         HeroTank_2  = new Bitmap[]{
	    		
        		 Constant.init_bitmap(this,R.drawable.heroup2),
        		 Constant.init_bitmap(this, R.drawable.herodown2),
        		 Constant.init_bitmap(this, R.drawable.heroleft2),
        		 Constant.init_bitmap(this, R.drawable.heroright2),
	  		    
	    };
	    
  
          HeroTank_3= new Bitmap[]{
  		
        		  Constant.init_bitmap(this, R.drawable.heroup3),
        		  Constant.init_bitmap(this, R.drawable.herodown3),
        		  Constant.init_bitmap(this, R.drawable.heroleft3),
        		  Constant.init_bitmap(this, R.drawable.heroright3),
			    
			  
	        };
  
  
          HeroTank_4= new Bitmap[]{
  		
        		  Constant.init_bitmap(this, R.drawable.heroup4),
        		  Constant.init_bitmap(this, R.drawable.herodown4),
        		  Constant.init_bitmap(this, R.drawable.heroleft4),
        		  Constant.init_bitmap(this, R.drawable.heroright4),
				   
		        };
		  
		  //�ϰ������
		  
			
		  
		  //��̹ͨ�˵ļ���
		   AttackTank   =  new Bitmap[]   {
				   Constant.init_bitmap(this,R.drawable.up1),
				   Constant.init_bitmap(this, R.drawable.down1),
				   Constant.init_bitmap(this,R.drawable.left1),
				   Constant.init_bitmap(this,R.drawable.right1)
		  };
		  
		  
		  FastTank   =   new Bitmap[]    {
				  Constant.init_bitmap(this,R.drawable.up2),
				  Constant.init_bitmap(this, R.drawable.down2),
				  Constant.init_bitmap(this,R.drawable.left2),
				  Constant.init_bitmap(this,R.drawable.right2)
		  };
		  
		
		  StrongTank   =    new Bitmap[]   {
				  Constant.init_bitmap(this, R.drawable.up3),
				  Constant.init_bitmap(this,R.drawable.down3),
				  Constant.init_bitmap(this,R.drawable.left3),
				  Constant.init_bitmap(this,R.drawable.right3)
		  };
	
	
		  redAttackTank   =     new Bitmap[]  {
				  Constant.init_bitmap(this, R.drawable.upred1),
				  Constant.init_bitmap(this, R.drawable.downred1),
				  Constant.init_bitmap(this, R.drawable.leftred1),
				  Constant.init_bitmap(this,R.drawable.rightred1)
		  };
		  
		  
		  redFastTank   =    new Bitmap[]   {
				  Constant.init_bitmap(this,R.drawable.upred2),
				  Constant.init_bitmap(this, R.drawable.downred2),
				  Constant.init_bitmap(this,R.drawable.leftred2),
				  Constant.init_bitmap(this,R.drawable.rightred2)
		  };
		  
		  redStrongTank   =    new Bitmap[]   {
				  Constant.init_bitmap(this, R.drawable.upred3),
				  Constant.init_bitmap(this, R.drawable.downred3),
				  Constant.init_bitmap(this, R.drawable.leftred3),
				  Constant.init_bitmap(this, R.drawable.rightred3)
		  }; 
		  
		  
		  //���������
		 reward_    =     new Bitmap[] {
		
		 
				 Constant.init_bitmap(this, R.drawable.bomb),
				 Constant.init_bitmap(this, R.drawable.protector),
				 Constant.init_bitmap(this, R.drawable.life),
				 Constant.init_bitmap(this, R.drawable.timer),
				 Constant.init_bitmap(this, R.drawable.star),
				 Constant.init_bitmap(this, R.drawable.shovel),
		 
		  
			  
			  };
          
          
          //��ըЧ��
           explode  =  new Bitmap[] {
        		   Constant.init_bitmap(this,R.drawable.explode0),
        		   Constant.init_bitmap(this,R.drawable.explode1),
        		   Constant.init_bitmap(this, R.drawable.explode2),
        		   Constant.init_bitmap(this,R.drawable.explode3),
        		   Constant.init_bitmap(this,R.drawable.explode4),
        		   Constant.init_bitmap(this, R.drawable.explode5),

          };
           //��ť����
          //��װը��
       
           fanshang =  Constant.init_bitmap(this,R.drawable.fanshang);
           hiding =  Constant.init_bitmap(this,R.drawable.hiding);
           zhenshi =  Constant.init_bitmap(this,R.drawable.zhenshi);
           stop =  Constant.init_bitmap(this,R.drawable.stop);
           bu_bomb =   Constant.init_bitmap(this,R.drawable.bu_bomb);
           bomb =  Constant.init_bitmap(this,R.drawable.bomb_);
           bu_protect =  Constant.init_bitmap(this,R.drawable.protect);
           stop_all =  Constant.init_bitmap(this,R.drawable.stop_all);
           kill_all =  Constant.init_bitmap(this,R.drawable.kill_all);
           jineng_fanshang = Constant.init_bitmap(this,R.drawable.jineng_fanshang);
           
		   herotankStopbutton  =    Constant.init_bitmap(this,R.drawable.reddot);
           killallenemybutton  =   Constant.init_bitmap(this,R.drawable.fire);
          
    
      
	}

}
