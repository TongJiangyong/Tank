package com.SurfaceView;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import com.Thread.change_welcome_alpha;
import com.example.my_firstgame.R;
import com.tools.Constant;

public class welcome_surfaceview extends SurfaceView implements SurfaceHolder.Callback {

	private SurfaceHolder holder ;
	private Bitmap welcome,welcome_ ;
	private Paint paint ;
	private int alpha = 100;
	private change_welcome_alpha change_alpha;
	private Handler handler ;
	public welcome_surfaceview(Context context,Handler handler) {
		super(context);
		// TODO Auto-generated constructor stub
		//�õ�SufaceHolder����
		holder = this.getHolder();  
        holder.addCallback(this);
        this.handler = handler;
	}

	@Override 
	public  void onDraw(Canvas canvas){
		if(canvas != null){
			canvas.drawBitmap(welcome_, 0,0, paint);
		}
		
		
	}
	
	@Override
	public void surfaceChanged(SurfaceHolder arg0, int arg1, int arg2, int arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void surfaceCreated(SurfaceHolder arg0) {
		// TODO Auto-generated method stub
		welcome =  BitmapFactory.decodeResource(this.getResources(), R.drawable.welcome);
		welcome_ = Constant.resizeImage(welcome, Constant.Screen_X, Constant.Screen_Y);
		welcome = Constant.shifang(welcome);//�ͷ��ڴ�
		paint = new Paint();
		paint.setStyle( Paint.Style.STROKE );   //����  
        change_alpha = new change_welcome_alpha(holder , this,handler);
        change_alpha.start();
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	  public boolean onKeyDown(int keyCode, KeyEvent event) {   
	        //�ڻ�ӭ��������BACK��   
	        if(keyCode==KeyEvent.KEYCODE_BACK) {   
	            return false;   
	        }   
	        return false;   
	    }   
}



















