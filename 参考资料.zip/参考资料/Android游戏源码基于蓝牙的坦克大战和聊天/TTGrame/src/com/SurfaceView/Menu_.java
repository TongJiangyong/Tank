package com.SurfaceView;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Handler;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import com.tools.Constant;

public class Menu_ extends SurfaceView implements SurfaceHolder.Callback{

	private Handler handler ;
	private SurfaceHolder holder ;
	private Canvas canvas;
	private Bitmap jiemian, shuangren , help , exit  ;
	
	public Menu_(Context context,Handler handler) {
		super(context);
		// TODO Auto-generated constructor stub
		this.handler = handler;
		this.setFocusableInTouchMode(true);
		holder = this.getHolder();  
        holder.addCallback(this);
		
	}

	@Override
	public void surfaceChanged(SurfaceHolder arg0, int arg1, int arg2, int arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void surfaceCreated(SurfaceHolder arg0) {
		// TODO Auto-generated method stub
		
		
		jiemian = Constant.resizeImage(initBimap_surfaceview.jiemian, Constant.Screen_X,Constant.Screen_Y);
		shuangren  = Constant.resizeImage(initBimap_surfaceview.double_people, (120*Constant.Screen_X)/800 ,(60*Constant.Screen_Y)/480);
		help = Constant.resizeImage(initBimap_surfaceview.help, (120*Constant.Screen_X)/800 ,(60*Constant.Screen_Y)/480);
		exit = Constant.resizeImage(initBimap_surfaceview.exit, (120*Constant.Screen_X)/800 ,(60*Constant.Screen_Y)/480);
		
		
		initBimap_surfaceview.exit  = Constant.shifang(initBimap_surfaceview.exit);
		initBimap_surfaceview.help  = Constant.shifang(initBimap_surfaceview.help);
		initBimap_surfaceview.double_people  = Constant.shifang(initBimap_surfaceview.double_people);
		//initBimap_surfaceview.jiemian  = Constant.shifang(initBimap_surfaceview.jiemian);
		
		
		
		Paint paint = new Paint();
	    canvas = holder.lockCanvas();
	    
	    canvas.drawBitmap(jiemian, 0, 0 , paint);
	    canvas.drawBitmap(shuangren, Constant.Screen_X/2, Constant.Screen_Y/4,paint);
	    canvas.drawBitmap(help,Constant.Screen_X/2 ,Constant.Screen_Y/4*2, paint);
	    canvas.drawBitmap(exit, Constant.Screen_X/2,Constant.Screen_Y/4*3, paint);
	    holder.unlockCanvasAndPost(canvas);
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder arg0) {
		// TODO Auto-generated method stub
		
	}

}
