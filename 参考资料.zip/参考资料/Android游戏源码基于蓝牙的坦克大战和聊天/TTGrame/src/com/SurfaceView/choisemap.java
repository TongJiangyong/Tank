package com.SurfaceView;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Message;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import com.Thread.confirm_map;
import com.example.my_firstgame.R;
import com.tools.Constant;

public class choisemap extends SurfaceView implements SurfaceHolder.Callback  {

	private SurfaceHolder holder;
	private Bitmap[] map = new Bitmap[1];
	private float getupx,getupy,getdownx,getdowny,getmovex,getmovey;
	private int flag,flag_u,flag_d;
	private Object o = new Object();
	private Canvas canvas ;
	private Paint paint;
	private Handler handler;
	private confirm_map map_ ;
	private long time;
	//private Message msga ;
	public choisemap(Context context,Handler handler) {
		super(context);
	    
		//msga = new Message();
		this.handler = handler;
		this.setFocusableInTouchMode(true);
		holder = this.getHolder();  
        holder.addCallback(this);
        map[0]  = BitmapFactory.decodeResource(this.getResources(), R.drawable.map_1);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void surfaceChanged(SurfaceHolder arg0, int arg1, int arg2, int arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void surfaceCreated(SurfaceHolder arg0) {
		// TODO Auto-generated method stub
		map_  = new confirm_map(handler);
		map_.start();
		paint = new Paint();
		paint.setAntiAlias(true);
		paint.setColor(Color.WHITE);
		canvas = holder.lockCanvas();
		
		canvas.drawBitmap(map[0],0,0 , paint);
		holder.unlockCanvasAndPost(canvas);
				
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder arg0) {
		// TODO Auto-generated method stub
		
		
	}
	
	
	
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
       
        switch(event.getAction()){
		
		case MotionEvent.ACTION_DOWN:
			getdownx=event.getX();
			getdowny=event.getY();
			
			// flag=0;
			 flag_d = 1;
			break;
		case MotionEvent.ACTION_UP:
			//Log.v("1", "action_up");
		 
		    getupx=event.getX();
			getupy=event.getY();
			flag_u = 1;
			flag = 0 ;
		    break;
			
		case MotionEvent.ACTION_MOVE:
			 flag ++;
			 getmovex=event.getX();
		     getmovey=event.getY();
		     flag_u = 0 ;
		     flag_d = 0 ;
		
			
		    break;
		}
		
		
		/*if(flag_d == 1 && flag_u ==1){  //һ��������down up �¼�
			//click
			
			deal_click(getupx,getupy);
			
		}
		if(flag < 4){//���ƿ�������¼�
			deal_click(getmovex,getmovey);
		}*/
		
		deal_click(getdownx,getdowny,getupx,getupy);
		
		synchronized(o){
			try {
				o.wait(20);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
		
		return true;
		
	}
	private void deal_click(float downx ,float downy,float upx,float upy){
		
		if(
				Constant.pointinarea(downx, downy, 0, 0, map[0].getWidth(), map[0].getHeight())
				&&Constant.pointinarea(upx, upy, 0, 0, map[0].getWidth(), map[0].getHeight())
		){
			Constant.whichMap = 0;
		//	map_.Write((byte)Constant.whichMap);
			confirm_map.stop_();
			Message msga = new Message();
			
			msga.what = 1;//��֪uiѡͼ���
			handler.sendMessage(msga);
			
		}
	}
	
	
}















