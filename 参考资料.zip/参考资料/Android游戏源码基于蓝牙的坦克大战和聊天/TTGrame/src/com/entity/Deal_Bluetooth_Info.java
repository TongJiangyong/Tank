package com.entity;

import com.Thread.chage_Info_thread_send;
import com.tools.Constant;

import java.math.BigDecimal;
/**
 * �������������Ľ�����Ϣ
 * �ͻ����������������������͸������������ʾ
 * @author Administrator
 * ���ô��͵�ͼ��Ϣ�����ڱ��ش�������ˡ�����
 */

public class Deal_Bluetooth_Info {
	
    private chage_Info_thread_send change_info ;
    private static String send,get;
	private static byte[] writemessage ;
	private static Herotank hero_tank ;
	private static NormalTank tank1 ,tank2;
	private static enemy_hero_tank enemy_tank_hero ;
	private static ene_normal_tank tank5,tank6;
	private static Bullet enemy_bullet,ene_tank5_bullet,ene_tank6_bullet;
	private static long rem_time = 0 ;
	private static boolean send_position = true;
	private static boolean begin = true;//��ʾ�տ�ʼ ��ʼ�󡣡��˱�����������true
	private static boolean tank_direction = false;//��ʾtank�ķ����ǲ��Ǹı��ˡ�
	private static boolean hero_shoot = false;//�ж�tank�Ƿ����ӵ���
	private static boolean tank1_shoot = false;
	private static boolean tank2_shoot = false;
	private static boolean reward = false;//�жϿͻ����Ƿ�����˽���
	private static boolean hero_tank_go = false ;
	private static boolean hero_tank_dongo = false;
	private static boolean hero_tank_running = false;
	
	private static boolean set_landmine = false;//�Ƿ��Ƿ����ҵ�����
	private static boolean hiding = false;//����
	private static boolean fanshang  = false;//�м�
	private static boolean wudi = false;//�޵�
	private static boolean stop_everone = false;//ȫ��ͣ
	private static boolean kill_all = false;//ȫ��strong --��
	
	private static boolean hero_dead = false;
	private static boolean tank1_dead = false;
	private static boolean tank2_dead = false;
	
	
	private static boolean success = false;//�����жϴ����������Ϣ�ǲ�����ȷ����
	
	private static boolean loading  = false;
	
	


public Deal_Bluetooth_Info(Herotank herotank, NormalTank tank12,
			NormalTank tank22, Bullet hero_bullet, Bullet normal_bullet1,
			Bullet normal_bullet2, Boundary boundary) {
		// TODO Auto-generated constructor stub
	}

	//**********************************************************************************************************************
    public static void Deal_Bluetooth_Info_(Herotank tank , NormalTank tank1,NormalTank tank2,
    		enemy_hero_tank enemy_tank_hero,Bullet enemy_bullet,Bullet bullet_tank5,Bullet bullet_tank6,
    		ene_normal_tank tank5 ,ene_normal_tank tank6 ){
    	hero_tank = tank ;
    	Deal_Bluetooth_Info.tank1 = tank1; 
        Deal_Bluetooth_Info.tank2 = tank2;
    	ene_tank5_bullet = bullet_tank5;
    	ene_tank6_bullet = bullet_tank6;
    	Deal_Bluetooth_Info.enemy_tank_hero = enemy_tank_hero;
    	Deal_Bluetooth_Info.enemy_bullet = enemy_bullet;
    	Deal_Bluetooth_Info.tank5 = tank5 ;
    	Deal_Bluetooth_Info.tank6 = tank6;
    }
//**********************************************************************************************************************
    
    public static void begin(){
    	begin = true;
    }
    
    public static void change_hiding (){
    	hiding = true;
    }
    public static void change_fanshang (){
    	fanshang = true;
    }
    public static void chang_wudi(){
    	wudi = true;
    }
    public static void change_stop_everone(){
    	stop_everone = true;
    }
    public static void change_kill_all(){
    	kill_all = true;
    }
    public static void changed_tank_direction(){
    	tank_direction = true;
    }
    public static void changed_hero_shoot(){//���tank�����ӵ�������������
    	hero_shoot = true;
    }
    public static void changed_tank1_shoot(){
    	
    	tank1_shoot = true;
    }
    public static void changed_tank2_shoot(){
    	tank2_shoot = true;
    }
    public static void changed_reward (){
    	reward  = true;
    }
    public static void chaged_tank_go(){
    	hero_tank_running = true;//tank״̬��run
    	hero_tank_go = true;
    }
    public static void change_set_landmine(){
    	set_landmine = true;
    }
    public static boolean is_herotank_go(){
    	//tank��run����true   don't run ��false  Ϊ��һ����������һ����Ϣ  �ڴ�����Ļ��ʱ���ж�tank�ǲ��������С��������ڵ�״̬��һ�²ŷ�����Ϣ
    	if(hero_tank_running )   return true ;
    	return false;

    }
    public static void changed_tank_dongo(){
    	hero_tank_running = false;
    	hero_tank_dongo = true;
    }
    public static void seted_landmine(){
    	set_landmine = true;
    }
    
    public static void change_hero_dead(){
    	hero_dead = true;
    }
    public static void change_tank1_dead(){
    	tank1_dead = true;
    }
    public static void change_tank2_dead(){
    	tank2_dead = true;
    }
    public static void done_loading(){
    	
    	loading = true;
    }
//***************************************************************************************************************************************

    
 //***************************************************************************************************************************************

    public static byte[] send_message(){//����Ҫ���͵���Ϣ
  		  String send = null ;
  		  
  		
    		   if (tank_direction){
    			  send = "��,"+hero_tank.get_direction()+","+tank1.get_direction()+","+tank2.get_direction()+",end,";
    			  tank_direction = false;//����
    				
    		  }
    		  
    		  //�ж����ĸ�tank�������ӵ�����
    		   else if(loading)
     		  {
     			  loading = false;
     			 
     			  send = "done_loading,";
     		  }
    		 
    		  else if (hero_shoot){//herotank�������ӵ�����
    			  send = "Ӣ��,";
    			  hero_shoot = false;
    				
    		  }
    		  else if(tank1_shoot){
    			  send = "һ��,";
    			  tank1_shoot = false;
    				
    		  }
    		  else if (tank2_shoot){
    			  
    			  send = "����,";
    			  tank2_shoot = false;
    				
    		  }
    		  else if(hero_tank_go){
    			  
    			  send = "Ӣ��,";
    			  hero_tank_go = false;//�����ָ�������ȻҪ�ظ�������Ϣ
    			
    		   
    		      
    		  }
    		  else if (hero_tank_dongo){
    			  send = "Ӣͣ,";
    			
    			  hero_tank_dongo = false;//����ֻ������ָ��������ܴ���ʲô������
    				
    		  }
    		  
    		  
    		  //�ǿͻ��ˡ�����ô�ѽ�����Ϣ���͸��Է�
    		  else if(Constant.C && reward){
    			  
    				  send = "��,"+Constant.reward_position_x+","+Constant.reward_position_y+","+Constant.reward+",end,";
    				  reward = false;
    					
    		  }
    		  else if(Boundary.get_now_time() % 2 == 0 && send_position ){//����һ�η��ͱ��ص�tankλ��
    			  rem_time = Boundary.get_now_time() ;
    			  send = "λ,"+hero_tank.get_x()+","+hero_tank.get_y()+","
    			                    +tank1.get_x()+","+tank1.get_y()+","
    					            +tank2.get_x()+","+tank2.get_y()+",end,";
    			 send_position = false;
    				
    		  }
    		  else if(Boundary.get_now_time()  == (rem_time+1)){//������ʱ�ָ̻�..���ﲻ�Ǵ�������
    			  send_position = true;
    		  }
    		  else if (set_landmine){
    			set_landmine = false;
    		
    			send = "ը,";
    		  }
    		  
    		  else if(hiding ){
    			  hiding = false;
    				
    			  send = "��,";
    			  
    		  }
    		  else if(fanshang){
    			  fanshang  = false;
    			
    			  send = "��,";
    		  }
    		  else if(wudi){
    			  wudi = false;
    				
    			  send = "��,";
    		  }
    		  else if(kill_all){
    			  kill_all = false;
    				
    			  send = "ȫ,";
    		  }
    		  else if(stop_everone){
    			  stop_everone = false;
    			
    			  send = "ͣȫ,";
    		  }
    		  else if(hero_dead){
    			  hero_dead = false;
    			
    			  send = "Ӣ��,";
    		  }
    		  else if(tank1_dead){
    			  tank1_dead = false;
    				
    			  send = "һ��,";
    		  }
    		  else if(tank2_dead){
    			  tank2_dead = false;
    				
    			  send ="����,";
    		  }
    		  
    		  //���м��ܵķ�֧����
    		 
  		 //}
  		 if(send != null){
  			
			  return send.getBytes();
		  }
  	
  		 return null;
  		
  		  
  
    }

  //**********************************************************************************************************************
    public static void write_message(byte[] info){//�����Ϣ
    	
    	    System.out.println(new String(info));
         	String get = new String(info);
         	String[] ysl = get.split(",");
         	
         	try{
         		
             	if(ysl[0].equals("��")){
             		
             		
             		Constant.enemy_hero_direction = Integer.parseInt(ysl[1]);
             		tank5.setDirection(  Integer.parseInt(ysl[2]));
             		tank6.setDirection(Integer.parseInt(ysl[3]));
             		//if(ysl[4].equals("end")){
             			success = true;
             		//}
             	
             	}
             
             	else if(ysl[0].equals("done_loading")){
             		
             		Constant.done_loading = true;
             	}
             	else if(ysl[0].equals("Ӣ��")){
             		enemy_bullet.shoot();
             		success = true;
             	}
             	else if (ysl[0].equals("һ��")){
             		ene_tank5_bullet.shoot();

             		success = true;
             	}
             	else if(ysl[0].equals("����")){
             		ene_tank6_bullet.shoot();
             		success = true;
             	}
             	else if (ysl[0].equals("��")){
             		Constant.reward_position_x = Float.parseFloat(ysl[1]);
             		Constant.reward_position_y = Float.parseFloat(ysl[2]);
             		Constant.reward = Float.parseFloat(ysl[3]);
             		
             		//if(ysl[4].equals("end")){
             			success = true;
             		///}
             	}
             	else if(ysl[0].equals("Ӣ��")){
             		enemy_tank_hero.move();
             	//	if(ysl[1].equals("end"))
             		success = true;
             		
             	}
             	else if(ysl[0].equals("Ӣͣ")){//ֹͣ����
             		enemy_tank_hero.stop_move();
             		//if(ysl[1].equals("end")) 
             		success = true;
             	}
             	else if(ysl[0].equals("λ")){
             	    enemy_tank_hero.set_x(  Float.parseFloat(ysl[1]));
             	    enemy_tank_hero.set_y ( Float.parseFloat(ysl[2]));
             		tank5.set_x(Float.parseFloat(ysl[3]));
             		tank5.set_y(Float.parseFloat(ysl[4]));
             		tank6.set_x(Float.parseFloat(ysl[5]));
             		tank6.set_y(Float.parseFloat(ysl[6]));
             		
             		//if(ysl[3].equals("end"))
             		success = true;
             	}
             	else if(ysl[0].equals("ը")){
             		jineng.ene_hero_set_boom();
             		//if(ysl[1].equals("end"))
             		success = true;
             	}
             	else if(ysl[0].equals("��")){
             		enemy_tank_hero.I_m_hiding();
             		success = true;
             	}
             	else if(ysl[0].equals("��")){
             		enemy_tank_hero.I_m_fanshang();
             		success = true;
             	}
             	else if(ysl[0].equals("��")){
             		enemy_tank_hero.i_m_wudi();
             		success = true;
             	}
             	else if(ysl[0].equals("ȫ")){
             		Constant.ene_get_bomb = true;
             		success  = true;
             	}
             	else if(ysl[0].equals("ͣȫ")){
             		 Constant.stop_fri_tank = true;
             		 success = true;
             	}
             	else if(ysl[0].equals("Ӣ��")){
             		//enemy_tank_hero.set_strong(0);
             		
             		success = true;
             		
             	}
             	else if(ysl[0].equals("һ��")){
             	//	tank5.set_strong(0);
             		
             		
             		
             		success = true;
             		
             	}
             	else if(ysl[0].equals("����")){
             		//tank6.set_strong(0);
             		
             		
             		
             		success = true;
             	}
             //	else if(ysl[0].equals("ok")){
             	//	chuansong = true;
             	//}
         	}
         	
         	
         	catch(ArrayIndexOutOfBoundsException e){
         		System.out.println("����deal����bluetooth�д�����Ϣ��������������");
         		e.printStackTrace();
         	}
         	catch(NumberFormatException e){
         		e.printStackTrace();
         		System.out.println("����ת���쳣");
         	}
         	
    }
        		
    		
    
    	
    
    //**********************************************************************************************************************
    private static float get_dealed_x(float x){
		return (Constant.Screen_X*x)/Constant.enemy_Screen_X;
	}
	private static float get_dealed_y(float y){
		return (Constant.Screen_Y*y)/Constant.enemy_Screen_Y;
	}
	private static double round(double value) {//ȷ�������͵ľ���

		   BigDecimal bd = new BigDecimal(value);

		   bd = bd.setScale(2,  BigDecimal.ROUND_CEILING);

		   double d = bd.doubleValue();

		  bd = null;

		  return d;
	}
}



























