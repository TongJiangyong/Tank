package com.entity;

import android.graphics.Canvas;
import android.graphics.Paint;

import com.tools.Constant;

public class loading {

	
	public  void Drawself(Canvas canvas, Paint paint){
		
		    paint.setTextSize(50);
	      	canvas.drawText("Loading.....", (Constant.Screen_X/2)-(200*Constant.Screen_X)/800, Constant.Screen_Y/2, paint);
	}
}
