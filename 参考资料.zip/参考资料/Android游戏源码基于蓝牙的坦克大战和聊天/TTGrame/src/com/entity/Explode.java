package com.entity;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;

import com.SurfaceView.initBimap_surfaceview;
import com.tools.Constant;

public class Explode {
  
	private int zheng=0;//����֡
	private int double_zheng = 0 ; //��Ϊ��̫֡�졣��������֡��һͼ
	
	public Bitmap[] tank_explode;
	private Bitmap protect ;
	//********************************************************************************************************************
	 public Explode(){
		 
		this.tank_explode = initBimap_surfaceview.explode ;
		 for(int i = 0 ;i < tank_explode.length ; i++){//����ͼƬ
			 
			 tank_explode[i] = Constant.resizeImage(initBimap_surfaceview.explode[i], Constant.tank_width, Constant.tank_height);
			 
		 }
	    protect = initBimap_surfaceview.protect ;
	    protect = Constant.resizeImage(protect,Constant.tank_width+5,Constant.tank_height+5);
	   
	}
	//********************************************************************************************************************
	//����󷵻���
	 public boolean drawexplode(Canvas canvas , Paint paint,float x,float y ){
		 
		 if(zheng >= tank_explode.length ){
			 double_zheng = 0 ;
			 zheng =  0;
			 return true;
		 }
		 else{
			 try{
				 
				 canvas.drawBitmap(tank_explode[double_zheng], x, y, paint);
				 zheng ++;
				 if(zheng % 2 == 0 ){
					 double_zheng ++;
				 }
				 
				
			 }catch(ArrayIndexOutOfBoundsException e){
				 e.printStackTrace();
				 return true;
			 
			 }
			  return false;
		 }
	 }
	//********************************************************************************************************************
	 public boolean Drawprotect(Canvas canvas , Paint paint ,float x , float y){
		 zheng ++;
		 if(zheng<350){//һ�����֡
			
			 canvas.drawBitmap(protect, x, y, paint);
		 }
		 else{// �����
			 zheng  = 0 ;
			 return true;
		 }
		 return false;
	 }
}
























