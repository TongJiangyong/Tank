package com.entity;



public class Barrier {
	 
    public static int brick = 1 ;
    public static int sea =  2 ; 
    public static int ice = 3 ;
    public static int grass = 4;
    public static int stone  = 5;
	
     
}
