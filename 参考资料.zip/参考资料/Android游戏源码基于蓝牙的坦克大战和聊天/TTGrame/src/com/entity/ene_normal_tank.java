package com.entity;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;

import com.SurfaceView.initBimap_surfaceview;
import com.tools.Constant;
/**
 * �����������з���̹ͨ��
 * @author Administrator
 *�з���ͨtank���������Ʒ���ͷ����ӵ���������ı���tankҪ�Ƿ���ı䷢�͸����ء�
 *�����ӵ���ķֿ�����Ҫ��������tank��Ϊ5��6
 */
public class ene_normal_tank extends Tank {
	private Bitmap[] tank ;
	private int number_tank = 0 ;//�ж����Ǽ���̹��
	private int star = 0 ;//��ʾ���˼�������   һ���ӵ��ٶȼӿ�  �����Ϳ��Է��������ӵ��� �����Ϳ��Ի��� stone
	private boolean wudi =true;
	//̹������
	private boolean is_live = false ;//�ж��Ƿ����
	//�Ƿ��ܷ����ӵ�
	private boolean canshoot = true;
	//�����ƶ��
	private boolean canmove = true ;
	//���ܳ��ܼ��ι���
	private int canbear = 1;
	//�ٶ�
	
	private float speed = 0;
	private int count ;
	private int where = -1;//����λ��
	
	//�ӵ���Ч��    ������Ч��
	private int kill = 0 ;
	private float skill = 0 ;
	//ȡ����ʲôtank 0 ����ͨ��̹��   1��fast̹��  2��strongtank
	private int who = -1 ;
	//����  0 ��  1��  2 ��   3 ��   
	private int direction = 3 ;
	private int strong = 0;
	private Explode explode  ;
	//�Ƿ��ܹ���
	private boolean can_acrossriver = false ;
	private boolean star_change = false;
	//�Ƿ��޵�
	private boolean is_unmatched = false ;
	private float tank_width =  Constant.tank_width,
			      tank_height = tank_width;//Ϊ�˱���tankΪ������
  
	//tank ������  
	private  float y,x;
//	private int birthwhere=-1;
	
	
	Object[] normaltank  = new Object[3];
	private Bitmap[] Attacktank = new Bitmap[4],Fasttank = new Bitmap[4],Strongtank = new Bitmap[4];
	//�����Ƿ���
	//******************************************************************************************************************************
	public float get_x(){
		return x;
	}
	public  void jia_star(){
		star++;
		star_change = true;
	}
	public void jian_star(){
		star-- ;
		star_change = true ;
	}
	public float get_y(){
		return y;
	}
	public int get_direction (){
		return direction ;
	}
	
	public void set_x(float x){
		this.x = x;
	}
	public void set_y(float y ){
		this.y = y ;
	}
	public float get_tanksize(){//��ȡtank�ĳߴ�  ��Ϊ������������͵��
		return tank_width;
	}
	public int get_star(){
		return star;
	}
	public void set_star(int h){
		star = h;
	}
	public void setDirection(int direction){
		 this.direction = direction ;
	}
	public int get_type(){

		return who;
	}
	public int get_tanknumber (){
		return number_tank ;
	}
	public int get_kill(){
		return kill;
	}
	public int get_strong(){
		return strong ;
	}
	public void set_strong(int dead){
		strong = dead;
	}
	public float get_skill(){
		return skill;
	}
	public int get_numtank(){
		return number_tank;
	}
	//******************************************************************************************************************************
    //�ȸ�����ʲô̹��  Ȼ�������������
	private void tank_getstar(int h_m){
    	switch(who){
    	case 0://��ͨtank
    		
    		switch(h_m){//��������
    		case 0 :
    			strong = 2;
    			
    			speed = 1;
    			break;
    		case 1:
    			strong = 3;
    			
    			speed = 2;
    			break;
    		case 2:
    			strong = 4;
    			
    			speed = 3;
    			break;
    		case 3 :
    			strong = 4;
    			
    			speed = 3;
    		
    			
    			break;
    		}
    		if(h_m>=4){
    			strong = 4;
    			
    			speed = 3;
    			star = 3;
    		}
    		else if(h_m <= 0 ){
    			star=0 ;
    			strong = 2;
    			speed = 1;
    		}
    		
    		
    		break;
    	case 1://fast
    		switch(h_m){//��������
    		case 0 :
    			strong = 2;
    		
    			speed = 2;
    			break;
    		case 1:
    			strong =3;
    			
    			speed= 3;
    			break;
    		case 2:
    			strong = 3;
    			speed = 3;
    			break;
    		case 3 :
    			strong = 3;
    			speed = 3;
    			break;
    		}
    		if(h_m>=4){
    			strong = 3;
    		
    			speed = 3;
    		}
    		else if(h_m <= 0 ){
    			star = 0 ;
    			strong = 2;
    			
    			speed = 2;
    		}
    		break;
    	case 2://strong
    		switch(h_m){//��������
    		case 0 :
    			strong = 3;
    			
    			speed = 1;
    			break;
    		case 1:
    			strong = 4;
    			
    			speed = 1;
    			break;
    		case 2:
    			strong = 4;
    			
    			speed = 2;
    			break;
    		case 3 :
    			strong = 4;
    		
    			speed = 2;
    			break;
    		}
    		if(h_m>=4){
    			strong = 4;
    			
    			speed = 2;
    		}
    		else if(h_m <= 0 ){
    			star = 0 ;
    			strong = 3;
    	
    			speed = 1;
    			
    		}
    	   break;
    		
    	}
    	
    }
	//******************************************************************************************************************************
   
	//******************************************************************************************************************************

	
    //******************************************************************************************************************************
	
	//�� λ�øı����һ˲�����
	private void setMyPosition(float x , float y ){
		
		
		switch(number_tank){
		case 5:
			Constant.enemy_tank1_x = x ;
			Constant.enemy_tank1_y = y ;
			break;
		case 6:
			Constant.enemy_tank2_x = x ;
			Constant.enemy_tank2_y = y ;
		    break;
		}
	}
	
	//������
	public ene_normal_tank( int numbers   ){
	      System.out.println("����ene_normaltank�Ĺ�������");
		  who = -1 ;
		number_tank = numbers ;
		
		if(Constant.S){
			for(int i = 0 ;i < 4; i++){
				
				Attacktank[i] = Constant.resizeImage(initBimap_surfaceview.AttackTank[i], tank_width, tank_height);
				Fasttank[i] = Constant.resizeImage(initBimap_surfaceview.FastTank[i], tank_width, tank_height);
				Strongtank[i] = Constant.resizeImage(initBimap_surfaceview.StrongTank[i], tank_width, tank_height);
				if(number_tank == 2){//��Ϊ��������������playgame�е��ⲿ����ԴҪʹ������
					
					initBimap_surfaceview.AttackTank[i] = Constant.shifang(initBimap_surfaceview.AttackTank[i]);
					initBimap_surfaceview.FastTank[i] = Constant.shifang(initBimap_surfaceview.FastTank[i]);
					initBimap_surfaceview.StrongTank[i] = Constant.shifang(initBimap_surfaceview.StrongTank[i]);
				}
				
				
			}
		}
		else{
			for(int i = 0 ;i < 4; ++i){
				
				
				Attacktank[i] = Constant.resizeImage(initBimap_surfaceview.redAttackTank[i], tank_width, tank_height);
				Fasttank[i] = Constant.resizeImage(initBimap_surfaceview.redFastTank[i], tank_width, tank_height);
				Strongtank[i] = Constant.resizeImage(initBimap_surfaceview.redStrongTank[i], tank_width, tank_height);
				if(number_tank == 2){
					
					initBimap_surfaceview.redAttackTank[i] = Constant.shifang(initBimap_surfaceview.redAttackTank[i]);
					initBimap_surfaceview.redFastTank[i] = Constant.shifang(initBimap_surfaceview.redFastTank[i]);
					initBimap_surfaceview.redStrongTank[i] = Constant.shifang(initBimap_surfaceview.redStrongTank[i]);
				}
				
			}
		}
		normaltank[0] = Attacktank;
		normaltank[1] = Fasttank;
		normaltank[2] = Strongtank;
	  
		explode  = new Explode();
		
		
	}
	//******************************************************************************************************************************
 

	//���ķ���
	public void Drawself(Canvas canvas ,Paint paint ){
		
		
	    if(strong <= 0 && is_live ){//tank����˲��
	   
	    	canmove = false;
				if(
						
						explode.drawexplode(canvas, paint, x, y)//�����Ϊ��
				){
					
						star--;
						star_change = true;//���������иı�
						is_live = false;
						canmove = true;
				
				}
				
			}
		 else{
			 
		
			   
				 if(is_live){   //����
						
						switch (direction){
						   
						case 0:
							canvas.drawBitmap(tank[0], x, y, paint);
							break;
						case 1:
							canvas.drawBitmap(tank[1], x, y, paint);
							break;
						case 2:
							canvas.drawBitmap(tank[2], x, y, paint);
							break;
						case 3:
							canvas.drawBitmap(tank[3], x, y, paint);
							break;
						}
						if(wudi){
							if(
									explode.Drawprotect(canvas, paint, x, y)
							  ){
								wudi  = false ;
							   }
						}
						
					}
					else {    //û�л���
							for_brith(canvas ,paint);
							if(number_tank == 5){
							}
					}
		 }
	    setMyPosition(x,y);
	    
		get_hurt();
		get_reward();
	}
		
	
	//******************************************************************************************************************************
	
	//******************************************************************************************************************************
	//��ȡʣ��ĳ���λ��
/*	private int getsurplus(){
		
		if((Constant.enemy_hero_position  == 0 ||Constant.enemy_tank1_position== 0)&&
				(Constant.enemy_hero_position == 1||Constant.enemy_tank1_position == 1)	){
		    return 2;
		}
		else if((Constant.enemy_hero_position == 0 ||Constant.enemy_tank1_position == 0)&&
				(Constant.enemy_hero_position  == 2 ||Constant.enemy_tank1_position == 2)	){
			return 1;
		}
		else if((Constant.enemy_hero_position  == 1 ||Constant.enemy_tank1_position == 1)&&
				(Constant.enemy_hero_position == 2 ||Constant.enemy_tank1_position == 2)){
			return 0 ;
		}
		return -1;
	}*/
	//******************************************************************************************************************************
	//��ȡ��������
	public int GetwhereamI(){
		int where_  = 0  ;
		switch(number_tank){
		case 5:
			where_  =0;
			break;
		case 6:
			where_ = 2;
			break;
		}
		
		
		
		 //��ʱ��λ�ñ�ס  �����ָ�
	
		
		return where_ ;
	}
	
	
	//******************************************************************************************************************************
	private void getWhoOut(){
		switch(number_tank){
		case 5:
			if(who == -1){
				who  = 1;
			}
			else {
				 who++;
				 who = who%3;//�ܵõ�0,1,2������Ϣ
			}
			tank = (Bitmap[]) normaltank[who];
			break;
		case 6:
			if(who == -1){
				who = 2;
			}
			else{
				who++;
				who = who % 3;
			}
			tank = (Bitmap[]) normaltank[who];
			break;
		}
		    
	 
			
		
		
		//��ͬ��̹�˳��������Բ�ͬ
		switch(who){
		case 0:
			speed = 1;
			strong = 2;
			break;
		case 1:
			speed = 2;
			strong = 2;
			break;
		case 2://strongtank
			strong = 3;
			speed = 1;
			break ;
		}
	}
	//******************************************************************************************************************************

	
	
	
	//******************************************************************************************************************************
	//ײ�˷���true   ûײ�� false   ����Ƿ��tank��ײ
	public boolean crashWithTank(float x , float y,int direction,int which){
		switch(number_tank){
		   
		case 5:
			
			if(
					Constant.pointinarea(x, y, Constant.fri_Hero_x,  Constant.fri_Hero_y, tank_width, tank_height)||
					Constant.pointinarea(x, y, Constant.fri_tank2_x,  Constant.fri_tank2_y, tank_width, tank_height)||
					Constant.pointinarea(x, y, Constant.enemy_Hero_tank_x,  Constant.enemy_Hero_tank_y, tank_width, tank_height)||
					Constant.pointinarea(x, y, Constant.fri_tank1_x,  Constant.fri_tank1_y, tank_width, tank_height)||
					Constant.pointinarea(x, y, Constant.enemy_tank2_x,  Constant.enemy_tank2_y, tank_width, tank_height)
			  ){
					switch(direction){
				    
				    case 0 :
				    	if(which == 1){
				    		 x += 2;
				    	}
				    	else if(which == 2){
				    		x -= 2;
				    	}
				    	y -= 2;
				    	break;//��ֹ�ص����ܶ�
				    case 1:
				    	
				    	if(which == 1){ x += 2;}
				    	else if(which == 2){x -= 2;}
				    		y += 2;
				    	break;
				    case 2:
				    	
				    	if(which == 1){y += 2;}
				    	
				    	else if(which == 2){y -= 2;}
				    	x -= 2;
				    	break;
				    case 3:
				    	
				    	if(which == 1){y+=2;}
				    	else if(which == 2){y-=2;}
				    	 
				    	x += 2;
				    	break;
				    }
				if(
						Constant.pointinarea(x, y, Constant.fri_Hero_x,  Constant.fri_Hero_y, tank_width, tank_height)||
						Constant.pointinarea(x, y, Constant.fri_tank2_x,  Constant.fri_tank2_y, tank_width, tank_height)||
						Constant.pointinarea(x, y, Constant.enemy_Hero_tank_x,  Constant.enemy_Hero_tank_y, tank_width, tank_height)||
						Constant.pointinarea(x, y, Constant.fri_tank1_x,  Constant.fri_tank1_y, tank_width, tank_height)||
						Constant.pointinarea(x, y, Constant.enemy_tank2_x,  Constant.enemy_tank2_y, tank_width, tank_height)
				  ){//��������ײ����ô��û���ˡ���
					return true;
						
			     	
				  }
						
			   }
			return false;
		case 6:
			if(
					Constant.pointinarea(x, y,  Constant.fri_Hero_x,  Constant.fri_Hero_y, tank_width, tank_height)||
					Constant.pointinarea(x, y,  Constant.fri_tank1_x,  Constant.fri_tank1_y, tank_width, tank_height)||
					Constant.pointinarea(x, y,  Constant.enemy_Hero_tank_x,  Constant.enemy_Hero_tank_y, tank_width, tank_height)||
					Constant.pointinarea(x, y,  Constant.enemy_tank1_x,  Constant.enemy_tank1_y, tank_width, tank_height)||
					Constant.pointinarea(x, y,  Constant.fri_tank2_x,  Constant.fri_tank2_y, tank_width, tank_height)
			  ){
				
				
				switch(direction){
			    
			    case 0 :
			    	if(which == 1){
			    		 x += 2;
			    	}
			    	else if(which == 2){
			    		x -= 2;
			    	}
			    	
			    	y -= 2;
			    	break;
			    case 1:
			    	
			    	if(which == 1){ x += 2;}
			    	else if(which == 2){x -= 2;}
			    	y += 2;
			    	break;
			    case 2:
			    	
			    	if(which == 1){y += 2;}
			    	
			    	else if(which == 2){y -= 2;}
			    	x -= 2;
			    	break;
			    case 3:
			    	if(which == 1){y+=3;}
			    	else if(which == 2){y-=2;}
			    	x += 2;
			    	break;
			    }
			if(
					Constant.pointinarea(x, y, Constant.fri_Hero_x,  Constant.fri_Hero_y, tank_width, tank_height)||
					Constant.pointinarea(x, y, Constant.fri_tank1_x,  Constant.fri_tank1_y, tank_width, tank_height)||
					Constant.pointinarea(x, y, Constant.enemy_Hero_tank_x,  Constant.enemy_Hero_tank_y, tank_width, tank_height)||
					Constant.pointinarea(x, y, Constant.enemy_tank1_x,  Constant.enemy_tank1_y, tank_width, tank_height)||
					Constant.pointinarea(x, y, Constant.fri_tank2_x,  Constant.fri_tank2_y, tank_width, tank_height)
			  ){
				
				
			         return true;
			   }
				
					
						
			   }
		return false;
		}
		return false;
	}
	                             
	//******************************************************************************************************************************
	//�ж�ǰ���Ƿ����ߡ�������������true ���ߡ���false������
	
	
	private boolean Cango(int direction){
	    boolean point_1,point_2,point_3,flag=true;
	   
	    if(canmove && !Constant.stop_union_ene()){
	    	switch(direction){
			   
			   case 0: //��
				   
				   
				   if(y <= Constant.Display_height)//�����ϱ߽�
					   {
					       flag = false;
					     
					   }
				      
					   point_1=Boundary.tankInMap(x,y,1,this);//���Ͻ�
					   point_2=Boundary.tankInMap(x+(tank_width/2),y,0,this);//�е�
					   point_3=Boundary.tankInMap(x+tank_width, y,2,this);
					   
					   
					   if(point_2||point_1||point_3){  //�������㲻��ͨ����flag��Ϊ��
						   flag = false;
					     }
					   
					   
					if(crashWithTank(x,y,direction,1)||
					   crashWithTank(x+tank_width, y,direction,2)){  //������Ϊ��Ͳ���ͨ��
						flag = false;
					}
				break;
						  
				   
			   case 1://��
				   if(y > Constant.Screen_Y-tank_height)//û�г����±߽�
				   {
					   flag = false;
					
				   }
				  
				   
				   point_1=Boundary.tankInMap(x,y+tank_height,1,this);//���Ͻ�
				   point_2=Boundary.tankInMap(x+(tank_width/2),y+tank_height,0,this);//�е�
				   point_3=Boundary.tankInMap(x+tank_width, y+tank_height,2,this);
				   
				   if(point_2||point_1||point_3){  //�������㲻��ͨ����flag��Ϊ��
					   flag = false;
				     }
				   
				   
				   if(crashWithTank(x,y+tank_height,direction,1)||
						   crashWithTank(x+tank_width, y+tank_height,direction,2)){  //������Ϊ��Ͳ���ͨ��
							flag = false;
					}
				   
				break;
				   
				   
			   case 2://��
				   if(x < Constant.Operate_width)//û�г����ϱ߽�
				   {
				       flag = false;
				   }
				   
				   point_1=Boundary.tankInMap(x,y,1,this);//���Ͻ�
				   point_2=Boundary.tankInMap(x,y+(tank_height/2),0,this);//�е�
				   point_3=Boundary.tankInMap(x, y+tank_height,2,this);
				  
				   if(point_2||point_1||point_3){  //�������㲻��ͨ����flag��Ϊ��
					   flag = false;
				     }
				   
				   if(crashWithTank(x,y,direction,1)||
						   crashWithTank(x, y+tank_height,direction,2)){  //������Ϊ��Ͳ���ͨ��
							flag = false;
					}
				 break;
				  
				  
			   case 3://��
				   
				   
				   if(x >= Constant.Screen_X-tank_width)//û�г����ϱ߽�
				   {
				       flag = false;
				   }
				   
				   point_1=Boundary.tankInMap(x+tank_width,y,1,this);//���Ͻ�
				   point_2=Boundary.tankInMap(x+tank_width,(y+(tank_height/2)),0,this);//�е�
				   point_3=Boundary.tankInMap(x+tank_width, y+tank_height,2,this);
				   
				   if(point_2||point_1||point_3){  //�������㲻��ͨ����flag��Ϊ��
					   flag = false;
				     }
				   
				   
				   
				   if(crashWithTank(x+tank_width,y,direction,1)||
						   crashWithTank(x+tank_width, y+tank_height,direction,2)){  //������Ϊ��Ͳ���ͨ��
							flag = false;
				   }
				  break;
			   }
	    	 return flag ;
	    }
	    
		   
		  return false;
	   }
	  
	
	//******************************************************************************************************************************
	public void go(){
		
		
		if(Cango(direction)){
				switch(direction){
			case 0:
				y -= speed ;
				break;
			case 1:

				y += speed;
				break;
			case 2:

				x -= speed;
				break;
			case 3:

				x+= speed;
				break;
				
			}
		}
		else{
			
		}
	}
	
	//******************************************************************************************************************************
	//���� ����տ�ʼ��ʱ��̹�˵ĳ���
	private void for_brith(Canvas canvas ,Paint paint){
		//�ж��ǿͻ��˻��Ƿ����
		
		wudi = true;
		tank_getstar(star);
		getWhoOut();
		if(where == -1){
			where = GetwhereamI();
		}
		
		if(Constant.S){
			
			direction = 0 ;
			if( !is_live){  // ������  
				
				
				switch(where){
				
				case 0://�����
					
					  y = Constant.Screen_Y-tank_height;
					  x = Constant.get_game_map_left();
					  canvas.drawBitmap(tank[0], x, y, paint);
					  break;
				case 1:
					
					  y = Constant.Screen_Y-tank_height;
					  x = Constant.get_game_map_center()+tank_width;
					  canvas.drawBitmap(tank[0], x, y, paint);
					  break;
				case 2:
					
					  y = Constant.Screen_Y-tank_height;
					  x = Constant.get_game_map_right()-tank_width;
					  canvas.drawBitmap(tank[0], x, y, paint);
					  break;
				}
				
			
			is_live = true;
			}
		 
		}
		else{
			if( !is_live){  // ������  
				direction = 1 ;
				switch(where){
				case 0://�����
					
					  y=Constant.Display_height;
					  x=Constant.get_game_map_left();
					  canvas.drawBitmap(tank[1], x, y, paint);
					  break;
				case 1:
					  y=Constant.Display_height;
					  x = Constant.get_game_map_center();
					  canvas.drawBitmap(tank[1], x, y, paint);
					  break;
				case 2:
					  y=Constant.Display_height;
					  x = Constant.get_game_map_right()-tank_width ;
					  canvas.drawBitmap(tank[1], x, y, paint);
					  break;
				}
			
			    is_live = true;
			}
			 
			
		}
		where = -1;
		canmove = true;
	}
	//*************************************************************************************************************************
	 private void get_hurt(){
		 
	    	if(Constant.checkcrash(x, y,tank_width, tank_height,
	                Constant.fri_hero_bullet_x1, Constant.fri_hero_bullet_y1, Constant.bullet_size, Constant.bullet_size)||
	        Constant.checkcrash(x, y,tank_width, tank_height,
	    	        Constant.fri_hero_bullet_x2, Constant.fri_hero_bullet_y2, Constant.bullet_size, Constant.bullet_size)){
		    		
		    		if(wudi)  
		    		{
					    		switch(number_tank){
					    			case 5:
					    				   Constant.ene_tank1_hurted = true;
					    				break;
					    			case 6:
					    				   Constant.ene_tank2_hurted = true;
					    			    break;
					    			   }
					    		
		    	    }
		    		
		    	else{
					    		switch(number_tank){
							    			case 5:
							    				   Constant.ene_tank1_hurted = true;
							    				break;
							    			case 6:
							    				   Constant.ene_tank2_hurted = true;
							    			    break;
				    			                  }
		    			--strong;
		    			if(strong == 0 ){
		    				Constant.fri_hero_kill++;
		    			}
		    	    }
	    		
	    	}
	 else if(//�ж��ǲ��Ǻ͵з��ӵ���ײ
	    			
	    	    	Constant.checkcrash(x, y,tank_width, tank_height,
	    	    	    	Constant.fri_tank1_bullet_x1, Constant.fri_tank1_bullet_y1, Constant.bullet_size, Constant.bullet_size)||
	    	       	Constant.checkcrash(x, y,tank_width, tank_height,
	    	    	    	Constant.fri_tank1_bullet_x2, Constant.fri_tank1_bullet_y2, Constant.bullet_size, Constant.bullet_size)||
	    	    	Constant.checkcrash(x, y,tank_width, tank_height,
	    	    	    	 Constant.fri_tank2_bullet_x1, Constant.fri_tank2_bullet_y1, Constant.bullet_size, Constant.bullet_size)||
	    	    	Constant.checkcrash(x, y,tank_width, tank_height,
	    	    	    	 Constant.fri_tank2_bullet_x2, Constant.fri_tank2_bullet_y2, Constant.bullet_size, Constant.bullet_size)
	    	    	    	    	   	  
	         
	    	){
	    		if(wudi)  
	    		{
				    		switch(number_tank){
				    			case 5:
				    				   Constant.ene_tank1_hurted = true;
				    				break;
				    			case 6:
				    				   Constant.ene_tank2_hurted = true;
				    			    break;
				    			   }
				    		
	    	    }
	    		
	    	else{
				    		switch(number_tank){
						    			case 5:
						    				   Constant.ene_tank1_hurted = true;
						    				break;
						    			case 6:
						    				   Constant.ene_tank2_hurted = true;
						    			    break;
			    			                  }
	    			--strong;
	    	    }
	    		    
	    	 }
	    	
	    	else if(
	    			Constant.checkcrash(x, y,tank_width, tank_height,
	    	                Constant.fri_landmine_position_x, Constant.fri_landmine_position_y, Constant.tank_width, Constant.tank_height)
	    			){
				    		Constant.fri_landmine_eated = true;
				    		if(wudi)  ;
				    		else {
				    			Constant.fri_hero_kill++;
				    			strong = 0 ;
				    		}
	    	        	
	    	        }
	    	
	    	else if(
	    			Constant.fri_get_bomb 
	    			){
	    		           // Constant.fri_get_bomb = false;
				    		if(wudi) ;
				    		else strong -- ;
	    		
	    	        }
	    	else if(Constant.ene_tank1_jian || Constant.ene_tank2_jian){
	    		switch(number_tank){
	    		case 5:
	    			if(Constant.ene_tank1_jian){
	    				strong -- ;
	    				Constant.ene_tank1_jian = false;
	    			}
	    			break;
	    		case 6:
	    			if(Constant.ene_tank2_jian){
	    				strong -- ;
	    				Constant.ene_tank2_jian = false;
	    			}
	    			break;
	    		}
	    	}
	    }
	 //********************************************************************************************************************************
	 private void get_reward(){
	    	
	    	if(
	    			Constant.checkcrash(x, y, tank_width, tank_height,
	    					Constant.reward_position_x, Constant.reward_position_y, tank_width, tank_width)
	    	  ){
	    		switch((int)Constant.reward){
	    		  
	    		case 0 ://ȫ��ը
	    			Constant.fri_get_bomb = true;
	    			break ;
	    		case 1://�޵�
	    			wudi = true;
	    			break;
	    		case 2:
	    		//	life ++;
	    			break;
	    		case 3:
	    			Constant.stop_fri_tank = true;
	    			break;
	    			
	    		case 4://��ס�Է�
	    			star++;
	    			tank_getstar(star);
	    			break;
	    		case 5://����
	    			star = 3;
	    			tank_getstar(star);
	    			break;
	    		
	    			
	    		}
	    		Constant.reward_eated  = true;
	    	}
	    }
}
