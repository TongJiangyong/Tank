package com.entity;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;

import com.SurfaceView.initBimap_surfaceview;
import com.tools.Constant;

/**
 * ������   ÿ��60��  Ȼ�������λ�÷�һ��������
 * @author Administrator
 *
 */
public class reward {
      public static int bomb = 0 , protector = 1, life = 2, timer = 3 , star = 4, shovel = 5;
      private int time =  50 ,which;
	  private Bitmap[] award ;
      private static boolean eat = true;  
      private float x, y ;
	  private boolean just_drawone = true;
	  private long rem_time;
      public reward(){
    	  
    	  award = new Bitmap[initBimap_surfaceview.reward_.length];
    	  for(int i = 0 ;i < award.length ; i++){
    		  award[i] = Constant.resizeImage( initBimap_surfaceview.reward_[i], Constant.tank_width, Constant.tank_width);
    		  initBimap_surfaceview.reward_[i] = Constant.shifang(initBimap_surfaceview.reward_[i]);
    	  }
    	  
      }
      
 public void Drawself(Canvas canvas , Paint paint ){
    	  
    	  if(Constant.C){//ֻ���ڰ��ͻ��˻��ƽ�������Ȼ��λ����Ϣ��������ˡ�����������ͳһ
    		  
    		  if(Boundary.get_now_time() % time == 0 && just_drawone){
    			  just_drawone = false;
    			  rem_time = Boundary.get_now_time() ;
        		  which = Constant.Random(award.length);
        		  x = Constant.Random(Constant.Screen_X);
        		  
        		  if(x <= Constant.Operate_width){
        			  x+= Constant.Operate_width;
        					  
        		  }
        		  if((x+Constant.tank_width) >= Constant.Screen_X){
        			  x= Constant.Screen_X - Constant.tank_width;
        		  }
        		  y =  Constant.Random(Constant.Screen_Y);
        		  
        		  if(y <= Constant.Display_height){
        			  y += Constant.Display_height;
        		  }
        		  if((y+Constant.tank_height) >= Constant.Screen_Y){
        			  y = Constant.Screen_Y - Constant.tank_height;
        		  }
        		  Constant.reward_position_x = x;
        		  Constant.reward_position_y = y ;
        		  Constant.reward = which ;
        		  Deal_Bluetooth_Info.changed_reward();
        		  eat = false;
        		  canvas.drawBitmap(award[which], x, y, paint);
        	  }
        	  eated();//����ǲ��Ǳ��Ե�
        	  if(!eat){//���û�б��� ������
        		  canvas.drawBitmap(award[which], x, y, paint);
        		 
        	  }
    	  }
    	 if(Boundary.get_now_time() % (rem_time+1) == 0){
    		 just_drawone = true;
    	 }
      }
	public void Draw_S(Canvas canvas,Paint paint){
		if(Constant.S){
			
			eated();
			if(Constant.reward != -1){
				 canvas.drawBitmap(award[(int) Constant.reward ], Constant.reward_position_x, 
						           Constant.reward_position_y, paint);
				
			}
		}
		
	}
	
	private void eated(){//�ж��Ƿ񱻳Ե�
		
		if(
				Constant.reward_eated 
														
		  ){
			eat = true;
			Constant.reward_eated  = false;
			 Constant.reward_position_x = 0;
   		     Constant.reward_position_y = 0 ;
   		     Constant.reward = -1;
		  }
		
	}
	
}































