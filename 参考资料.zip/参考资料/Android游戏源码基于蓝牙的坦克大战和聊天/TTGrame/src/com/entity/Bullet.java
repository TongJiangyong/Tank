package com.entity;


import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;

import com.SurfaceView.initBimap_surfaceview;
import com.tools.Constant;

/**
 * �����ӵ���  
 * @author Administrator
 *
 */
public class Bullet {
	 // == 1 �ⷢ�ӵ�ֻ�ܵ���tank��һ��strong  ==2 ����һ�ν����ͨtank
     private int attack = 1;
     //��ͨ�ӵ� ��2��5���ٶ� ���������� ����3.5���ٶ�
     private float speed = (float)(2.5*Constant.Screen_Y)/480;
     //�ܻ���stone�
     private boolean can_stone = false;
     // 0 ��ͨͨtank 1 fast  2 strong  3hero
     private int tank_type   ;
     //�Ƿ��оŹ���Ľ���Ч��
     private boolean can_spatter = false ;
     //һ�����ܷ��伸���ӵ� if ==2 ��ô����Ļ�ϵ������ ���ܷ��������ӵ�  ���ǵ�һ�λ���ֻ����һ���ӵ�
     public int can_shoot_h = 1;
     private boolean can_shoot = false;
    
     private Tank tank ;
     private Bitmap bullet,bullet2  ;
     //�Ѿ�����ӵ� ��ôflyΪtrue
     public  boolean flying = false,flying2= false;//�ж��ӵ��Ƿ��ڽ����л�û��ʧ
     private float x1=-1 ,y1=-1,x2=-1,y2=-1 ; //�ӵ��ľ������� ,��Ϊ���Է�����������Ҫ��������
     //�����ӵ��ķ��� 0 shang  1xia 2zuo 3you
     private int my_direction  ;
     int count = 0 ;
   //********************************************************************************************************************************  
     // ����tank������ӵ�ͼƬ��
     public Bullet(Tank tank, Boundary face  ){
    	 
    	this.tank =tank ;
    	
    	
    	this.tank_type = tank.get_type();
    	bullet = initBimap_surfaceview.NormalBullet;
    	
    	this.bullet2 = initBimap_surfaceview.NormalBullet ;
    	Constant.bullet_size = bullet.getHeight();// ���ӵ��Ĵ�С��ֵ ����Ϊ�����������Բ��������Ĵ���

     }
     //********************************************************************************************************************************
     public float get_x1(){
    	 return x1;
     }
     public float get_y1(){
    	 return y1;
     }
     public float get_x2(){
    	 return x2;
     }
     public float get_y2(){
    	 return y2;
     }
     public void set_x1(float x){
    	 x1 = x ;
     }
     public void set_x2(float x){
    	 x2 = x ;
     }
     public void set_y1(float y){
    	 y1 = y ;
     }
     public void set_y2(float y){
    	 y2 = y ;
     }
     public void shoot(){
    	 can_shoot= true;
     }
    public void clear_position1(){//����������ϰ���֮��Ȼ��ָ��ӵ���λ��
    	 	switch(tank.get_numtank()){
     	 
     	
     	 case 1:
     		 if(!flying){
     			    Constant.fri_tank1_bullet_x1 = -1;
		    		Constant.fri_tank1_bullet_y1 = -1;
		    		x1 = -1; y1 = -1 ;
     		 }
     		 
 			    		
 			    		
     		 break;
     	 case 2:
     		 if(!flying){
     			  Constant.fri_tank2_bullet_x1 = -1;
			      Constant.fri_tank2_bullet_y1 = -1;
			    		x1 = -1; y1 = -1 ;
     		 }
     		 	   
			    		
			    		 
     		 break;
     	 case 3://hero
     		 
             if(!flying){
     			  Constant.fri_hero_bullet_x1 = -1;
     		      Constant.fri_hero_bullet_y1 = -1;
     		     
     		      x1 = -1; y1 = -1 ; 
     		 }
     		 
     		               
     		               
     		              
     		 break;
     	 case 4://enemy_hero
     		 
             if(!flying){
     			 Constant.enemy_hero_bullet_x1 = -1;
 			     Constant.enemy_hero_bullet_y1 = -1;
 			        		x1 = -1; y1 = -1 ;
     		 }
     		 
 			        		
 			        		
 			    		 
     		 break;
		 case 5:
			 
			 if(!flying){
     			 Constant.enemy_normal1_bullet_x1 = -1;
			     Constant.enemy_normal1_bullet_y1 = -1; 
			    		 x1 = -1; y1 = -1 ;
     		 }
     		 
			    		 
			    		
			    		 
			break;
		case 6:
			
			if(!flying){
			
     			  Constant.enemy_normal2_bullet_x1 = -1;
			      Constant.enemy_normal2_bullet_y1 = -1;
			      x1 = -1; y1 = -1 ;
     		 }
     		
			    		
			    		
			break;
     	 }
     }
    
    
    public void clear_position2(){
    	
    	switch(tank.get_numtank()){
    	 
     	
    	 case 1:
    		
    		 if(!flying2){
    			    Constant.fri_tank1_bullet_x2 = -1;
		    		Constant.fri_tank1_bullet_y2 = -1;
		    		x2 = -1 ; y2 = -1;
    		 }
			    		
			    		
    		 break;
    	 case 2:
    		
    		 if(!flying2 ){
    			 Constant.fri_tank2_bullet_x2 = -1;
			     Constant.fri_tank2_bullet_y2 = -1;
			    		x2 = -1 ; y2 = -1;
    		 }
		     		   
			    		
			    		 
    		 break;
    	 case 3://hero
    		 
           
    		 if(!flying2){
    			  Constant.fri_hero_bullet_x2 = -1;
    		      Constant.fri_hero_bullet_y2 = -1;

    		      x2 = -1 ; y2 = -1;
    		 }
    		               
    		               
    		              
    		 break;
    	 case 4://enemy_hero
    		 
            
    		 if(!flying2){
    			   Constant.enemy_hero_bullet_x2 = -1;
			       Constant.enemy_hero_bullet_y2 = -1;
			        		 x2 = -1 ; y2 = -1;
    		 }
			        		
			        		
			    		 
    		 break;
		 case 5:
			
    		 if(!flying2){
    			  Constant.enemy_normal1_bullet_x2 = -1;
			      Constant.enemy_normal1_bullet_y2 = -1;
			    		 x2 = -1 ; y2 = -1;
    		 }
			    		 
			    		
			    		 
			break;
		case 6:
			
			
    		 if(!flying2){
    			  Constant.enemy_normal2_bullet_x2 = -1;
			      Constant.enemy_normal2_bullet_y2 = -1;
			    		  x2 = -1 ; y2 = -1;
    		 }
			    		
			    		
			break;
    	 }
    }
    //*********************************************************************************************************************************
     public void set_position(){
    		switch(tank.get_numtank()){
        	 
         	
        	 case 1:
    			    		Constant.fri_tank1_bullet_x1 = x1;
    			    		Constant.fri_tank1_bullet_y1 = y1;
    			    		Constant.fri_tank1_bullet_x2 = x2;
    			    		Constant.fri_tank1_bullet_y2 = y2;
        		 break;
        	 case 2:
		   		     		    Constant.fri_tank2_bullet_x1 = x1;
		   			    		Constant.fri_tank2_bullet_y1 = y1;
		   			    		Constant.fri_tank2_bullet_x2 = x2;
		   			    		Constant.fri_tank2_bullet_y2 = y2;
        		 break;
        	 case 3://hero
        		                Constant.fri_hero_bullet_x1 = x1;
        		                Constant.fri_hero_bullet_y1 = y1;
        		                Constant.fri_hero_bullet_x2 = x2;
        		                Constant.fri_hero_bullet_y2 = y2;
        		 break;
        	 case 4://enemy_hero
        		 
    			        		Constant.enemy_hero_bullet_x1 = x1;
    			        		Constant.enemy_hero_bullet_y1 = y1;
    			        		Constant.enemy_hero_bullet_x2 = x2;
    			        		Constant.enemy_hero_bullet_y2 = y2;
    			    		 
        		 break;
        	 case 5:
				        		 Constant.enemy_normal1_bullet_x1 = x1;
				        		 Constant.enemy_normal1_bullet_y1 = y1;
				        		 Constant.enemy_normal1_bullet_x2 = x2;
				        		 Constant.enemy_normal1_bullet_y2 = y2;
        		 break;
        	 case 6:
				        		 Constant.enemy_normal2_bullet_x1 = x1;
				        		 Constant.enemy_normal2_bullet_y1 = y1;
				        		 Constant.enemy_normal2_bullet_x2 = x2;
				        		 Constant.enemy_normal2_bullet_y2 = y2;
        		 break;
        	 }
     }
     
   //********************************************************************************************************************************
     public void Drawself(Canvas canvas,Paint paint){
    	
    	 if(can_shoot){
    		
        	 how_to_go();
        	 set_position();
	    		 if(can_shoot_h==1){//����һö�ӵ�
	    		    	
	        		 if(!flying){
	        			get_bullet(); //����ܷ������ơ��������ȡ�������ӵ�
	        			
	        	     }
	        		 canvas.drawBitmap(bullet, x1,y1, paint);
	        	 }
	        	 
	        	 else if(can_shoot_h == 2){//������ö�ӵ�
	        		//�����ӵ�����ʧ��ʱ��������ӵ�
	        		 if(!flying && !flying2){
	        			 
	        			 get_bullet();
	        		 }
	        		
	        		 if(flying&&!flying2){//ֻ���ӵ�һ�ڷ�
	        			 canvas.drawBitmap(bullet, x1,y1, paint); 
	        		 }
	        		 else if (!flying && flying2){//ֻ���ӵ����ڷ�
	        			 canvas.drawBitmap(bullet2, x2, y2, paint); 
	        		 }
	        		 else if(flying && flying2){//�����ӵ�һ���
	        			 canvas.drawBitmap(bullet2, x2, y2, paint);
	        			 canvas.drawBitmap(bullet, x1,y1, paint);
	        		 }
	        		  
	        	 }
    	}
    	// go();
    	 
     }
     //********************************************************************************************************************************
     public void get_bullet(){
    	 if(!flying){
    		 
    		 switch(tank.get_direction()){
        	 case 0:
        		 x1 = tank.get_x()+(tank.get_tanksize()/2)-5;
        		 y1 = tank.get_y();
        		 my_direction = 0 ;
        		 break;
        	 case 1:
        		 x1 = tank.get_x()+(tank.get_tanksize()/2)-5;
        		 y1 = tank.get_y()+tank.get_tanksize();
        		 
        		 my_direction = 1 ;
        		 break;
        	 case 2:
        		 x1 = tank.get_x();
        		 y1 = tank.get_y()+(tank.get_tanksize()/2)-5;
        		 
        		 my_direction = 2 ;
        		 break;
        	 case 3:
        		 x1 = tank.get_x()+tank.get_tanksize();
        		 y1 = tank.get_y()+(tank.get_tanksize()/2)-5;
        		 
        		 my_direction = 3 ;
        		 break;
        	 }
    		 flying = true;//�ӵ��Ѿ��ڽ�������
    	 }
    	
    	 
    	 
    	 
    	 if(can_shoot_h == 2 && !flying2){
	    		 switch(tank.get_direction()){
	        	 case 0:
	        		 x2 = tank.get_x()+((float)(tank.get_tanksize()/2.0))-5;
	        		 y2 = tank.get_y()+((float)(tank.get_tanksize()/2.0));
	        		 my_direction = 0 ;
	        		 break;
	        	 case 1:
	        		 x2 = tank.get_x()+((float)(tank.get_tanksize()/2.0))-5;
	        		 y2 = tank.get_y()-((float)(tank.get_tanksize()/2.0))+tank.get_tanksize();
	        		 
	        		 my_direction = 1 ;
	        		 break;
	        	 case 2:
	        		 x2 = tank.get_x()+((float)(tank.get_tanksize()/2.0));
	        		 y2 = tank.get_y()+((float)(tank.get_tanksize()/2.0))-5;
	        		 
	        		 my_direction = 2 ;
	        		 break;
	        	 case 3:
	        		 x2 = tank.get_x()-((float)(tank.get_tanksize()/2.0))+tank.get_tanksize();
	        		 y2 = tank.get_y()+((float)(tank.get_tanksize()/2.0))-5;
	        		 
	        		 my_direction = 3 ;
	        		 break;
	        	 }
        	 flying2=true;
    	 }
    	 
    	 
     }
 //********************************************************************************************************************************
     public void go(){
    	
	    	if(flying){
		    		if(Cango(x1,y1)){
		       		
			    		  switch(my_direction){
			    		  
						    	 case 0 :
						    		 y1 -= speed;
						    		
						    		 break;
						    	 case 1:
						    		 y1 += speed;
						    		
						    		 break;
						    	 case 2:
						    		 x1 -= speed;
						    		
						    		 break;
						    	 case 3:
						    		 x1 += speed;
						    		
						    		 break;
			    	      }
			    		  
			          }
                  else{//������������ӵ���ʧ
                	  
                	  if(can_shoot_h != 2){
                		  can_shoot = false;
                	  }
                	  
                	      flying = false;
		  		          clear_position1();
                	  
		  		    
		  	      }
    	}
    	 
	    	
    	 
    		 if(flying2 && can_shoot_h == 2){
		    			 if(Cango(x2,y2)){
		        			 
			    			 switch(my_direction){
			    			 
					    	 case 0 :		
					    		 y2 -= speed;
					    		 break;
					    	 case 1:
					    		 y2 += speed;
					    		 break;
					    	 case 2:
					    		 x2 -= speed;
					    		 break;
					    	 case 3:
					    		 x2 += speed;
					    		 break;
					    		 
				          }
		    	     }
		    		 
		    		  else{
		    			
		    			
		    			       can_shoot = false;
		    			      
		   	    		       flying2 = false;
		   	    		       clear_position2();
		   	    		       
		   	    		  }
    		 }
    		 
      
	    	
    	
     }
   //********************************************************************************************************************************   
    //�ӵ��Ƿ���ߡ��������߷���false
     private boolean Cango(float x,float y){
    	 
    	
    	boolean flag = true;
    	if(//�Ƿ��ڵ�ͼ��Ե
    			x >= Constant.Screen_X||x < Constant.Operate_width|| y >= Constant.Screen_Y ||y <= Constant.Display_height
    	 ){
    		//clear_position();//ײ��ǽ�����λ��
    		flag = false;
    	}
    	else if( !Boundary.bulletInMap(x, y,bullet.getWidth(),bullet.getHeight(), can_stone,my_direction)){//�ж��Ƿ��ǽ��  ��ײ
    		
    		//clear_position();//ײ����ͼ���λ��
    		flag= false;
    	}
    	else if(shoot_enemy(x,y,bullet.getWidth(),bullet.getHeight())){//�Ƿ���Ƶ��ط�̹��
    		
    		flag= false;
    	}
    	else if(//�Ƿ�͵ط��ӵ�����?
    			
    			crashWithEnemybullet(x,y)
    	){
    		
    		flag = false ;
    	}
      
    	return flag ;
    	
     }
     //********************************************************************************************************************************   
     private void how_to_go(){
    	 //����ʲô̹��Ȼ�������������  Ȼ�����ж���ô��
    	  switch(tank.get_numtank()){
     	 
    	  case 1:
    	  case 2:
    	  case 5:
    	  case 6:
               switch(tank.get_type()){
               case 0 ://��̹ͨ��
		    		 switch(tank.get_star()){//�ж���������
		        	 case 0 :
		        		 speed = 2*2;
		        		 can_shoot_h  = 1;
		        		 can_stone = false;
		        		 break;
		        	 case 1:
		        		can_shoot_h  = 1;
		        		 can_stone = false;
		        		 speed = 2*2;
		        		 break;
		        	 case 2:
		        		 can_stone = false;
		        		 speed =3*2;
		        		 can_shoot_h  = 2;
		        		 break;
		        	 case 3:
		        		 speed = 3*2;
		        		 can_shoot_h = 2;
		        		 can_stone = true;
		        		 break;
		        	 }
		    		 if(tank.get_star()>= 4){
		    			tank.set_star(3);
		    			 speed = 3*2;
		        		 can_shoot_h = 2;
		        		 can_stone = true;
		    		 }
		    		 if(tank.get_star() <= 0 ){
		    			 speed = 2*2;
		        		 can_shoot_h  = 1;
		        		 can_stone = false;
		    		 }
   		        break;
   	            case 1://fast
			    		 switch(tank.get_star()){
			        	 case 0 :
			        		 speed = 2*2;
			        		can_shoot_h  = 1;
			        		can_stone = false;
			        		 break;
			        	 case 1:
			        		can_shoot_h  = 1;
			        		can_stone = false;
			        		 speed =3*2;
			        		 break;
			        	 case 2:
			        		 speed = 3*2;
			        		 can_shoot_h  = 2;
			        		 can_stone = false;
			        		 break;
			        	 case 3:
			        		 speed = 3*2;
			        		 can_shoot_h = 2;
			        		 can_stone = true;
			        		 break;
			        	 }
			    		 if(tank.get_star()>= 4){
			    			tank.set_star(3);
			    			 speed =3*2;
			        		 can_shoot_h = 2;
			        		 can_stone = true;
			    		 }
			    		 if(tank.get_star() <= 0){
			    			 speed = 2*2;
				        		can_shoot_h  = 1;
				        		can_stone = false;
			    		 }
   		            break;
   	                case 2://strong
			    		 switch(tank.get_star()){
			        	 case 0 :
			        		 speed =2*2;
			        		can_shoot_h  = 1;
			        		can_stone = false;
			        		 break;
			        	 case 1:
			        		 can_stone = false;
			        		can_shoot_h  = 1 ;
			        		 speed = 2*2;
			        		 break;
			        	 case 2:
			        		 can_stone = false;
			        		 speed = 2*2;
			        		 can_shoot_h  = 2;
			        		 break;
			        	 case 3:
			        		 speed = 3;
			        		 can_shoot_h = 2;
			        		 can_stone = true;
			        		 break;
			        	 }
			    		 if(tank.get_star()>= 4){
			    			tank.set_star(3);
			    			 speed = 3;
			        		 can_shoot_h = 2;
			        		 can_stone = true;
			    		 }
			    		 if(tank.get_star() <= 0){
			    			 
			    			 speed =2;
				        		can_shoot_h  = 1;
				        		can_stone = false;
			    		 }
   		            break;
   	               
                  }
                  break;
                  
                  
     	 case 3://hero
     	 case 4:
     		 bullet = initBimap_surfaceview.HeroBullet;
     		 //bullet2 = initBimap_surfaceview.HeroBullet;
     		bullet2 = initBimap_surfaceview.NormalBullet;
 			    		 switch(tank.get_star()){
 			        	 case 0 :
 			        		
 			        		 speed = 2;
 			        		 can_shoot_h  = 1;
 			        		 can_stone = false;
 			        		 break;
 			        	 case 1:
 			        		
			        		 can_shoot_h  = 1;
 			        		 speed = 3*2;
 			        		 can_stone = false;
 			        		 break;
 			        	 case 2:
 			        		 
 			        		 speed =3*2;
 			        		 can_shoot_h  = 2;
 			        		 can_stone = false;
 			        		 break;
 			        	 case 3:
 			        		 speed = 4*2;
 			        		 
 			        		 can_shoot_h = 2;
 			        		 can_stone = true;
 			        		 break;
 			        	 }
 			    		 if(tank.get_star()>= 4){
 			    			tank.set_star(3);
 			    			 speed =4*2;
 			    			
 			        		 can_shoot_h = 2;
 			        		 can_stone = true;
 			    		 }
 			    		 if(tank.get_star() <= 0){
 			    			 speed = 2*2;
			        		 can_shoot_h  = 1;
			        		 can_stone = false;
			        		 
			        		 break;
 			    		 }
     		 break;
     	
     	 }
     	 
      }
     //********************************************************************************************************************************   

     //�ж��Ƿ�������ط�̹�ˡ���������� �ӵ���ʧ tank��ը  ������˾�Ϊtrue  û��false   tank_type = 4,5,6�ı������ǡ�����tank��
    private boolean shoot_enemy(float x , float y , float w, float h ){
    	 if(tank.get_numtank() == 4 || tank.get_numtank() == 5 || tank.get_numtank() == 6){//���ǵط����ӵ�
    		
    		 if(//�ж��ӵ���˭�ˡ���Ȼ����tank���ر����е���Ϣ����������ӵ�λ��
    				 Constant.checkcrash(x, y, w, h, 
 	    					 Constant.fri_Hero_x, Constant.fri_Hero_y, tank.get_tanksize(),  tank.get_tanksize())&&
 	    					 Constant.fri_hero_hurted
    		   ){
    			 Constant.fri_hero_hurted = false;
    			// clear_position();
    			 return true;
    		   }
    		 
    		 
    		 else if(
    				 Constant.checkcrash(x, y, w, h, 
 	       					 Constant.fri_tank1_x, Constant.fri_tank1_y, tank.get_tanksize(), tank.get_tanksize())&&
 	       					 Constant.fri_tank1_hurted
    				 ){
		    			 Constant.fri_tank1_hurted = false;
		    		//	 clear_position();
		    			 return true;
    		          }
    		 
    		 
    		 else if(
    				 Constant.checkcrash(x, y, w, h, 
 	    					 Constant.fri_tank2_x, Constant.fri_tank2_y, tank.get_tanksize(), tank.get_tanksize())&&
 	    					 Constant.fri_tank2_hurted
    				 ){
		    			 Constant.fri_tank2_hurted = false;
		    			// clear_position();
		    			 return true;
    		          }
    	 }
    	 
    	 
    	 else{	//���Ǳ��ص��ӵ�
    		 
		    		
	    		 if(
	    				 Constant.checkcrash(x, y, w, h, 
		    					 Constant.enemy_Hero_tank_x, Constant.enemy_Hero_tank_y, tank.get_tanksize(), tank.get_tanksize())&&
		    					 Constant.ene_hero_hurted 
	    		   ){
	    			 
	    			 Constant.ene_hero_hurted = false;
	    			 //clear_position();
	    			 return true;
	    		    }
    		 
    		 else if(
    				 Constant.checkcrash(x, y, w, h, 
	       					 Constant.enemy_tank1_x, Constant.enemy_tank1_y, tank.get_tanksize(), tank.get_tanksize())&&
	       					Constant.ene_tank1_hurted
    				 ){
    			             
			    			 Constant.ene_tank1_hurted = false;
			    		//	 clear_position();
			    			 return true;
    		         }
	    		 
	    		 
    		 else if(
    				 Constant.checkcrash(x, y, w, h, 
	    					 Constant.enemy_tank2_x, Constant.enemy_tank2_y, tank.get_tanksize(), tank.get_tanksize())&&
	    					 Constant.ene_tank2_hurted 
    				 ){
			    			 Constant.ene_tank2_hurted = false;
			    			// clear_position();
			    			 return true;
    		         }
	    		 
    	 }
    	 
    	 return false;
     }
     
     
     
     //********************************************************************************************************************************   
     //������е��ӵ���ײ �������е���Ч��
     private boolean crashWithEnemybullet(float x , float y ){
    	 if(tank.get_numtank() == 4 || tank.get_numtank() == 5 || tank.get_numtank() == 6){
    		/* if(
    				 
    				    (Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
    	    	    	Constant.fri_hero_bullet_x1,Constant.fri_hero_bullet_y1,bullet.getWidth(), bullet.getHeight())||
    	    	    	Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
    	    	    	Constant.fri_hero_bullet_x2,Constant.fri_hero_bullet_y2,bullet.getWidth(), bullet.getHeight())||
    	    	    	Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
    	    	    	Constant.fri_tank1_bullet_x1,Constant.fri_tank1_bullet_y1,bullet.getWidth(), bullet.getHeight())||
    	    	    	Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
    	    	    	Constant.fri_tank1_bullet_x2,Constant.fri_tank1_bullet_y2,bullet.getWidth(), bullet.getHeight())||
    	    	    	Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
    	    	    	Constant.fri_tank2_bullet_x1,Constant.fri_tank2_bullet_y1,bullet.getWidth(), bullet.getHeight())||
    	    	    	Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
    	    	    	Constant.fri_tank2_bullet_x2,Constant.fri_tank2_bullet_y2,bullet.getWidth(), bullet.getHeight()))
    				 ){
    			         
    			          // clear_position();//ֻ�ܵ���һ�������ķ��Ϳ�����
    			           return true; 
    		           } */
    		 if(Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
 	    	    	Constant.fri_hero_bullet_x1,Constant.fri_hero_bullet_y1,bullet.getWidth(), bullet.getHeight())){
    			 Constant.fri_hero_bullet1 = true;
    			 return true;
    		 }
    		 else if(Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
 	    	    	Constant.fri_hero_bullet_x2,Constant.fri_hero_bullet_y2,bullet.getWidth(), bullet.getHeight())){
    			 Constant.fri_hero_bullet2 = true;
    			 return true;
    		 }
    		 else if(Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
 	    	    	Constant.fri_tank1_bullet_x1,Constant.fri_tank1_bullet_y1,bullet.getWidth(), bullet.getHeight())){
    			 Constant.fri_tank1_bullet1 = true;
    			 return true;
    		 }
    		 else if(Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
 	    	    	Constant.fri_tank1_bullet_x2,Constant.fri_tank1_bullet_y2,bullet.getWidth(), bullet.getHeight())){
    			 Constant.fri_tank1_bullet2 = true;
    			 return true;
    		 }
    		 else if(Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
 	    	    	Constant.fri_tank2_bullet_x1,Constant.fri_tank2_bullet_y1,bullet.getWidth(), bullet.getHeight())){
    			 Constant.fri_tank2_bullet1 = true;
    			 return true;
    		 }
    		 else if(Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
 	    	    	Constant.fri_tank2_bullet_x2,Constant.fri_tank2_bullet_y2,bullet.getWidth(), bullet.getHeight())){
    			 Constant.fri_tank2_bullet2 = true;
    			 return true;
    		 }
    	 }
    	 
    	 else{
    		 /*
    		 if(
    	    			(Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
    	    			Constant.enemy_hero_bullet_x1,Constant.enemy_hero_bullet_y1,bullet.getWidth(), bullet.getHeight())||
    	    			Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
    	    	    	Constant.enemy_hero_bullet_x2,Constant.enemy_hero_bullet_y2,bullet.getWidth(), bullet.getHeight())||
    	    	    	Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
    	    			Constant.enemy_normal1_bullet_x1,Constant.enemy_normal1_bullet_y1,bullet.getWidth(), bullet.getHeight())||
    	    			Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
    	    	    	Constant.enemy_normal1_bullet_x2,Constant.enemy_normal1_bullet_y2,bullet.getWidth(), bullet.getHeight())||
    	    	    	Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
    	    	    	Constant.enemy_normal2_bullet_x1,Constant.enemy_normal2_bullet_y1,bullet.getWidth(), bullet.getHeight())||
    	    	    	Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
    	    	    	Constant.enemy_normal2_bullet_x2,Constant.enemy_normal2_bullet_y2,bullet.getWidth(), bullet.getHeight()))
    	    	    	//�жϲ�������
    	    			
    	    	   ){
    			         //  clear_position();
    	    		       return true;
    	    	    }
    		 */
    		 if((Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
 	    			Constant.enemy_hero_bullet_x1,Constant.enemy_hero_bullet_y1,bullet.getWidth(), bullet.getHeight()))){
    			 Constant.ene_hero_bullet1 = true;
    			 return true;
    		 }
    		 else if(Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
 	    	    	Constant.enemy_hero_bullet_x2,Constant.enemy_hero_bullet_y2,bullet.getWidth(), bullet.getHeight())){
    			 Constant.ene_hero_bullet2 = true;
    			 return true;
    		 }
    		 else if(Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
 	    			Constant.enemy_normal1_bullet_x1,Constant.enemy_normal1_bullet_y1,bullet.getWidth(), bullet.getHeight())){
    			 Constant.ene_tank1_bullet1 = true;
    			 return true;
    		 }
    		 else if(Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
 	    	    	Constant.enemy_normal1_bullet_x2,Constant.enemy_normal1_bullet_y2,bullet.getWidth(), bullet.getHeight())){
    			 Constant.ene_tank1_bullet2 = true;
    			 return true;
    		 }
    		 else if(Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
 	    	    	Constant.enemy_normal2_bullet_x1,Constant.enemy_normal2_bullet_y1,bullet.getWidth(), bullet.getHeight())){
    			 Constant.ene_tank2_bullet1 = true;
    			 return true;
    		 }
    		 else if(Constant.checkcrash(x, y, bullet.getWidth(), bullet.getHeight(),
 	    	    	Constant.enemy_normal2_bullet_x2,Constant.enemy_normal2_bullet_y2,bullet.getWidth(), bullet.getHeight())){
    			 Constant.ene_tank2_bullet2 = true;
    			 return true;
    		 }
    		 
    	 }
    	
    	 switch(tank.get_numtank()){
    	 case 1:
    		 if(Constant.fri_tank1_bullet1){
    			 Constant.fri_tank1_bullet1 = false;
    			 return true;
    		 }
    		 if(Constant.fri_tank1_bullet2){
    			 Constant.fri_tank1_bullet2 = false;
    			 return true;
    		 }
    		 break;
    	 case 2:
    		 if(Constant.fri_tank2_bullet1){
    			 Constant.fri_tank2_bullet1 = false;
    			 return true;
    		 }
    		 if(Constant.fri_tank2_bullet2){
    			 Constant.fri_tank2_bullet2 = false;
    			 return true;
    		 }
    		 break;
    	 case 3:
    		 if(Constant.fri_hero_bullet1){
    			 Constant.fri_hero_bullet1 = false;
    			 return true;
    		 }
    		 if(Constant.fri_hero_bullet2){
    			 Constant.fri_hero_bullet2 = false;
    			 return true;
    		 }
    		 break;
    	 case 4:
    		 if(Constant.ene_hero_bullet1 ){
    			 Constant.ene_hero_bullet2 = false;
    			 return true;
    		 }
    		 if(Constant.ene_hero_bullet2){
    			 Constant.ene_hero_bullet2 = false;
    			 return true;
    		 }
    		 break;
    	 case 5:
    		 if(Constant.ene_tank1_bullet1 ){
    			 Constant.ene_tank1_bullet1 = false;
    			 return true;
    		 }
    		 if(Constant.ene_tank1_bullet2 ){
    			 Constant.ene_tank1_bullet2 = false;
    			 return true;
    		 }
    		 break;
    	 case 6:
    		 if(Constant.ene_tank2_bullet1 ){
    			 Constant.ene_tank2_bullet1 = false;
    			 return true;
    		 }
    		 if(Constant.ene_tank2_bullet2 ){
    			 Constant.ene_tank2_bullet2 = false;
    			 return true;
    		 }
    		 break;
    	 }
    	 
    	 return false;
     }
     
     //********************************************************************************************************************************   

     
     
     
     
}




















