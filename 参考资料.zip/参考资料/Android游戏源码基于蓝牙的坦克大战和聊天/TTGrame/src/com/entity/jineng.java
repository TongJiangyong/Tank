package com.entity;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;

import com.SurfaceView.initBimap_surfaceview;
import com.tools.Constant;

public class jineng {

	private static boolean eated_fri = false,eated_ene = false;
	
	private static Bitmap bomb,fanshang ,bomb_ene;
	private int zheng = 0 ;
	private int zheng1 = 0 ; 
	private static boolean zheng_shi = false;
	private static long time = 0 ;
    public static void jineng_(){
    	bomb =  Constant.resizeImage(initBimap_surfaceview.bomb, Constant.tank_width, Constant.tank_height);
    	bomb_ene = bomb ;
    	fanshang =  Constant.resizeImage(initBimap_surfaceview.jineng_fanshang, Constant.tank_width+4, Constant.tank_height+4);
    	initBimap_surfaceview.bomb = Constant.shifang(initBimap_surfaceview.bomb);
    	initBimap_surfaceview.jineng_fanshang = Constant.shifang(initBimap_surfaceview.jineng_fanshang);
    }
	
	
	//****************************************************************************************************************************
	public static void DrawfriLandmine(Canvas canvas ,Paint paint){
		    get_eated();
		
			if(!eated_fri){//���û�б���
			   canvas.drawBitmap(bomb,Constant.fri_landmine_position_x,Constant.fri_landmine_position_y , paint);	
			}
			else{//���Ե�
				
			}
	}
	
	public static void fri_hero_set_boom(){
		Constant.fri_landmine_position_x = Constant.fri_Hero_x ;
		Constant.fri_landmine_position_y = Constant.fri_Hero_y ;
		eated_fri = false;
	}
	public static void get_eated(){
		if(Constant.fri_landmine_eated){
			eated_fri = true;
			Constant.fri_landmine_eated = false;
			Constant.fri_landmine_position_x = -100;
			Constant.fri_landmine_position_y = -100;
		}
	}
	//******************************************************************************************************************************
	public static void Draw_ene_Landmine(Canvas canvas,Paint paint){
		ene_get_eated();
		if(zheng_shi){
			paint.setAlpha(150);
			if(!eated_fri){//���û�б���
				   canvas.drawBitmap(bomb_ene,Constant.enemy_landmine_position_x,Constant.enemy_landmine_position_y , paint);	
				}
			paint.setAlpha(255);
			
			if(Boundary.get_now_time() == (time + 12)){
				zheng_shi = false;
			}
		}
		
	}
	
	public static void ene_hero_set_boom(){
		Constant.enemy_landmine_position_x = Constant.enemy_Hero_tank_x ;
		Constant.enemy_landmine_position_y = Constant.enemy_Hero_tank_y ;
		eated_ene = false;
	}
	
	public static void ene_get_eated(){
		if(Constant.ene_landmine_eated){
			eated_ene = true;
			Constant.ene_landmine_eated = false;
			Constant.enemy_landmine_position_x = -100;
			Constant.enemy_landmine_position_y = -100;
		}
	}
	//******************************************************************************************************************************
	public static void set_zhengshi(boolean zhen){
		time = Boundary.get_now_time() ;
		zheng_shi = zhen;
	}
	public static boolean get_zhengshi(){
		return zheng_shi;
	}
	
	//****************************************************************************************************************************
	//����true���ǻ�����
	public boolean Drawhiding(Bitmap tank,Canvas canvas,Paint paint ,float x , float y ){
		if(zheng >= 400){
			zheng = 0 ;
			return true;
		}
		else {
			zheng++;
			paint.setAlpha(150);
			canvas.drawBitmap(tank, x,y, paint);
			
			paint.setAlpha(255);
			return false;
		}
	}
	//***************************************************************************************************************************
	public boolean Drawfanshang(Canvas canvas,Paint paint,float x , float y){
		if(zheng1 >= 200){
			zheng1 = 0 ;
			return true;
		}
		else {
			zheng1++;
			
			canvas.drawBitmap(fanshang, x,y, paint);
			
		
			return false;
		}
	}
	
}












































