package com.entity;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;

import com.SurfaceView.initBimap_surfaceview;
import com.tools.Constant;

public class Draw_Enemy {
    
    Object[] normaltank = new Object[3];
	
	Object tankrank[] = new Object[4];//Ӣ��tank������Ȼ��ȷ��tank��״
			              
	
	private Bitmap[] herotank,tank1,tank2 ,
	herotank_0 = new Bitmap[4],herotank_1= new Bitmap[4],herotank_2= new Bitmap[4],
	herotank_3= new Bitmap[4],Attacktank= new Bitmap[4],Fasttank= new Bitmap[4],Strongtank= new Bitmap[4];
	//�����Ƿ���
	//***********************************************************************************************************************
	public Draw_Enemy(){//������
		
		for(int i = 0 ;i < 4; i++){//����Ӣ��tankͼƬ
			
			herotank_0[i] = Constant.resizeImage(initBimap_surfaceview.HeroTank_1[i], Constant.tank_size, Constant.tank_size);
			herotank_1[i] = Constant.resizeImage(initBimap_surfaceview.HeroTank_2[i], Constant.tank_size, Constant.tank_size);
			herotank_2[i] = Constant.resizeImage(initBimap_surfaceview.HeroTank_3[i], Constant.tank_size, Constant.tank_size);
			herotank_3[i] = Constant.resizeImage(initBimap_surfaceview.HeroTank_4[i], Constant.tank_size, Constant.tank_size);
			
			initBimap_surfaceview.HeroTank_1[i] = Constant.shifang(initBimap_surfaceview.HeroTank_1[i]);
			initBimap_surfaceview.HeroTank_2[i] = Constant.shifang(initBimap_surfaceview.HeroTank_2[i]);
			initBimap_surfaceview.HeroTank_3[i] = Constant.shifang(initBimap_surfaceview.HeroTank_3[i]);
			initBimap_surfaceview.HeroTank_4[i] = Constant.shifang(initBimap_surfaceview.HeroTank_4[i]);
			
			
		}
		tankrank[0] = herotank_0;
		tankrank[1] = herotank_1;
		tankrank[2] = herotank_2;
		tankrank[3] = herotank_3;//Ӣ��tank
		
		if(Constant.S){//�Ƿ������ô����tank
			
			for(int i = 0 ; i < 4 ; i++){
				Attacktank[i] = Constant.resizeImage(initBimap_surfaceview.AttackTank[i], Constant.tank_size, Constant.tank_size);
				Fasttank[i] = Constant.resizeImage(initBimap_surfaceview.FastTank[i], Constant.tank_size, Constant.tank_size);
				Strongtank[i] = Constant.resizeImage(initBimap_surfaceview.StrongTank[i], Constant.tank_size, Constant.tank_size);
				initBimap_surfaceview.AttackTank[i] = Constant.shifang(initBimap_surfaceview.AttackTank[i]);
				initBimap_surfaceview.FastTank[i] = Constant.shifang(initBimap_surfaceview.FastTank[i]);
				initBimap_surfaceview.StrongTank[i] = Constant.shifang(initBimap_surfaceview.StrongTank[i]);
			}
		}
		else{//�ͻ���
			
			for(int i = 0 ; i < 4 ; i++){
				Attacktank[i] = Constant.resizeImage(initBimap_surfaceview.redAttackTank[i], Constant.tank_size, Constant.tank_size);
				Fasttank[i] = Constant.resizeImage(initBimap_surfaceview.redFastTank[i], Constant.tank_size, Constant.tank_size);
				Strongtank[i] = Constant.resizeImage(initBimap_surfaceview.redStrongTank[i], Constant.tank_size, Constant.tank_size);
				initBimap_surfaceview.redAttackTank[i] = Constant.shifang(initBimap_surfaceview.redAttackTank[i]);
				initBimap_surfaceview.redFastTank[i] = Constant.shifang(initBimap_surfaceview.redFastTank[i]);
				initBimap_surfaceview.redStrongTank[i] = Constant.shifang(initBimap_surfaceview.redStrongTank[i]);
	        	
			}
		}
        
		normaltank[0] = Attacktank;//��ͨtank����
		normaltank[1] = Fasttank;
		normaltank[2] = Strongtank;
        
	}
	//***********************************************************************************************************************

	public void Drawself(Canvas canvas ,Paint paint){
		DrawHero(canvas,paint);
		Drawtank1(canvas,paint);
		Drawtank2(canvas,paint);
		
	}
	//***********************************************************************************************************************

	private void DrawHero(Canvas canvas ,Paint paint){
	    
		herotank = (Bitmap[]) tankrank[(int)Constant.enemy_hero_star];//��������ȷ��tank��״
		switch((int)(Constant.enemy_hero_direction)){
		case 0 :
			canvas.drawBitmap(herotank[0], Constant.enemy_Hero_tank_x,  Constant.enemy_Hero_tank_y, paint);
			break;
		case 1:
			canvas.drawBitmap(herotank[1], Constant.enemy_Hero_tank_x, Constant.enemy_Hero_tank_y, paint);
			break;
		case 2:
			canvas.drawBitmap(herotank[2], Constant.enemy_Hero_tank_x, Constant.enemy_Hero_tank_y, paint);
			break;
		case 3:
			canvas.drawBitmap(herotank[3], Constant.enemy_Hero_tank_x, Constant.enemy_Hero_tank_y, paint);
			break;
			
		}
	}
	//***********************************************************************************************************************

	private void Drawtank1(Canvas canvas, Paint paint){
		try{
			
					
			    tank1 = (Bitmap[]) normaltank[(int) Constant.enemy_tank1_type];	//����tank���ͻ�tank
				switch((int)(Constant.enemy_normal_tank1_direction)){
				case 0 :
					canvas.drawBitmap(tank1[0], Constant.enemy_tank1_x, Constant.enemy_tank1_y, paint);
					break;
				case 1:
					canvas.drawBitmap(tank1[1],  Constant.enemy_tank1_x, Constant.enemy_tank1_y, paint);
					break;
				case 2:
					canvas.drawBitmap(tank1[2],  Constant.enemy_tank1_x, Constant.enemy_tank1_y, paint);
					break;
				case 3:
					canvas.drawBitmap(tank1[3],  Constant.enemy_tank1_x, Constant.enemy_tank1_y, paint);
					break;
				}

		}catch(ArrayIndexOutOfBoundsException e){
			
		}
		
	}
	//***********************************************************************************************************************

	private void Drawtank2(Canvas canvas , Paint paint){
		try{
			
							tank2 = (Bitmap[]) normaltank[(int) Constant.enemy_tank1_type];
						switch((int)(Constant.enemy_normal_tank2_direction)){
						case 0 :
							canvas.drawBitmap(tank2[0],  Constant.enemy_tank2_x, Constant.enemy_tank2_y, paint);
							break;
						case 1:
							canvas.drawBitmap(tank2[1],  Constant.enemy_tank2_x, Constant.enemy_tank2_y, paint);
							break;
						case 2:
							canvas.drawBitmap(tank2[2],  Constant.enemy_tank2_x, Constant.enemy_tank2_y, paint);
							break;
						case 3:
							canvas.drawBitmap(tank2[3],  Constant.enemy_tank2_x, Constant.enemy_tank2_y, paint);
							break;
						}
					
						
		}catch(ArrayIndexOutOfBoundsException e){
			
		}
}
	
	
}
























