package com.entity;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;

import com.SurfaceView.initBimap_surfaceview;
import com.tools.Constant;

public class Boundary {

	//������
	private static Rect displayrect = new Rect((int)Constant.Operate_width ,0,(int)Constant.Screen_X,(int)Constant.Display_height);
	private static Rect Operaterect = new Rect(0,0,(int)Constant.Operate_width,(int)Constant.Screen_Y);
	private static Bitmap grass = null, ice = null , sea = null, brick = null ,stone = null,
			              grass_jiakuan = null,ice_jiakuan = null , sea_jiakuan = null, brick_jiakuan = null ,stone_jiakuan = null,
			              grass_jiachang = null,ice_jiachang = null , sea_jiachang = null, brick_jiachang = null ,stone_jiachang = null,  
	                      grass_kuanchang = null,ice_kuanchang = null,sea_kuanchang = null,brick_kuanchang,stone_kuanchang = null;//����ͼƬ��Դ
	private static float pic_width = Constant.getlittlepicture_x();//ÿ��ͼƬ���
	private static float pic_height = Constant.getlittlepicture_y();//ÿ��ͼƬ�ĸ߶�
	private static boolean flag_hang = false , flag_lie = false;
	private static Paint pen_fordisplay = new Paint();
	private static long time = 1,now_time=0;//ʱ�����
	public static float button_width = Constant.Operate_width;//��ť�Ŀ��
	public static float button_height = (float) (Constant.Operate_height/5);//��ť�ĸ߶�
	
	public static Bitmap Button_stop;//ͣס
	public static Bitmap Button_hiding;//����
	public static Bitmap Button_setboom;//װը��
	public static Bitmap Button_timewait;//��סtank
	public static Bitmap button_killall;//ȫ��ը�Է�tank
	public static Bitmap button_other1;
	public static Bitmap button_fa_she;//������������
	public static Bitmap button_Rebound ;//����
	public static Bitmap button_real_eye ;//����
	public static Bitmap button_protect ;
	public static String jinggao;
    public static long draw_time ;
    public static boolean draw_one = true;//true ��ʱ���Լ�����Ϣ   false��ʱ�򻭾�����Ϣ
	
	public static boolean Button_hiding_flag = false,Button_setboom_flag = false,Button_timewait_flag = false,
			              Button_killall_flag = false,Button_Rebound_flag = false,Button_real_eye = false,Button_protect_eye = false;
	//public static float 
    public static int[][] map;//��������ͼ
	
    public static int move_button = 1;
    
    private static int temp = 0 ;
   
	public static  int map_1 [][]     =         {//������Ϣ
			//35*20 �ĵ�ͼ

			 
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,2,2,2,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,0,0,0,0},
			{0,0,0,0,0,0,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,0,0,0,0},
			{0,0,0,0,0,0,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,0,0,0,0},
			{0,0,0,0,0,0,1,1,4,4,4,4,4,4,4,4,4,4,4,4,4,1,1,0,0,0,0,0,0,0,5,0,0,0,0},
			{0,0,0,0,0,0,1,1,1,1,1,1,1,1,4,4,4,4,4,4,4,1,1,0,0,0,0,0,0,0,5,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,0,0,0,0,1,1,0,0,3,3,3,3,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,4,0,0,0,0,5,0,0,0,0,1,1,0,0,3,3,3,3,0,0,0,0,0,0},
			{1,0,0,0,1,0,0,0,0,0,0,4,0,0,0,0,5,0,0,0,0,1,1,0,0,3,3,3,3,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,1},
			{0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,1,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			
			
	};
	
	public static int map_2[][]    =   {//����
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,2,2,2,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,0,0,0,0},
			{0,0,0,0,0,0,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,0,0,0,0},
			{0,0,0,0,0,0,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,0,0,0,0},
			{0,0,0,0,0,0,1,1,4,4,4,4,4,4,4,4,4,4,4,4,4,1,1,0,0,0,0,0,0,0,5,0,0,0,0},
			{0,0,0,0,0,0,1,1,1,1,1,1,1,1,4,4,4,4,4,4,4,1,1,0,0,0,0,0,0,0,5,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,0,0,0,0,1,1,0,0,3,3,3,3,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,4,0,0,0,0,5,0,0,0,0,1,1,0,0,3,3,3,3,0,0,0,0,0,0},
			{1,0,0,0,1,0,0,0,0,0,0,4,0,0,0,0,5,0,0,0,0,1,1,0,0,3,3,3,3,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,1},
			{0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,1,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{1,2,3,4,5,1,2,3,4,5,1,2,3,4,5,1,2,3,4,5,1,2,3,4,5,1,2,3,4,5,1,2,3,4,5},
			
			
	};
	
	
	public static int map_3[][]   =   {
			
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,1,2,0,0,0,0,0,0,0,0,0,0,0,0,2,2,2,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,1,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,1,1,0,3,4,5,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,0,0,0,0},
			{0,0,0,0,0,0,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,0,0,0,0},
			{0,0,0,0,0,0,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5,0,0,0,0},
			{0,0,0,0,0,0,1,1,4,4,4,4,4,4,4,4,4,4,4,4,4,1,1,0,0,0,0,0,0,0,5,0,0,0,0},
			{0,0,0,0,0,0,1,1,1,1,1,1,1,1,4,4,4,4,4,4,4,1,1,0,0,0,0,0,0,0,5,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,0,0,0,0,1,1,0,0,3,3,3,3,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,4,0,0,0,0,5,0,0,0,0,1,1,0,0,3,3,3,3,0,0,0,0,0,0},
			{1,0,0,0,1,0,0,0,0,0,0,4,0,0,0,0,5,0,0,0,0,1,1,0,0,3,3,3,3,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,5,5,5,5,5,5,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,1},
			{0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,1,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
			
	};
	public static Object[] Map ={map_1,map_2,map_3};
	//****************************************************************************************************************************
	//������
	public static void Boundary_( ){
		  Dealbitmap();
		  
	    
		  map = (int[][]) Map[Constant.whichMap];//ѡ�����ŵ�ͼ
	  
	  
	}
	//****************************************************************************************************************************
    public static long get_now_time(){
    	if(time == 0)return 1;
    	return time;
    }
    
	//****************************************************************************************************************************
   
	private static boolean get_pic_width(int count_hang){
  
		if(((count_hang*pic_width)-(--count_hang*(int)pic_width)-(int)pic_width) >= 1){
			return true;
		}
    	return false;//����һ
    }
	
	private static boolean get_pic_height(int count_lie){
	
		if(((count_lie*pic_height)-(--count_lie*(int)pic_height)-(int)pic_height) >= 1){
			return true;
		}
		return false;//����һ
	}
	
	//****************************************************************************************************************************
    public int[][] get_map(){
    	return map;
    }
    public void set_map(int[][] merge){//ÿ��������Ϣ������ ѡ������������
    
    	map = merge;
    }
    public static void set_whitch_button(int whitch){
    	move_button = whitch ;
    }
    public static int get_witch_button(){
    	return move_button ;
    }
	///////////////////////////////////////////////////////////////////////////////////////////////
	//�ж�̹���Ƿ���ͨ���ˡ�������false��ͨ��
    public static boolean tankInMap(float x, float y ,int whitch,Tank tank){
		//����������x y�������� ���  map�е��±�
		    //���������if��Ϊ�˽���Ǹ��������ĵ��ٽ�����
    	temp = (int) (3*(Constant.Screen_X/800)) ;//����������
    	
		    if(x >= Constant.Screen_X){
		    	
		    	
		    	x=Constant.Screen_X-1;
		    }
		    if(y >= Constant.Screen_Y){
		    	
		    	y=Constant.Screen_Y-1 ;
		    
		    }
			x -= Constant.Operate_width;
		    y -= Constant.Display_height;
			//Ϊ�˵õ��Ǿ�����ĸ�ͼƬ
		    int map_x = (int) (x / pic_width);
			int map_y = (int) (y / pic_height);
			if((map[map_y][map_x] == Barrier.ice || map[map_y][map_x]  == Barrier.grass || map[map_y][map_x]  == 0)){
				
				if(map[map_y][map_x] == Barrier.ice ){//����Ч��
					huaxing(tank,x,y);
				}
				return false;//����ͨ��
			}
			else{//����ͨ����
				
				switch(tank.get_direction()){
				
				
				case 0:
					
					if(whitch ==1){ //�Ϸ����   ���Ͻǵĵ�
						 x += temp;
						
					        map_x = (int) (x / pic_width);
					      
					        if((map[map_y][map_x] == Barrier.ice || map[map_y][map_x]  == Barrier.grass || map[map_y][map_x]  == 0)){
					        	
					        	if(map[map_y][map_x] == Barrier.ice ){//����Ч��
									huaxing(tank,x,y);
								}
					        	return false;//����ͨ��
							}
					        return true;
					}
					else if(whitch == 2){//���Ͻǵĵ�
						x-=temp;
						
						map_x = (int) (x / pic_width);
						
						if((map[map_y][map_x] == Barrier.ice || map[map_y][map_x]  == Barrier.grass || map[map_y][map_x]  == 0)){
							/*if(map[map_y][map_x] == Barrier.ice ){//����Ч��
							huaxing(tank,x,y);
						}*/
							return false;//����ͨ��
						}
					}
					else{
						return true;
					}
					
				case 1:
					
					if(whitch == 1){ //���½ǵĵ�
						
						x+=temp;
				        map_x = (int) (x / pic_width);
				        if((map[map_y][map_x] == Barrier.ice || map[map_y][map_x]  == Barrier.grass || map[map_y][map_x]  == 0)){
				        	if(map[map_y][map_x] == Barrier.ice ){//����Ч��
								huaxing(tank,x,y);
							}
				        	return false;//����ͨ��
						}
				        return true;
					}
					else if(whitch == 2){ //���½ǵĵ�
						x-=temp;
						map_x = (int) (x / pic_width);
						if((map[map_y][map_x] == Barrier.ice || map[map_y][map_x]  == Barrier.grass || map[map_y][map_x]  == 0)){
							
						
							
							return false;//����ͨ��
					     }
					}
					
					 
					
					else{
					      return true;
					     }
				
				case 2:
					
					if(whitch == 1){//���Ͻǵĵ�
						y+=temp;
						 map_y = (int) (y / pic_height);
					     if((map[map_y][map_x] == Barrier.ice || map[map_y][map_x]  == Barrier.grass || map[map_y][map_x]  == 0)){
					    	 if(map[map_y][map_x] == Barrier.ice ){//����Ч��
									huaxing(tank,x,y);
								}
					    	 return false;//����ͨ��
					     }
					}
					else if(whitch == 2){//���½ǵĵ�
						
						y-=temp;
						 map_y = (int) (y / pic_height);
						 
						if((map[map_y][map_x] == Barrier.ice || map[map_y][map_x]  == Barrier.grass || map[map_y][map_x]  == 0)){
						
							/*if(map[map_y][map_x] == Barrier.ice ){//����Ч��
								huaxing(tank,x,y);
							}*/
							
							return false;//����ͨ��
						}
						
					}
					else{
						return true;
					}
					
				case 3:
					
					if(whitch == 1){//���Ͻǵĵ�
						
						y+=temp;
						 map_y = (int) (y / pic_height);
						 
						 if((map[map_y][map_x] == Barrier.ice || map[map_y][map_x]  == Barrier.grass || map[map_y][map_x]  == 0)){
							
							 if(map[map_y][map_x] == Barrier.ice ){//����Ч��
									huaxing(tank,x,y);
							  }
							 
							 return false;//����ͨ��
						 }
					}
					else if(whitch == 2){//���½ǵĵ�
						
						y-=temp;
						map_y = (int) (y / pic_height);
						
						if((map[map_y][map_x] == Barrier.ice || map[map_y][map_x]  == Barrier.grass || map[map_y][map_x]  == 0)){
							
							
							
							return false;//����ͨ��
						}
					}    
					else{
				        return true;
					}
				
				
				
				
				}
			}
			return true ;
			
		
		    
			
	}
	//**********************************************************************************************************************************
	private static  void huaxing(Tank tank,float x, float y ){
		
		//����Ч��
		//tank.set_speed(6);
		/*	switch(tank.get_direction()){
			case 0:
				y -= 0.1;
				tank.set_y(y);
				break;
			case 1:
				y-=Constant.tank_height;
				y+= 0.1;
				tank.set_y(y);
				break;
			case 2:
				x -= 0.1;
				tank.set_x(x);
				break;
			case 3:
                x-= Constant.tank_width;
				x+= 0.1;
				tank.set_x(x);
				break;
			}*/
	}
	//**********************************************************************************************************************************

	//�ж��ӵ�ʱ������   Ȼ���ж��ӵ� ��ʲô�ȼ�  ���Ի���ʲô�ϰ�  �ɴ����� true ��������false��
	public static  boolean bulletInMap(float x, float y,float w,float h,boolean can_stone ,int direction){
		
		 if(x >= Constant.Screen_X){
		    	
		    	x= Constant.Screen_X - 1;
		 }
		 if(y >= Constant.Screen_Y){
		    	y=  Constant.Screen_Y - 1 ;
		 }
		 if(y+h>=Constant.Screen_Y){
			 y = Constant.Screen_Y-1 - h  ;
		 }
		 if(x+w>=Constant.Screen_X){
			 x =  Constant.Screen_X - 1 - w ;
		 }
			x -= Constant.Operate_width;
		    y -= Constant.Display_height;
		    
		int map_1_x = 0 ;
		int map_1_y = 0 ;
		int map_2_x = 0 ;
		int map_2_y = 0 ;
		
		
		switch(direction){
		
		case 0 :
			map_1_x = (int) (x/Constant.getlittlepicture_x());//���Ͻǵĵ�
			map_1_y = (int) (y/Constant.getlittlepicture_y());
			map_2_x = (int) ((x+w)/Constant.getlittlepicture_x());
			map_2_y = (int) (y/Constant.getlittlepicture_y());
			break;
		case 1:
			map_1_x = (int) (x/Constant.getlittlepicture_x());//���½ǵĵ�
			map_1_y = (int) ((y+h)/Constant.getlittlepicture_y());
			map_2_x = (int) ((x+w)/Constant.getlittlepicture_x());//youxiajiao
			map_2_y = (int) ((y+h)/Constant.getlittlepicture_y());
			break;
		case 2:
			map_1_x = (int) (x/Constant.getlittlepicture_x());
			map_1_y = (int) (y/Constant.getlittlepicture_y());
			map_2_x = (int) ((x)/Constant.getlittlepicture_x());
			map_2_y = (int) ((y+h)/Constant.getlittlepicture_y());
			break;
		case 3:
			map_1_x = (int) ((x+w)/Constant.getlittlepicture_x());
			map_1_y = (int) (y/Constant.getlittlepicture_y());
			map_2_x = (int) ((x+w)/Constant.getlittlepicture_x());
			map_2_y = (int) ((y+h)/Constant.getlittlepicture_y());
			break;
		}
		
		
		
		
		
		
	    if(
	    		(map[map_1_y][map_1_x] == Barrier.ice || map[map_1_y][map_1_x]  == Barrier.sea || map[map_1_y][map_1_x]  == 0||
	    		map[map_1_y][map_1_x]  == Barrier.grass)&&
	    		(map[map_2_y][map_2_x] == Barrier.ice || map[map_2_y][map_2_x]  == Barrier.sea || map[map_2_y][map_2_x]  == 0||
	    		map[map_2_y][map_2_x]  == Barrier.grass)
	    )
	    {
	    	
			return true;
		}
	    //   ����ӵ��ĵȼ�3   ��������stone �����
	    else if (
			             (map[map_1_y][map_1_x]  == Barrier.brick||(map[map_1_y][map_1_x]  == Barrier.stone && can_stone))
				)
	    { 
	    	        map[map_1_y][map_1_x] = 0 ;
			     
	                return false;
	        
	    }
	    else if(
	    				(map[map_2_y][map_2_x]  == Barrier.brick||(map[map_2_y][map_2_x]  == Barrier.stone && can_stone) )
	    		){
	    	               map[map_2_y][map_2_x]  = 0;
	    	               return false ;
	           }
	    else if(
	    		  (map[map_1_y][map_1_x]  == Barrier.brick||(map[map_1_y][map_1_x]  == Barrier.stone && can_stone))&&
				    (map[map_2_y][map_2_x]  == Barrier.brick||(map[map_2_y][map_2_x]  == Barrier.stone && can_stone) )
	    		){
	    	             map[map_1_y][map_1_x] = 0 ;
	    	             map[map_2_y][map_2_x]  = 0;
	    	             return false ;
	            }
		return false; 
	}
	//����Ӳ������ͼƬ
	private static void Dealbitmap(){
		   //��������޸ĳߴ硣����Ȼ�˷���Դ
			
			grass = Constant.resizeImage(initBimap_surfaceview.grass, pic_width , pic_height);
			ice = Constant.resizeImage(initBimap_surfaceview.ice, pic_width , pic_height);
			stone = Constant.resizeImage(initBimap_surfaceview.stone, pic_width , pic_height);
			brick = Constant.resizeImage(initBimap_surfaceview.brick, pic_width , pic_height);
			sea = Constant.resizeImage(initBimap_surfaceview.sea, pic_width , pic_height);
			
			grass_jiakuan = Constant.resizeImage(initBimap_surfaceview.grass, pic_width+1 , pic_height);
			ice_jiakuan = Constant.resizeImage(initBimap_surfaceview.ice, pic_width+1 , pic_height);
			stone_jiakuan = Constant.resizeImage(initBimap_surfaceview.stone, pic_width+1 , pic_height);
			brick_jiakuan = Constant.resizeImage(initBimap_surfaceview.brick, pic_width+1 , pic_height);
			sea_jiakuan = Constant.resizeImage(initBimap_surfaceview.sea, pic_width+1 , pic_height);
			
			grass_jiachang = Constant.resizeImage(initBimap_surfaceview.grass, pic_width, pic_height+1);
			ice_jiachang = Constant.resizeImage(initBimap_surfaceview.ice, pic_width , pic_height+1);
			stone_jiachang = Constant.resizeImage(initBimap_surfaceview.stone, pic_width , pic_height+1);
			brick_jiachang = Constant.resizeImage(initBimap_surfaceview.brick, pic_width , pic_height+1);
			sea_jiachang = Constant.resizeImage(initBimap_surfaceview.sea, pic_width , pic_height+1);
			
			grass_kuanchang = Constant.resizeImage(initBimap_surfaceview.grass, pic_width+1, pic_height+1);
			ice_kuanchang = Constant.resizeImage(initBimap_surfaceview.ice, pic_width+1 , pic_height+1);
			stone_kuanchang = Constant.resizeImage(initBimap_surfaceview.stone, pic_width+1 , pic_height+1);
			brick_kuanchang = Constant.resizeImage(initBimap_surfaceview.brick, pic_width+1 , pic_height+1);
			sea_kuanchang = Constant.resizeImage(initBimap_surfaceview.sea, pic_width+1 , pic_height+1);
			
			
			Button_stop = Constant.resizeImage(initBimap_surfaceview.stop, button_width, button_height);
			Button_hiding = Constant.resizeImage(initBimap_surfaceview.hiding, button_width, button_height);
			Button_setboom = Constant.resizeImage( initBimap_surfaceview.bu_bomb, button_width, button_height);
			Button_timewait = Constant.resizeImage(initBimap_surfaceview.stop_all, button_width, button_height);
			button_killall = Constant.resizeImage( initBimap_surfaceview.kill_all, button_width, button_height);
			
			button_other1 = Constant.resizeImage(initBimap_surfaceview.herotankStopbutton, button_width, button_height);
			
			button_fa_she =  Constant.resizeImage(initBimap_surfaceview.killallenemybutton, button_width, button_height);;//������������
			button_Rebound  = Constant.resizeImage(initBimap_surfaceview.fanshang, button_width, button_height);//����
			button_real_eye = Constant.resizeImage(initBimap_surfaceview.zhenshi, button_width, button_height);//����
			button_protect =  Constant.resizeImage(initBimap_surfaceview.bu_protect, button_width, button_height);
			
			initBimap_surfaceview.kill_all = Constant.shifang(initBimap_surfaceview.kill_all);
			initBimap_surfaceview.stop_all = Constant.shifang(initBimap_surfaceview.stop_all);
			initBimap_surfaceview.bu_protect = Constant.shifang(initBimap_surfaceview.bu_protect);
			initBimap_surfaceview.zhenshi = Constant.shifang(initBimap_surfaceview.zhenshi);
			initBimap_surfaceview.fanshang = Constant.shifang(initBimap_surfaceview.fanshang); 
			initBimap_surfaceview.grass = Constant.shifang(initBimap_surfaceview.grass);  //���û�л���  
			initBimap_surfaceview.sea = Constant.shifang(initBimap_surfaceview.sea);
			initBimap_surfaceview.ice = Constant.shifang(initBimap_surfaceview.ice);
			initBimap_surfaceview.stone = Constant.shifang(initBimap_surfaceview.stone);
			initBimap_surfaceview.brick = Constant.shifang(initBimap_surfaceview.brick);
			initBimap_surfaceview.temp = Constant.shifang(initBimap_surfaceview.temp);
			initBimap_surfaceview.herotankStopbutton = Constant.shifang(initBimap_surfaceview.herotankStopbutton);
			
			initBimap_surfaceview.herotankStopbutton = Constant.shifang(initBimap_surfaceview.herotankStopbutton);
			initBimap_surfaceview.killallenemybutton = Constant.shifang(initBimap_surfaceview.killallenemybutton);
			initBimap_surfaceview.herotankStopbutton = Constant.shifang(initBimap_surfaceview.herotankStopbutton);
           
		}  
			
			
		
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////
	
	public static void DrawslefBelow(Canvas canvas,Paint paint){
		
		canvas.drawRect(displayrect, paint);
		paint.setColor(Color.BLUE);
		canvas.drawRect(Operaterect, paint);  
		
		Drawmap(canvas,paint);
		DrawButton(canvas,paint);
		DrawInfo(canvas);
		paint.setColor(Color.WHITE);
		draw_warn(canvas,paint);
		DrawMyself(canvas,paint);
		
	}
	//*********************************************************************************************************************
	public static void draw_warn(Canvas canvas,Paint paint){
		if((Boundary.get_now_time() - draw_time) <= 1 && jinggao != null){
			paint.setTextSize(35);
			    draw_one = false;
				paint.setColor(Color.BLACK);
				canvas.drawText(jinggao, Constant.Operate_width+3, Constant.Display_height-3, paint);
			    paint.setColor(Color.WHITE);
			
		}
		else {
			draw_one  = true;
		}
	}
	//*********************************************************************************************************************
	public static void DrawMyself(Canvas canvas ,Paint paint){
		if(draw_one){
			paint.setColor(Color.BLACK );
			paint.setTextSize(35);
			canvas.drawText("��ɱ:"+Constant.fri_hero_kill+"     ����:"+Constant.fri_hero_life,
					Constant.Operate_width+3, Constant.Display_height-3, paint);
			paint.setColor(Color.WHITE );
		}
	}
	//**********************************************************************************************************************
	public static void get_warn(int warn){
		
		switch(warn){
		case 1:
			jinggao = "����Ҫɱ��"+(3-Constant.fri_hero_kill)+"��̹��";
			
			break;
		case 2:
			jinggao ="����Ҫ"+(30-(get_now_time() - Constant.set_boom_end))+"��";
			break;
		case 3:
			jinggao ="����Ҫɱ��"+(3-Constant.fri_hero_kill)+"��̹��";
			break;
		case 4:
			jinggao ="����Ҫ"+(40-(get_now_time() - Constant.kill_all_end))+"��";
			break;
		case 5:
			jinggao = "����Ҫɱ��"+(2-Constant.fri_hero_kill)+"��̹��";
			break;
		case 6:
			jinggao ="����Ҫ"+(20-(get_now_time() - Constant.fanshang_end))+"��";

			break;
		case 7:
			jinggao = "����Ҫɱ��"+(5-Constant.fri_hero_kill)+"��̹��";

			break;
		case 8:
			jinggao ="����Ҫ"+(40-(get_now_time() - Constant.kill_all_end))+"��";

			break;
		case 9:
			jinggao ="����Ҫ"+(30-(get_now_time() - Constant.protect_end))+"��";

			break;
		case 10:
			jinggao ="����Ҫ"+(20-(get_now_time() - Constant.hiding_end))+"��";

			break;
		case 11:
			jinggao ="����Ҫ"+(30-(get_now_time() - Constant.zheng_shi_end))+"��";

			break;
			
			
	
		}
		draw_time = get_now_time();
	}
	//****************************************************************************************************************
	
	public static void DrawselfAbove(Canvas canvas,Paint paint ){
		
		for(int i = 0 ; i < 21 ; i++){
			
			flag_lie = get_pic_height(i);
			
			for(int j = 0 ; j < 35 ; j++){
				flag_hang = get_pic_width(j);
                    if(map[i][j] == Barrier.grass){
					   
							if(flag_hang && !flag_lie){
								canvas.drawBitmap(grass_jiakuan,   ((Constant.Operate_width+pic_width*j)), 
									(Constant.Display_height+pic_height*i), paint);
							}
							else if(!flag_hang && flag_lie){
								canvas.drawBitmap(grass_jiachang,   ((Constant.Operate_width+pic_width*j)), 
										(Constant.Display_height+pic_height*i), paint);
							}
							else if(flag_hang && flag_lie){
								canvas.drawBitmap(grass_kuanchang,   ((Constant.Operate_width+pic_width*j)), 
										(Constant.Display_height+pic_height*i), paint);
							}
							else{
								
								canvas.drawBitmap(grass,   (Constant.Operate_width+pic_width*j), 
									(Constant.Display_height+pic_height*i), paint);
							}
				}
				
			}
		}
	}
	//�ػ���ͼ
	public static void Drawmap(Canvas canvas ,Paint paint){
		
		for(int i = 0 ; i < 21 ; i++){
			
			flag_lie = get_pic_height(i);
			
			for(int j = 0 ; j < 35 ; j++){
				flag_hang = get_pic_width(j);
				
				if(map[i][j] == Barrier.brick){
					
					
					if(flag_hang && !flag_lie){
						canvas.drawBitmap(brick_jiakuan,   ((Constant.Operate_width+pic_width*j)), 
								(Constant.Display_height+pic_height*i), paint);
						
					}
					else if(!flag_hang && flag_lie){
						canvas.drawBitmap(brick_jiachang,   ((Constant.Operate_width+pic_width*j)), 
								(Constant.Display_height+pic_height*i), paint);
					}
					else if(flag_hang && flag_lie){
						canvas.drawBitmap(brick_kuanchang,   ((Constant.Operate_width+pic_width*j)), 
								(Constant.Display_height+pic_height*i), paint);
					}
					else{
						
						canvas.drawBitmap(brick,   (Constant.Operate_width+pic_width*j), 
							(Constant.Display_height+pic_height*i), paint);
					}
					
						
				}
				else if(map[i][j]== Barrier.ice){
					
					if(flag_hang && !flag_lie){
						canvas.drawBitmap(ice_jiakuan,   ((Constant.Operate_width+pic_width*j)), 
							(Constant.Display_height+pic_height*i), paint);
					}
					else if(!flag_hang && flag_lie){
						canvas.drawBitmap(ice_jiachang,   ((Constant.Operate_width+pic_width*j)), 
								(Constant.Display_height+pic_height*i), paint);
					}
					else if(flag_hang && flag_lie){
						canvas.drawBitmap(ice_kuanchang,   ((Constant.Operate_width+pic_width*j)), 
								(Constant.Display_height+pic_height*i), paint);
					}
					else{
						
						canvas.drawBitmap(ice,   (Constant.Operate_width+pic_width*j), 
							(Constant.Display_height+pic_height*i), paint);
					}
					
					  
					
				}
				else if(map[i][j] == Barrier.sea){
					
					if(flag_hang && !flag_lie){
						canvas.drawBitmap(sea_jiakuan,   ((Constant.Operate_width+pic_width*j)), 
							(Constant.Display_height+pic_height*i), paint);
					}
					else if(!flag_hang && flag_lie){
						canvas.drawBitmap(sea_jiachang,   ((Constant.Operate_width+pic_width*j)), 
								(Constant.Display_height+pic_height*i), paint);
					}
					else if(flag_hang&& flag_lie){
						canvas.drawBitmap(sea_kuanchang,   ((Constant.Operate_width+pic_width*j)), 
								(Constant.Display_height+pic_height*i), paint);
					}
					else{
						
						canvas.drawBitmap(sea,   (Constant.Operate_width+pic_width*j), 
							(Constant.Display_height+pic_height*i), paint);
					}
					
					
					
				}
				
				else if(map[i][j] == Barrier.stone){
					
					if(flag_hang && !flag_lie){
						canvas.drawBitmap(stone_jiakuan,   ((Constant.Operate_width+pic_width*j)), 
							(Constant.Display_height+pic_height*i), paint);
					}
					else if(!flag_hang && flag_lie){
						canvas.drawBitmap(stone_jiachang,   ((Constant.Operate_width+pic_width*j)), 
								(Constant.Display_height+pic_height*i), paint);
					}
					else if(flag_hang && flag_lie){
						canvas.drawBitmap(stone_kuanchang,   ((Constant.Operate_width+pic_width*j)), 
								(Constant.Display_height+pic_height*i), paint);
					}
					else{
						
						canvas.drawBitmap(stone,   (Constant.Operate_width+pic_width*j), 
							(Constant.Display_height+pic_height*i), paint);
					}
					
					
				}
				
				
				else if(map[i][j] == 0 ){
					
					;
				}
			
				
			}
		}
	
	}
	
	//�滭��ť
	private static void DrawButton(Canvas canvas , Paint paint ){//��ť̫���ˡ�������ĸ�


		//public static   Bitmap Button_stop;//ͣסtank
		//public static Bitmap Button_hiding;//����
		//public static Bitmap Button_setboom;//װը��
		//public static Bitmap Button_timewait;//��סtank
//		public static Bitmap button_killall;//ȫ��ը�Է�tank
		//public static Bitmap button_other1;
		//public static Bitmap button_fa_she;//������������
		//public static Bitmap button_Rebound ;//����
		//public static Bitmap button_real_eye ;//����
		//public static Bitmap button_protect ;
		
		
		//canvas.drawBitmap(button_other, 0, button_height/5, paint);//��������ť
		if(move_button == 1){
				
			canvas.drawBitmap(Button_hiding,0, 0, paint);
			canvas.drawBitmap(button_protect,0, button_height, paint);
			canvas.drawBitmap(button_Rebound,0, button_height*2,paint);//����
			canvas.drawBitmap(button_fa_she, 0, button_height*3, paint);
			canvas.drawBitmap(Button_stop, 0, button_height*4, paint);
			
		}
		else if(move_button == 2){

			canvas.drawBitmap(button_real_eye,0, 0, paint);
			canvas.drawBitmap(button_other1,0, button_height, paint);
			canvas.drawBitmap(button_killall,0, button_height*2,paint);
			canvas.drawBitmap(Button_timewait, 0, button_height*3, paint);
			canvas.drawBitmap(Button_setboom, 0, button_height*4, paint);
			
		}
		
		
	}
	
	private static void DrawInfo(Canvas canvas){  //����ʾ������ʾ��Ϣ
		pen_fordisplay.setColor(Color.BLACK);
		pen_fordisplay.setAntiAlias(true);
		pen_fordisplay.setColor(Color.BLACK);
		pen_fordisplay.setTextSize((Constant.Display_height/6)*4);
		
		/*Bitmap shengming = Constant.resizeImage(PlayGame.tank_shengming,(Constant.Display_height*4)/5,
				(Constant.Display_height*4)/5);*/
		//PlayGame.tank_shengming = Constant.shifang(PlayGame.tank_shengming);
		
		//canvas.drawBitmap(shengming,Constant.Operate_width , 3, pen_fordisplay);
		//canvas.drawText("x", shengming.getWidth()+Constant.Operate_width,(float) ((Constant.Display_height/2)*1.5), pen_fordisplay);
		/*Bitmap jisha = Constant.resizeImage(PlayGame.kill_tank,(Constant.Display_height*4)/5,
				(Constant.Display_height*4)/5);
		PlayGame.kill_tank = Constant.shifang(PlayGame.kill_tank);
		canvas.drawBitmap(jisha,Constant.Display_width/2+10 , 3, pen_fordisplay);
		canvas.drawText("x", Constant.Display_width/2+10+jisha.getWidth(), (float) ((Constant.Display_height/2)*1.5), pen_fordisplay);
		pen_fordisplay.setTextSize(Constant.Display_height/2);*/
		//������Ϸ���е�ʱ��
		if(now_time == 0) now_time =System.currentTimeMillis();
		 time = ( System.currentTimeMillis()-now_time)/1000;//ת�����롣��
	    if(time/60 == 0){  //�տ�ʼ �������Ϊ����
	    	
	    		canvas.drawText(time+"",
	    				 (Constant.Operate_width+Constant.Display_width-100), 
	    				(float) ((Constant.Display_height/2)*1.5), pen_fordisplay);
	    	
	    }
	    else if(time/60 != 0){
	    	
	    	if(time/3600 == 0){	
	    		
	    		canvas.drawText(time/60+":"+time%60, 
	    				(float) (Constant.Operate_width+Constant.Display_width-100), 
	    				(float) ((Constant.Display_height/2)*1.5), pen_fordisplay);

	    	}
	    	else{//����һ��Сʱ
	    		canvas.drawText(time/3600+":"+time/216000+":"+time%60, 
	    				(float) (Constant.Operate_width+Constant.Display_width-130),
	    				(float) ((Constant.Display_height/2)*1.5), pen_fordisplay);

	    	}
	    }
	}
	
	
}



















