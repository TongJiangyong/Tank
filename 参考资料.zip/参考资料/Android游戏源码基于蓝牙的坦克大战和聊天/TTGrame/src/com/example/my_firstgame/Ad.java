package com.example.my_firstgame;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;



public class Ad extends Activity implements Runnable{

	private ImageView iv; 
	private Button mStart;
	private Handler handler; 
	private int[] path = new int[] { R.drawable.img01, R.drawable.img02,
			R.drawable.img03, R.drawable.img04, R.drawable.img05,
			R.drawable.img06 }; 
	private String[] title = new String[] { "��̴ʵ�ϵ�в�Ʒ", "��Ч����", "���ַ���", "�û���Ⱥ",
			"����ѧϰ", "ȫ��λ��ѯ" }; 

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_ad);
		iv = (ImageView) findViewById(R.id.adimageView); 
		mStart=(Button)findViewById(R.id.adbutton);
		Thread t = new Thread(this); 
		t.start(); // �����߳�
	
		handler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				// ����UI
				TextView tv = (TextView) findViewById(R.id.adtextView); 
				if (msg.what == 0x101) {
					tv.setText(msg.getData().getString("title")); 
					iv.setImageResource(path[msg.arg1]);
				}
				super.handleMessage(msg);
			}

		};
mStart.setOnClickListener(new OnClickListener() {
	
	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		Intent intent=new Intent(Ad.this,Dute.class);
		startActivity(intent);
	}
});
	}

	

	@Override
	public void run() {
		int index = 0;
		while (!Thread.currentThread().isInterrupted()) {
			index = new Random().nextInt(path.length); 
			Message m = handler.obtainMessage();
			m.arg1 = index; 
			Bundle bundle = new Bundle();
			m.what = 0x101; // ������Ϣ��ʶ
			bundle.putString("title", title[index]); 
			m.setData(bundle); 
			handler.sendMessage(m); 

			try {
				Thread.sleep(2000); 
			} catch (InterruptedException e) {
				e.printStackTrace(); 
			}

		}
	}
}
