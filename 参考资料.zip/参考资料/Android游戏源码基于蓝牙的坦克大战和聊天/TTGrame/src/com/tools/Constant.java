package com.tools;

import android.bluetooth.BluetoothSocket;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;

import com.SurfaceView.initBimap_surfaceview;
import com.entity.Boundary;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class Constant {
	
	  public static final int tank_size = 0;
	public static final int enemy_tank1_type = 0;
	public static int hero_bir_position = 0;
	//�������Ӻ��ж��ǿͻ��˻��Ƿ����
	 public static boolean S = false; 
	 public static boolean C = false;
	 public static int state = 0 ;//0δ���ӡ�1����
	 
	 public static int whichMap = 0;//��ʼ��Ϊ-1
	// public static boolean doneMap = false ;//�ж��ǲ���ѡ�����˵�ͼ
	
	 public static BluetoothSocket socket = null;//����socket����  �������Ӻ�ʯ��ʱ����ʹ�� 
	 public static OutputStream out = null; 
	 public static InputStream in = null;
	 
	
     public static float Screen_X = 1240 ;//ע��Ҫ�Ժ�����x y��Ϊ��׼
     public static float Screen_Y = 660 ;//gao
	 
     public static float enemy_Screen_X = 0 ;
     public static float enemy_Screen_Y = 0 ;
     
     public static float Display_width = 0 ;
     public static float Display_height = 0 ;
     
     public static float Operate_width = 0 ;
     public static float Operate_height = 0 ;
     
     public static float map_width = 35 ;//��ͼ�ĸ߶ȺͿ��
     public static float map_height = 21 ;//��ά����
    
     /*public static int hero_bir_position = -1 ; //�ж�Ӣ�۳�����λ��    Ȼ����̹ͨ�˲����ж��Լ��ĳ���λ��     0 �����  1���м�    2 ���ұ�
     public static int normaltank1_bir_position= -1 ;//�ж�һ����̹ͨ�˳�����λ��   ����˵��ͬ��
     public static int normaltank2_bir_position = -1;*/
    
   /*  public static int enemy_hero_position = 1 ;
     public static int enemy_tank1_position = 0 ;
     public static int enemy_tank2_position = 2 ;*/
     
     /*public static float enemy_tank1_type = 0 ;
     public static float enemy_tank2_type = 1 ;*/
     
     public static float tank_width = 0;
     public static float tank_height = 0 ;
     
    //̹�˵ľ������� 
     public static float fri_Hero_x = -1 ;
     public static float fri_Hero_y = -1 ;
     
     public static float fri_tank1_x = -1 ;
     public static float fri_tank1_y = -1 ;
     
     public static float fri_tank2_x = -1 ;
     public static float fri_tank2_y = -1 ;
     
    //�з� 
     public static float enemy_tank1_x = -1 ;
     public static float enemy_tank1_y = -1 ;
   
     public static float enemy_tank2_x = -1 ;
     public static float enemy_tank2_y = -1 ;
      
     public static float enemy_Hero_tank_x =  -1; 
     public static float enemy_Hero_tank_y =  -1; 
     
     
     //����ÿ���ӵ��ľ���λ��
     public static float bullet_size = 0;
     
     public static float enemy_hero_bullet_x1 = -1 ;
     public static float enemy_hero_bullet_y1 = -1 ;
     
     public static float enemy_hero_bullet_x2 = -1 ;
     public static float enemy_hero_bullet_y2 = -1 ;
     
     public static float enemy_normal1_bullet_x1 = -1 ;
     public static float enemy_normal1_bullet_y1 = -1 ;
     
     public static float enemy_normal1_bullet_x2 = -1 ;
     public static float enemy_normal1_bullet_y2 = -1 ;
     
     public static float enemy_normal2_bullet_x1 = -1 ;
     public static float enemy_normal2_bullet_y1 = -1 ;
    
     public static float enemy_normal2_bullet_x2 = -1 ;
     public static float enemy_normal2_bullet_y2 = -1 ;
     
     public static float fri_hero_bullet_x1 = -1;
     public static float fri_hero_bullet_y1 = -1;
     public static float fri_hero_bullet_x2 = -1;
     public static float fri_hero_bullet_y2 = -1;
     
     public static float fri_tank1_bullet_x1 = -1;
     public static float fri_tank1_bullet_y1 = -1;
     public static float fri_tank1_bullet_x2 = -1;
     public static float fri_tank1_bullet_y2 = -1;
     
     public static float fri_tank2_bullet_x1 = -1;
     public static float fri_tank2_bullet_y1 = -1;
     public static float fri_tank2_bullet_x2 = -1;
     public static float fri_tank2_bullet_y2 = -1;
    		 
     
     public static float enemy_hero_life = 0;
     
    // public static float enemy_hero_tank_go = 1 ;//0�����ߡ���1��
   //  public static float enemy_normal_tank1_life = 0;
    // public static float enemy_normal_tank2_life = 0;
  
 
     
     public static float enemy_hero_strong = 0;
     public static float enemy_normal_tank1_strong = 0;
     public static float enemy_normal_tank2_strong = 0;
     
     public static float enemy_hero_star = 0;
     public static float enemy_normal_tank1_star = 0;
     public static float enemy_normal_tank2_star = 0;
     
     public static float enemy_hero_direction = 0;
     public static float enemy_normal_tank1_direction = 0;
     public static float enemy_normal_tank2_direction = 0;
     
     public static float enemy_hero_skill = -1;//���ܴ���
     public static float enemy_tank1_skill = -1;
     public static float enemy_tank2_skill = -1;
     //����λ��
     public static float fri_landmine_position_x = -10 ;
     public static float fri_landmine_position_y = -10 ;//Ӣ�۷ŵ�
     
     
    // public static float landmine_width = 0 ;
    // public static float landmine_height = 0 ;
     
     public static float enemy_landmine_position_x = -10 ;
     public static float enemy_landmine_position_y = -10 ;//�о�Ӣ�۷ŵ�
     
     
     public static boolean fri_landmine_eated = false;//�ж��з����ҵ��ǲ��Ǳ��Ե���
     public static boolean ene_landmine_eated  = false;
     //�������λ��
     public static float reward_position_x = 0 ;
     public static float reward_position_y = 0 ;
     public static float reward = -1 ;//�жϽ�����ʲô������
     public static boolean reward_eated = false;
     
     
     
     //�鿴�Է��ǲ����ͷ���ȫ��ɱ���� ���� ����true
     public static boolean ene_get_bomb = false;
     public static boolean fri_get_bomb = false;
     //��������ǲ��Ǳ��ӵ����С������к󡣡��ӵ���ʧ
     public static boolean fri_hero_hurted = false;
     public static boolean fri_tank1_hurted = false;
     public static boolean fri_tank2_hurted = false;
     public static boolean ene_hero_hurted = false;
     public static boolean ene_tank1_hurted = false;
     public static boolean ene_tank2_hurted = false;
     
     public static boolean stop_fri_tank = false;
     public static boolean stop_ene_tank = false;
     public static long  stop_begin_time1 = 0;
     public static long stop_begin_time2 = 0;
     
     public static boolean ene_hero_jian = false;
     public static boolean ene_tank1_jian = false;
     public static boolean ene_tank2_jian = false;
     public static boolean fri_hero_jian = false;
     public static boolean fri_tank1_jian = false;
     public static boolean fri_tank2_jian = false;
     
     public static boolean ene_hero_bullet1 = false;
     public static boolean ene_hero_bullet2 = false;
     public static boolean ene_tank1_bullet1 = false ;
     public static boolean ene_tank1_bullet2 = false;
     public static boolean ene_tank2_bullet1 = false;
     public static boolean ene_tank2_bullet2 = false ;
     
     public static boolean fri_hero_bullet1 = false;
     public static boolean fri_hero_bullet2 = false;
     public static boolean fri_tank1_bullet1 = false;
     public static boolean fri_tank1_bullet2= false;
     public static boolean fri_tank2_bullet1 = false;
     public static boolean fri_tank2_bullet2 = false;
     
     public static boolean fri_lose  = false;
     public static boolean ene_lose  = false;
     
     public static int fri_hero_kill = 0 ;
     public static int ene_hero_kill = 0 ;
     
     public static int fri_hero_life = 0;
     
     public static long set_boom_end , hiding_end , kill_all_end, stop_all_end,zheng_shi_end,fanshang_end,protect_end ;
     
     public static boolean done_loading = false;
	public static int normaltank_bir_position;
     //public static boolean can_loading = false;//�ڼ��ص��߳��������������⡣��ֻ�����������������¡���
     //�����Ƿ���
     //******************************************************************************************************************************
    //��������ֹͣ����tank  ���ؼ���tank��������
     public static boolean stop_union_fri(){
    	if(stop_fri_tank){
    		if(stop_begin_time1 == 0) stop_begin_time1 = Boundary.get_now_time();
    	    if(Boundary.get_now_time() - stop_begin_time1 == 8){
    	    	stop_begin_time1 = 0;
    	    	stop_fri_tank = false;
    	    	return false;//��ʱ����
    	    }
    	    return true;
    	}
    	return false;
    }
    public static boolean stop_union_ene(){
    	if(stop_ene_tank){
    		if(stop_begin_time2 == 0) stop_begin_time2 = Boundary.get_now_time();
    	    if(Boundary.get_now_time() - stop_begin_time2 == 8){
    	    	stop_begin_time2 = 0;
    	    	stop_ene_tank = false;
    	    	return false;//��ʱ����
    	    }
    	    return true;
    	}
    	return false;
    }

   //******************************************************************************************************************************
     public static InputStream get_inputstream(){
    	 if(in == null){
    		 
    		 try {
				in = socket.getInputStream();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		 return in ;
    	 }
    	 
    	 return in ;
     }
     
     public static OutputStream get_outputstream(){
    	 
    	 if(out == null){
    		 try {
				out = socket.getOutputStream();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		 return out;
    	 }
    	 
    	 return out;
     }
     
     
     //******************************************************************************************************************************

   
     //******************************************************************************************************************************

     //�����Ϸ��ͼ�����λ��
     public static float get_game_map_left (){
    	 if(Operate_width != 0 ){
    		 return Operate_width;
    	 }
    	 System.out.println("����get����game����map_l�� -----------�д���");
    	 return 0 ;
     }
     
   
     //�����Ϸ�м��ͼ��
     public static float get_game_map_center (){
    	 if(Operate_width != 0 && Screen_X != 0 ){
    		 
    		 return (Screen_X-Operate_width)/2;
    	 }
    	 System.out.println("����get����game����map_c�� -----------�д���");
    	 return 0 ;
     }
     
     
     
     //�����Ϸ��ͼ���ұ߽߱�
     public static float get_game_map_right (){
    	 if(Operate_width != 0 && Screen_X != 0 ){
    		 
    		 return Screen_X;
    	 }
    	 System.out.println("����get����game����map_r�� -----------�д���");
    	 return 0 ;
     }
     
     
   //******************************************************************************************************************************
     
     //�����ʾӢ�۵������ȵ���Ϣ
    public static void GetDisplay(){
    	
    	if(Screen_X != 0&& Screen_Y != 0 ){
    		
    		 Display_width =(int) (Screen_X/8)*7;
    		 Display_height = (int)(Screen_Y/8);
    	}
    	else{
    		
    		System.out.println("��Ļ����");
    	}
       
    }
    
    //��õĲ������ĳ������Ϣ
    public static void GetOperate(){
    	
    	if(Screen_X != 0&&Screen_Y != 0 ){
    		Operate_width = (int)Screen_X/8;
    		Operate_height = (int)Screen_Y;
    		
    	}
    }
  //******************************************************************************************************************************
    //��ȡÿ��СͼƬ�Ŀ��
    public static float getlittlepicture_x(){
    	if(Screen_X != 0 ){
    		return (Screen_X-Operate_width)/map_width;
    	}
    	else{
    		System.out.println("��getlittlepicture_x   screen����x == 0");
    		return 0 ;
    	}
    }
    //��ȡÿ��СͼƬ�ĸ߶�
    public static float getlittlepicture_y(){
    	if(Screen_Y != 0 ){
    		return 	(Screen_Y-Display_height)/map_height;
    		
    	}
    	else{
    		System.out.println("��getlittlepicture_Y   screen����x == 0");
    		return 0 ;
    	}
    }
    
  //******************************************************************************************************************************
    
     //һ���ı�ͼƬ����ķ���   w ���µĿ�ȡ���h���µĸ߶�
 	public static Bitmap resizeImage(Bitmap bitmap, int w, int h) {
		
        Bitmap BitmapOrg = bitmap;
        int width = BitmapOrg.getWidth();
        int height = BitmapOrg.getHeight();
        int newWidth = w;
        int newHeight = h;
        float scaleWidth = ((float) newWidth) / width;
        float scaleHeight = ((float) newHeight) / height;
        Matrix matrix = new Matrix();
        matrix.postScale(scaleWidth, scaleHeight);
        Bitmap resizedBitmap = Bitmap.createBitmap(BitmapOrg,0, 0, width,height, matrix, true);
        return resizedBitmap;
    }
 	
	public static Bitmap resizeImage(Bitmap bitmap, float w, float h) {
			
	        Bitmap BitmapOrg = bitmap;
	        int width = BitmapOrg.getWidth();
	        int height = BitmapOrg.getHeight();
	        float newWidth = w;
	        float newHeight = h;
	        float scaleWidth = ( newWidth) / width;
	        float scaleHeight = (newHeight) / height;
	        Matrix matrix = new Matrix();
	        matrix.postScale(scaleWidth, scaleHeight);
	        Bitmap resizedBitmap = Bitmap.createBitmap(BitmapOrg,0, 0, width,height, matrix, true);
	        return resizedBitmap;
	    }
//******************************************************************************************************************************

//�ж����������Ƿ���ײ�����������Ͻǵĵ�Ϊ��׼
	public static boolean checkcrash(float x1,float y1,float w1 , float h1,
			                         float x2,float y2,float w2 , float h2){
				
		
		  if(
		    
			 x2>=x1 && x2<=x1+w1 && y2>=y1 && y2<=y1+h1||   //x2�����ϽǵĶ���
		     x2+w2 >= x1 && x2+w2<=x1+w1 && y2>=y1 && y2<=y1+h1|| //x2���Ͻǵĵ�
		     x2>=x1 && x2<=x1+w1 && y2 + h2 <= y1 + h1 && y2+h2>=y1||
		     x2+w2 >= x1 && x2+w2 <= x1+w1 && y2+h2 <= y1+ h1 && y2+h2 >= y1||
			 (
			 x1>=x2 && x1<=x2+w2 && y1>=y2 && y1<=y2+h2||   //x2�����ϽǵĶ���
			 x1+w1 >= x2 && x1+w1<=x2+w2 && y1>=y2 && y1<=y2+h2|| //x2���Ͻǵĵ�
			 x1>=x2 && x1<=x2+w2 && y1 + h1 <= y2 + h2 && y1+h1>=y2||
			 x1+w1 >= x2 && x1+w1 <= x2+w2 && y1+h1 <= y2+ h2 && y1+h1 >= y2
			 )
		    
		     //��ע�͵��ĵط��д���������Ŀǰ��֪����ô��ġ���
		     
			){//x2���½ǵĵ�
			  return true; //������������ײ
		  }
		  
		
		return false;//��������û����ײ
		
	}

	
	public static boolean checkcrash(int x1,int y1,int w1 , int h1,
			int x2,int y2,int w2 , int h2){
			
	  if(
			  x2>=x1 && x2<=x1+w1 && y2>=y1 && y2<=y1+h1||   //x2�����ϽǵĶ���
	          x2+w2 >= x1 && x2+w2<=x1+w1 && y2>=y1 && y2<=y1+h1|| //x2���Ͻǵĵ�
	          x2>=x1 && x2<=x1+w1 && y2 + h2 <= y1 + h1 && y2+h2>=y1||
	          x2+w2 >= x1 && x2+w2 <= x1+w1 && y2+h2 <= y1+ h1 && y2+h2 >= y1||
	          (
	          x1>=x2 && x1<=x2+w2 && y1>=y2 && y1<=y2+h2||   //x2�����ϽǵĶ���
	          x1+w1 >= x2 && x1+w1<=x2+w2 && y1>=y2 && y1<=y2+h2|| //x2���Ͻǵĵ�
	          x1>=x2 && x1<=x2+w2 && y1 + h1 <= y2 + h2 && y1+h1>=y2||
	          x1+w1 >= x2 && x1+w1 <= x2+w2 && y1+h1 <= y2+ h2 && y1+h1 >= y2
	          )
	    
		){//x2���½ǵĵ�
		  return true; //������������ײ
	  }
	  
	
	return false;//��������û����ײ
	}
//******************************************************************************************************************************
//�ж�һ�����Ƿ���ĳ����������
	public static boolean pointinarea(int px, int py ,int x,int y,int w,int h){
		if(px>=x && px<=x+w && py >= y &&py <= y+h){
			return true ;     //������������������
		}
		return false ;       //�����û���������������
	}

	public static boolean pointinarea(float px, float py ,float x,float y,float w,float h){
		if(px>=x && px<=x+w && py >= y &&py <= y+h){
			return true ;     //������������������
		}
		return false ;       //�����û���������������
	}
//******************************************************************************************************************************

	public static int Random(int xiaoyu){//�����������   С�ڡ�xiaoyu �� ����0 
		return (int)(Math.random()/0.0001)%xiaoyu;
		
	}

	public static int Random(float xiaoyu){//�����������   С�ڡ�xiaoyu �� ����0 
		return (int) ((int)(Math.random()/0.0001)%xiaoyu);
		
	}
	public static Bitmap shifang(Bitmap a){
		if (a != null && !a.isRecycled()) {/*a.recycle();*/a=null;} 
		return a ;
	}
	
	public static  Bitmap init_bitmap(initBimap_surfaceview a,int R_drawable){
		 Bitmap btp = null;
		 InputStream is = a.getResources().openRawResource(R_drawable);
	     BitmapFactory.Options options=new BitmapFactory.Options();
	     options.inJustDecodeBounds = false;
	     options.inSampleSize = 1;   //width��hight��Ϊԭ����3��һ
	     btp =BitmapFactory.decodeStream(is,null,options);
	     return btp;
	     
	}
}





















