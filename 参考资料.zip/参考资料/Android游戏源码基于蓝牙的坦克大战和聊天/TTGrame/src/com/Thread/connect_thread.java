package com.Thread;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.os.Message;

import com.tools.Constant;

import java.io.IOException;
import java.util.UUID;

public class connect_thread extends Thread {

	//private Context context = null ;
	private BluetoothAdapter bluetooth = null;
	private BluetoothDevice device = null;
	private BluetoothSocket socket = null;

	private Listener_bluetooth lis =null;
	private String address = null;
	private Handler handler = null;
//	private confirm_map map ;
	
	public connect_thread(String address,Handler handler){
		//this.context = context;
		this.address = address;
		this.handler = handler;
		 bluetooth = BluetoothAdapter.getDefaultAdapter();
		 device = bluetooth.getRemoteDevice(address.toString());
	}
	
	@Override
	public void run(){
		setName("connect_thread");
	//	System.out.println("����" +getName()+" id--  "+getId());
		 try {
			// lis = new Listener_bluetooth(context,handler);
			
			 device = bluetooth.getRemoteDevice(address.toString());
             socket = device.createInsecureRfcommSocketToServiceRecord(
            		 UUID.fromString("00000000-2527-eef3-ffff-ffffe3160865"));
                                   
             
         } catch (IOException e) {
            e.printStackTrace();
         }
		 
		 if(socket != null){
			 try {
				 System.out.println("����Ŭ����������");
				socket.connect();
				Constant.state = 1;
				Constant.C = true;
				Constant.socket = socket;
				//new chage_Info_thread_recive(socket.getInputStream()).start();
				//new chage_Info_thread_send(socket.getOutputStream()).start();
				Message msg = handler.obtainMessage();
				msg.what = 1 ;
				handler.sendMessage(msg);
				Constant.state = 1 ;
			
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("����û�����ϵ�");
				Message msg = handler.obtainMessage();//��������ʧ�ܵ���Ϣ
				msg.what = 2 ;
				handler.sendMessage(msg);//��������ʧ�ܵ���Ϣ
				try {
					socket.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Constant.state = 0 ;
				e.printStackTrace();
			}
		 }
	
	}
	
}















