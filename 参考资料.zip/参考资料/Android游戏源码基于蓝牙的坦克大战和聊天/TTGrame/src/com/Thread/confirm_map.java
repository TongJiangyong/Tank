package com.Thread;

import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.os.Message;

import com.tools.Constant;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class confirm_map extends Thread {
	
	private static BluetoothSocket socket = null;
	private static OutputStream out = null;
	private static InputStream in = null;
//	private Context context = null;
	private static boolean flag = true ;
	private Handler handler = null;
	
	public confirm_map(Handler handler){
		
		this.handler = handler;
		
			out = Constant.get_outputstream();
			in = Constant.get_inputstream();
		
	}
	@Override
	public void run(){
		setName("confirm_map");
		//System.out.println("����" +getName()+" id--  "+getId());
			byte get_Info[] = new byte[1];
			int bytes = 1;
			Message msg = null;
			int temp = 0 ;//��ʱ�����ͼ��Ϣ..���ж���Ϣ
			while(flag){
				
				try {
					
				    bytes = in.read(get_Info);
				    
				    
				    	
				    	 temp = (int)get_Info[0];//��һ�����־��ǵ�ͼ��Ϣ
						   
						    if(temp == 0 ||temp == 1||temp == 2){//������յ�����Ϣ����������ֹͣ
						    	System.out.println("���ڵ�ͼ��Ϣ������  :"+temp);
						    	Constant.whichMap = temp ;
						    	flag = false;
						    	
						    }
							msg = new Message();
							msg.arg1 = temp;
							msg.what = 1;
							handler.sendMessage(msg);
							
				    
				 
				   
				  
				   
				
					Thread.sleep(100);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}
	

	public static void  Write(byte bs){//���Լ��ĵ�ͼ��Ϣ�����Է�
		try {
		
			
			out.write(bs);
			out.flush();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public  static void stop_(){
			
				/*try {
					out.flush();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}*/
				flag = false;
			  
			  
			
		}
	
}






