package com.Thread;

import android.bluetooth.BluetoothSocket;

import com.entity.Deal_Bluetooth_Info;
import com.tools.Constant;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class chage_Info_thread_send extends Thread {

	private static BluetoothSocket socket = null;
	private static OutputStream out = null;
	private static InputStream in = null;
	private static boolean flag = false ;
	
	public chage_Info_thread_send(/*OutputStream out*/){
		//this.out = out;
			out = Constant.get_outputstream();
	}
	
	
	@Override
	public void run(){
		System.out.println("�����߳�����");
		setName("change_info_thread_send");
	//	System.out.println("����" +getName()+" id--  "+getId());
		int bytes = 1;
		byte[] send_info = null;
	    flag = true;
		while(flag){
			
			try {
				if((send_info=Deal_Bluetooth_Info.send_message() ) != null){
				    //�����Ϣ��㴫�͸��Է���������
					Write(send_info);
					
					send_info = null;
				}
				//������Ϣ
			   
				
			 Thread.sleep(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("�����ж��߳�");
				e.printStackTrace();
			}
			
		}
	}
	
	public static void  Write(byte b[]){//��̬�ˡ�
		try {
			out.write(b);
			out.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public  static void stop_(){
		flag = false;
		
		if(out != null){
			
				try {
				
				out.flush();
				out.close();
				if(socket != null){
					socket.close();
				}
				
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			
			}
		}
		
		
		
	}
	public static boolean getflag(){
		return flag ;
	}
}

























