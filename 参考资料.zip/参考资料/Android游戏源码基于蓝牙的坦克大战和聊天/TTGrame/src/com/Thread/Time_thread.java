package com.Thread;

public class Time_thread extends Thread {

	private static long time = 0 ; //ʱ��Ϊ��̬  ȫ�ֶ�����ʹ��
	private int apart_time ;//�����ʱ��   
	private static long now_time =0; //��¼��ǰ��ĳ��ʱ��
	private boolean flag = true ;
	
	@Override
	public void run(){
		setName("time_thread_go");
		//System.out.println("����" +getName()+" id--  "+getId());
		while(flag){
			
			++time;
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public static boolean calculate_time(int apart){
		
		if(now_time == 0 ){
			now_time = time;
		}
		
		if(time == now_time+apart){
			now_time = 0 ;
			return true;
		}
	    return false;
	}
	
	public static long get_time(){
		return time;
	}
	
	public void stop_(){
		flag  = false;
	}
}























