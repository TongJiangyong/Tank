package com.Thread;

import android.graphics.Canvas;
import android.os.Handler;
import android.os.Message;
import android.view.SurfaceHolder;

import com.SurfaceView.welcome_surfaceview;

public class change_welcome_alpha extends Thread {
    
	private SurfaceHolder holder ;
	private welcome_surfaceview welcome;
	private boolean flag = true;
	private int alpha ;
	private Handler handler;
	private Canvas c;
	private int time = 0 ;
	public change_welcome_alpha(SurfaceHolder holder,welcome_surfaceview welcome,Handler handler){
		
		this.holder = holder ; 
		this.welcome = welcome;
		this.handler = handler;
	}
	@Override
	public void run(){
		setName("change_welcome_alpha");
		//System.out.println("����" +getName()+" id--  "+getId());
		while(flag){
			++time;
			c = holder.lockCanvas();
			
			if(c != null){
				
			    welcome.onDraw(c);
				holder.unlockCanvasAndPost(c);
			}
			if(time >= 4){
				flag = false;
				Message msg  = new Message();
				msg.what = 1;
				handler.sendMessage(msg);
				break;
			}
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}
	
	public void stop_(){
		flag = false;
	}
}

















