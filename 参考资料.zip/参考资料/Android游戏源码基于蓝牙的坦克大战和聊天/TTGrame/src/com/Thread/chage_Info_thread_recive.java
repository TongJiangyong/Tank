package com.Thread;

import android.bluetooth.BluetoothSocket;

import com.entity.Deal_Bluetooth_Info;
import com.tools.Constant;

import java.io.IOException;
import java.io.InputStream;

public class chage_Info_thread_recive extends Thread {

	private static BluetoothSocket socket;
	private static InputStream in = null;
	private static boolean flag = false;
	public chage_Info_thread_recive(/*InputStream in*/){
		//this.in = in ;
		in = Constant.get_inputstream();
			
			
		
	}
	@Override
	public void run(){
		setName("change_info_thread_recive");
		flag = true;
		//System.out.println("����" +getName()+" id--  "+getId());
		byte[] get_info = new byte[45];
		while(flag){
			try{
				in.read(get_info);
				Deal_Bluetooth_Info.write_message(get_info);
				Thread.sleep(10);

			} catch (IOException e) {
				System.out.println("���ڶ�ȡ�̵߳�io�쳣��");
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public static void stop_(){
		flag = false;
		if(in != null){
			
			try {
				in.close();
				if(socket != null){
					socket.close();
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
	}
	
	public static boolean getflag(){
		return flag ;
	}
}












