package com.Thread;

import android.graphics.Canvas;
import android.view.SurfaceHolder;

import com.SurfaceView.PlayGame;

public class change_face extends Thread {
	
	private Canvas Viewcanvas;
    private PlayGame for_change ;
	private boolean flag = true ;
	private SurfaceHolder holder ;
	public change_face(PlayGame change,SurfaceHolder holder ){
		for_change = change ;
		this.holder = holder ;
	}
	
    @Override  
	public void run(){
    	
    	while(flag ){
    		if(for_change.can_start){
    			
	    		Viewcanvas = holder.lockCanvas();
	    		if(Viewcanvas != null){
	    				   
	    			for_change.onDraw(Viewcanvas);
	    	    	holder.unlockCanvasAndPost(Viewcanvas);

	    		}
	    		
	               
	    	    
	    		
	    			
	    	    
    		
    		}
    		try {
				Thread.sleep(20);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
	}
    
    public void stop_(){
    	flag = false;
    }
}
