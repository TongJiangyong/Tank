package com.Thread;

import com.entity.Tank;



public class Normal_tank_go extends Thread {
  
	private Tank no ;
	private boolean flag =true ;
	
	public Normal_tank_go(Tank no){
		if(no != null){
			this.no = no ;	
		}
		

	}
	@Override
	public void run(){
		setName("normal_tank_go");
		//System.out.println("����" +getName()+" id--  "+getId());
		while(flag){
			
			if(no.get_x() == 0){
				
			}
			
			else {
				no.go();
			}
			
			try {
				Thread.sleep(20);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	public void stop_(){
		flag = false; 
	}
}
