package com.Thread;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.os.Message;

import com.tools.Constant;

import java.io.IOException;
import java.util.UUID;

public class Listener_bluetooth extends Thread {

	private BluetoothAdapter bluetooth = BluetoothAdapter.getDefaultAdapter();
	private static boolean flag = false;
    private static BluetoothServerSocket serverSocket = null;
	private  static BluetoothSocket socket = null;	

//	private confirm_map map ;
	//private Context context = null;
	private Handler handler = null;
	private Class<?> btClass = null;
	
	public Listener_bluetooth(Handler handler) throws IOException{
		serverSocket = bluetooth.listenUsingRfcommWithServiceRecord("btspp", 
				UUID.fromString("00000000-2527-eef3-ffff-ffffe3160865"));
		this.handler = handler ;
	}
		
	
	@Override
	public void run(){
		setName("listener_bluetooth");
	//	System.out.println("����" +getName()+" id--  "+getId());
		flag = true;
		while(Constant.state == 0 && flag){//δ����
			try {
					System.out.println("���ڼ�����");
				socket = serverSocket.accept();
			    
				if(socket != null){
					//��ʼ���ݽ������߳�
					Constant.socket = socket;
					//new chage_Info_thread_recive(socket.getInputStream()).start();
					//new chage_Info_thread_send(socket.getOutputStream()).start();
					Constant.state = 1 ;
					Constant.S = true;
					Message msg = handler.obtainMessage();
					msg.what = 1;
					handler.sendMessage(msg);
				}
				Thread.sleep(100);
			} catch (IOException e){
				System.out.println("����ws����listener�����쳣");
				try {
					serverSocket.close();
				} catch (IOException e1) {
				
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				// TODO Auto-generated catch block
				e.printStackTrace();
				break;
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	public static void stop_(){
		/*if(serverSocket != null){
			try {
				serverSocket.close();
				
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}*/
		if(socket != null){
			try {
				socket.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		flag = false;
	}
	public static boolean getflag(){
		return flag ;
	}
}
