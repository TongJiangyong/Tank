package com.Thread;

import com.entity.Bullet;

public class Bullet_go extends Thread {
    private Bullet bullet ;
	private boolean flag = true;
	public Bullet_go(Bullet bullet){
		this.bullet = bullet;
	}
	
	@Override
	public void run(){
		setName("bullet����go");
		//System.out.println("����" +getName()+" id--  "+getId());
		while(flag){
			if(bullet.can_shoot_h == 1){
					if(bullet.get_x1() == 0 ){
					;
				   }
				   
				   else{
					bullet.go();
				   }
			}
			else{
				if(bullet.get_x1() == 0||bullet.get_x2() == 0 ){
					;
				}
				
				else{
					bullet.go();
				}
			}
			
			
			try {
				Thread.sleep(20);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
	public void stop_(){
		flag  = false ;
	}
}
