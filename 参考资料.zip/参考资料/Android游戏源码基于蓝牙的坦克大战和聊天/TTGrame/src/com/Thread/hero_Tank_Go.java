package com.Thread;

import com.entity.Tank;

public class hero_Tank_Go extends Thread {
    
	private Tank tank ; 
	private boolean flag = true ;
	
	//***********************************************************************************************************************8
	public hero_Tank_Go(Tank tank){
		this.tank = tank ;
	}
	
	@Override
	public void run(){
		setName("hero_tank_go");
		//System.out.println("����" +getName()+" id--  "+getId());
		while(flag){
			if(tank.get_x() == 0 ){
				
			}
			
			else {
				tank.go();
			}
		    
		    try {
				Thread.sleep(20);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void stop_(){
		flag = false;
	}
}
