package com.Thread;

import android.bluetooth.BluetoothSocket;

import com.entity.Deal_Bluetooth_Info;
import com.tools.Constant;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class chage_Info_thread extends Thread {

	private static BluetoothSocket socket = null;
	private static OutputStream out = null;
	private static InputStream in = null;
	private static boolean flag = true ;
	
	public chage_Info_thread(){
		this.socket = Constant.socket;//���������������Ѿ����Ӻ���
		try {
			out = socket.getOutputStream();
			in = socket.getInputStream();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	@Override
	public void run(){
		
		
		byte get_Info[] = new byte[2048];
		int bytes = 1;
	
		while(flag){
			
			try {
				Write(Deal_Bluetooth_Info.send_message());//������Ϣ
			    bytes =  in.read(get_Info);
			    Deal_Bluetooth_Info.write_message(get_Info);//����Ϣ����������
				Thread.sleep(20);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("�����쳣�С����������е��쳣����555555555555555555555555555");
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("�����ж��߳�");
				e.printStackTrace();
			}
			
		}
	}
	
	public static void  Write(byte b[]){//��̬�ˡ�
		try {
			out.write(b);
			out.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public  static void stop_(){
		
		try {
			out.flush();
			out.close();
			in.close();
			socket.close();
			flag = false;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		}
		
		
	}
	public static boolean getflag(){
		return flag ;
	}
}

























