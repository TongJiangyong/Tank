package com.ACTIVITY;


import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import com.Thread.Listener_bluetooth;
import com.Thread.connect_thread;
import com.example.my_firstgame.Ad;
import com.example.my_firstgame.R;
import com.tools.Constant;

import java.io.IOException;

public class menu extends Activity {

	
	private Button double_peo,chares,exit,helpes;
	private BluetoothDevice device= null;
	private BluetoothAdapter bluetoothadpter=null;
	private connect_thread for_connect = null;
	private Listener_bluetooth Listener_server = null;
	
	private boolean connecting = false;
	
	public void onCreate(Bundle ow){
		super.onCreate(ow);
		requestWindowFeature(Window.FEATURE_NO_TITLE); //û�б���
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);//������Ļ
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);//����
		
		DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm); 
        Constant.GetDisplay();//�������ʾ���ĸߺͿ�
	    Constant.GetOperate();//��ʾ�������ĸߺͿ�
	    
		setContentView(R.layout.choise);
		
		double_peo=(Button)findViewById(R.id.double_);
		helpes=(Button)findViewById(R.id.httpes);
		chares=(Button)findViewById(R.id.help);
		exit=(Button)findViewById(R.id.exit);
		
		bluetoothadpter = BluetoothAdapter.getDefaultAdapter();
		
		
		if(!bluetoothadpter.isEnabled()){
			Toast.makeText(getApplicationContext(), "�˳����Ĭ�ϴ��������", 1000).show();
		//	bluetoothadpter.enable();
		}
		
		
		
	
		
		
		
		
		double_peo.setOnClickListener(new OnClickListener(){//˫�˶�ս��ʼ��Ϸ

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
			if(Constant.state != 1){
				
					if(bluetoothadpter.getState() == bluetoothadpter.STATE_ON){
				        Intent intent = new Intent(menu.this,ListDevice.class);
				        startActivityForResult(intent,1);   
					}
					else{
						Toast.makeText(getApplicationContext(), "�ȴ���������...", 1000).show();
					}
					Toast.makeText(getApplicationContext(), "������������", 1000).show();
					
			}
				else{
					Intent intent = new Intent(menu.this,choisemap_.class);
					startActivity(intent);
			}
			}
			
		});
		
		helpes.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(menu.this,help.class);
				startActivity(intent);
			}
			
		});
	
		
		chares.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(menu.this,Ad.class);
				startActivity(intent);
			}
			
		});
		
		exit.setOnClickListener(new OnClickListener(){
      //�˳����򡣡��˳�һ�г���	
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Listener_server.stop_();
				if(Constant.socket != null){
					try {
						Constant.socket.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				//�˳�����ķ�ʽ
				Intent intent = new Intent(Intent.ACTION_MAIN);  
	            intent.addCategory(Intent.CATEGORY_HOME);  
	            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);  
	            startActivity(intent);  
	            android.os.Process.killProcess(android.os.Process.myPid());  
			//��ѯ�˳���Ϸ����
			}
			
		});
		
		
	
	
	
	}
	//***********************************************************************************************************************
	
	//************************************************************************************************************************
	@Override
	public void onStart(){
		super.onStart();
		try {
			if(bluetoothadpter.getState() == bluetoothadpter.STATE_ON){
				
				Listener_server = new Listener_bluetooth(mhanlder);
			    Listener_server.start();
			   
			}
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} 
	//************************************************************************************************************************

	private Handler mhanlder = new Handler(){
		    @Override
		    public void handleMessage(Message msg){
		        switch(msg.what){
		        case 1:
		        	Toast.makeText(getApplicationContext(), "����������", 1000).show();
		        	connecting = false;//���������
		        	break;
		        case 2:
		        	Toast.makeText(getApplicationContext(), "��������ʧ��", 1000).show();
		        	connecting = false;//����ʧ��
		        	break;
		        
		        }
		    }
		};
		
		//************************************************************************************************************************

		@Override
		protected void onActivityResult(int requestCode, int resultCode, Intent data){
			super.onActivityResult(requestCode, resultCode, data);
		    
			switch(requestCode){
			case 1:
				if(resultCode==RESULT_OK){
					connecting = true;//��ʾ��������
					Uri address = data.getData();
					System.out.println("��ws���Ǹ�Զ���豸�ĵ�ַ"+address.toString());
					for_connect = new connect_thread(address.toString(),mhanlder);
					for_connect.start();
				}
				else{
					
				}
				break;
			}
			
		}
		
		
		 @Override
		  public boolean onKeyDown(int keyCode, KeyEvent event) {   
		        //�ڻ�ӭ��������BACK��   
		        if(keyCode==KeyEvent.KEYCODE_BACK) {
		        	Listener_server.stop_();
					if(Constant.socket != null){
						try {
							Constant.socket.close();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					//�˳�����ķ�ʽ
					Intent intent = new Intent(Intent.ACTION_MAIN);  
		            intent.addCategory(Intent.CATEGORY_HOME);  
		            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);  
		            startActivity(intent);  
		            android.os.Process.killProcess(android.os.Process.myPid());  
		        }
		        
				return true;
				
		 }
}

























