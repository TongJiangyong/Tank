package com.ACTIVITY;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

import com.SurfaceView.choisemap;
import com.Thread.confirm_map;
import com.example.my_firstgame.R;
import com.tools.Constant;

//����ѡ���ͼ

/**
 * ��ͼѡ��������ϰѵ�ͼ����Ϣ��������һ���� 
 * ��ȫ������
 * ��������˵�������Ѿ����Ӻ���
 * @author Administrator
 *
 */
public class choisemap_ extends Activity {

	private Button first,second,third;
	
	private confirm_map map_ ;
	
	   @Override
	   public void onCreate(Bundle ow){
		   super.onCreate(ow);
		   
		   requestWindowFeature(Window.FEATURE_NO_TITLE); 
		   getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);//������Ļ
		   setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		   setContentView(R.layout.choisemap);
		   first = (Button)findViewById(R.id.first);
		   second = (Button)findViewById(R.id.second);
		   third = (Button)findViewById(R.id.third);
		   
		  map_  = new confirm_map(handler);
	      //screen = new confirm_screen(handler);
		  
		   
		   first.setOnClickListener(new click(first));
		   second.setOnClickListener(new click(second));
		   third.setOnClickListener(new click(third));
	   
	   }
	   class click implements OnClickListener {
		  
			
			 View temp ;  
		    click(View button){
		     temp = button;
		    }
			   @Override
				public void onClick(View view) {
					// TODO Auto-generated method stub
					if(temp  == first){
						Constant.whichMap = 0 ;
					}
					else if(temp == second){
						Constant.whichMap = 1 ;
					}
					else if(temp == third){
						Constant.whichMap = 2 ;
					}
					map_.Write((byte)Constant.whichMap);
					System.out.println((Constant.whichMap+","+Constant.Screen_X+","+Constant.Screen_Y+","));
					 Intent intent = new Intent(choisemap_.this, MainActivity.class);
				     	startActivity(intent);
				}
	 }
	   
	   
	   @Override
	   public void onStart(){
		   super.onStart();
		 map_.start();
		
		 
	   }
	   
	   
	   

		@Override
		public void onDestroy(){
			super.onDestroy();
			map_.stop_();
			
		}
		
		
		private Handler handler = new Handler(){

			@Override
			 public void handleMessage(Message msg){
			     switch(msg.what){
			     case 1:
			     	 Intent intent = new Intent(choisemap_.this, MainActivity.class);
			     	startActivity(intent);

			     	break;
			     
			     	 
			     }
			 }

			};

}






























