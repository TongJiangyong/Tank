package com.ACTIVITY;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.my_firstgame.R;

import java.util.Set;

public class ListDevice extends Activity {

	private ListView ListOld = null;
	private ListView ListNew = null;
	private Button bu_scan = null;
	private Button bu_can_check= null;
	private BluetoothAdapter bluetoothadapter=null; 
	private ArrayAdapter<String> arraybluetoothdevice=null,NewAdapterdevice=null;
	
	 @Override
	 public void onCreate (Bundle wo){
		 super.onCreate(wo);
		 requestWindowFeature(Window.FEATURE_NO_TITLE);
		 setContentView(R.layout.list_device);
		
		 bu_can_check = (Button)findViewById(R.id.can_discovered);
		 ListOld = (ListView)findViewById(R.id.list_old_device);
		 ListNew = (ListView)findViewById(R.id.list_new_device);
		 bu_scan = (Button)findViewById(R.id.scan_bluetooth);
		 bluetoothadapter = BluetoothAdapter.getDefaultAdapter();
		 arraybluetoothdevice = new ArrayAdapter<String>(this,R.layout.device_name);
		 NewAdapterdevice = new ArrayAdapter<String>(this,R.layout.device_name);
		 
		 ListNew.setAdapter(NewAdapterdevice);
		 ListNew.setOnItemClickListener(mDeviceClickListener);
		 
		 Set<BluetoothDevice> OldBluetoothDevice = bluetoothadapter.getBondedDevices();//��ȡ����Ե������豸����
		 for (BluetoothDevice device : OldBluetoothDevice) {
			 arraybluetoothdevice.add(device.getName() + "\n"
						+ device.getAddress());
		 }
		 ListOld.setAdapter(arraybluetoothdevice);
		 ListOld.setOnItemClickListener(mDeviceClickListener);
			//*********************************************************************************************************************

		 //�����豸��ť
		 bu_scan.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				bluetoothadapter.startDiscovery();
				bu_scan.setVisibility(View.GONE);
			}
			 
		 });
			//*********************************************************************************************************************

		 //�����豸�ɱ�ɨ��
		 bu_can_check.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);  
				discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);  
				startActivity(discoverableIntent);   
				bu_can_check.setVisibility(View.GONE);
			
			}
			 
		 });
		 
		    IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
			this.registerReceiver(mReceiver, filter);
			
			filter = new IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
			this.registerReceiver(mReceiver, filter);
	 }
	 
		//*********************************************************************************************************************

	 private OnItemClickListener mDeviceClickListener = new OnItemClickListener() {
			public void onItemClick(AdapterView<?> av, View v, int arg2, long arg3) {
				bluetoothadapter.cancelDiscovery();// ȡ������
				// ��ȡ�豸��MAC��ַ
				bluetoothadapter.cancelDiscovery();
				String msg = ((TextView) v).getText().toString();
				String address = msg.substring(msg.length() - 17);
				
				
				Uri data = Uri.parse(address);
				Intent intent = new Intent(null,data);
				// �豸������˳�Activity
				setResult(Activity.RESULT_OK, intent);
				finish();
			}
		};
		//*********************************************************************************************************************
	private  BroadcastReceiver mReceiver = new BroadcastReceiver(){
         
			@Override
			public void onReceive(Context arg0, Intent arg1) {
				// TODO Auto-generated method stub
				
				String action = arg1.getAction();
				
				if(BluetoothDevice.ACTION_FOUND.equals(action)){
					
					BluetoothDevice device = arg1.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
					
					if (device.getBondState() != BluetoothDevice.BOND_BONDED) {
						NewAdapterdevice.add(device.getName() + "\n"
								+ device.getAddress());
					}
				}
				else if (action.equals(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)){
					
					if (NewAdapterdevice.getCount() == 0) {
						String noDevices ="û�в��ҵ�";
						NewAdapterdevice.add(noDevices);
					}
				}
				
			}
			
		};

		//ע������Ϣ������� onDestroyע����Ϣ   ******
		@Override
		public void onDestroy(){
			super.onDestroy();
			this.unregisterReceiver(mReceiver);  //һ��Ҫע�������¼�
			if(bluetoothadapter != null){
				bluetoothadapter.cancelDiscovery();
			}
		}
		
}






















