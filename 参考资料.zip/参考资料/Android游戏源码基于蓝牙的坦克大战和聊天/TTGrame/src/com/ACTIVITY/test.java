//package com.ACTIVITY;
//
//import com.example.my_firstgame.R;
//
//import android.app.Activity;
//import android.content.Intent;
//import android.content.pm.ActivityInfo;
//import android.os.Bundle;
//import android.view.View;
//import android.view.View.OnClickListener;
//import android.view.Window;
//import android.view.WindowManager;
//import android.widget.Button;
//
//public class test extends Activity{
//	private Button first,second;
//	@Override
//	public void onCreate(Bundle wo){
//		super.onCreate(wo);
//		  requestWindowFeature(Window.FEATURE_NO_TITLE); //û�б���
//		   getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);//������Ļ
//		   setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);//����
//		 
//	    setContentView(R.layout.choisemap);
//	    
//				Intent intent = new Intent(test.this,MainActivity.class);
//		        startActivity(intent);
//		
//	
//
//	}
//}
