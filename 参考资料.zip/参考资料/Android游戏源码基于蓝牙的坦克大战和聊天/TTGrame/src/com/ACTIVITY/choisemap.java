//package com.ACTIVITY;
//
//import com.Thread.chage_Info_thread_send;
//import com.Thread.confirm_map;
//import com.example.my_firstgame.R;
//import com.tools.Constant;
//
//import android.app.Activity;
//import android.content.Intent;
//import android.content.pm.ActivityInfo;
//import android.os.Bundle;
//import android.os.Handler;
//import android.os.Message;
//import android.view.View;
//import android.view.View.OnClickListener;
//import android.view.Window;
//import android.view.WindowManager;
//import android.widget.Button;
////����ѡ���ͼ
//import android.widget.Toast;
//
///**
// * ��ͼѡ��������ϰѵ�ͼ����Ϣ��������һ���� 
// * ��ȫ������
// * ��������˵�������Ѿ����Ӻ���
// * @author Administrator
// *
// */
//public class choisemap extends Activity {
//
//	private Button first,second;
//	private confirm_map map ;
//	
//	
//	   @Override
//	   public void onCreate(Bundle ow){
//		   super.onCreate(ow);
//		   
//		   requestWindowFeature(Window.FEATURE_NO_TITLE); //û�б���
//		   getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);//������Ļ
//		   setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);//����
//		   
//		   setContentView(R.layout.choisemap);
//		   first = (Button)findViewById(R.id.first);
//		   second = (Button)findViewById(R.id.second);
//		   
//		   //map  = new confirm_map(handler);
//		  // map.start();
//		   
//		   
//		   first.setOnClickListener(new OnClickListener(){
//
//				@Override
//				public void onClick(View arg0) {
//					// TODO Auto-generated method stub
//				
//						
//					   Constant.whichMap = 0;//ѡ��ĵ�һ��
//					 
//					//   map.Write((byte)Constant.whichMap);
//					 
//					   Intent intent = new Intent(choisemap.this,MainActivity.class);
//					   startActivity(intent);
//					   confirm_map.stop_();
//					
//				}
//				   
//			   });
//		   
//		   
//		   second.setOnClickListener(new OnClickListener(){
//
//				@Override
//				public void onClick(View arg0) {
//					// TODO Auto-generated method stub
//					
//						   Constant.whichMap = 1;//ѡ��ĵڶ���
//						//   map.Write((byte)Constant.whichMap);
//						   
//						   Intent intent = new Intent(choisemap.this,MainActivity.class);
//						   startActivity(intent);
//						   confirm_map.stop_();
//					
//				}
//				   
//			   });
//		   
//	   }
//	   private Handler handler = new Handler(){
//		   @Override
//		    public void handleMessage(Message msg){
//		        switch(msg.what){
//		        case 1:
//		        	
//		        	Intent intent = new Intent(choisemap.this, MainActivity.class);
//		        	startActivity(intent);
//		        	confirm_map.stop_();
//		        	break;
//		        
//		        }
//		    }
//		   
//	   };
//	   
//
//		@Override
//		public void onDestroy(){
//			super.onDestroy();
//			confirm_map.stop_();
//		}
//}
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
