package com.ACTIVITY;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.SurfaceView.choisemap;
import com.SurfaceView.initBimap_surfaceview;
import com.Thread.Bullet_go;
import com.Thread.Listener_bluetooth;
import com.Thread.Normal_tank_go;
import com.Thread.chage_Info_thread_recive;
import com.Thread.chage_Info_thread_send;
import com.Thread.hero_Tank_Go;
import com.entity.Boundary;
import com.entity.Bullet;
import com.entity.Deal_Bluetooth_Info;
import com.entity.Herotank;
import com.entity.NormalTank;
import com.entity.ene_normal_tank;
import com.entity.enemy_hero_tank;
import com.entity.jineng;
import com.entity.reward;
import com.tools.Constant;
/**

 * Ϊ�˽�������ͬ������
 * ����һ�η���˫����tank��λ�á������ͬ��ôλ�ý��ı䡣λ�ý��ԶԷ���λ��Ϊ׼�����Լ���λ�ò��ı�ֻ�ı�ط���λ��
 * @author Ws
 *
 */
public class MainActivity extends Activity {
   private long time =0;
   private PlayGame playgame;
   private choisemap map;
  static initBimap_surfaceview initbitmap_surfaceview ;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);			
	       
			requestWindowFeature(Window.FEATURE_NO_TITLE); 
			getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);//������Ļ
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
			
			DisplayMetrics dm = new DisplayMetrics();
	        getWindowManager().getDefaultDisplay().getMetrics(dm);  
		     Constant.GetDisplay();//��ʾ���ĸߺͿ�
		     Constant.GetOperate();//��ʾ�������ĸߺͿ�
		   
			 initbitmap_surfaceview = new initBimap_surfaceview(this);
			playgame = new PlayGame(this,handler);
			  setContentView(playgame);
	}
	
	 private Handler handler = new Handler(){
		  
		   @Override
		    public void handleMessage(Message msg){
		        switch(msg.what){
		        case 1:
		        	
		        	setContentView(playgame);
		        	break;
		        case 2:
		        	Intent intent = new Intent(Intent.ACTION_MAIN);  
		            intent.addCategory(Intent.CATEGORY_HOME);  
		            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);  
		            startActivity( intent);  
		            android.os.Process.killProcess(android.os.Process.myPid());
		       
		            break;
		        	 
		        }
		    }
		   
	   };
	   
	   @Override
		  public boolean onKeyDown(int keyCode, KeyEvent event) {   
		        //�ڻ�ӭ��������BACK��   
		        if(keyCode==KeyEvent.KEYCODE_BACK) {
		        	if( System.currentTimeMillis() - time < 2000){
		        		
		        	if(playgame.change != null){
		        		playgame.change.stop_();
		       		}
		        	if(playgame.change2 != null){
		        		playgame.change2.stop_();
		        	}
		       		if(playgame.tank1_thread !=null){
		       			playgame.tank1_thread.stop_();
		       		}
		       		if(playgame.tank2_thread != null){
		       			playgame.tank2_thread.stop_();
		       		}
		       		if(playgame.enemy_tank_go != null){
		       			playgame.enemy_tank_go.stop_();
		       		}
		       		if(playgame.hero_go_thread != null){
		       			playgame.hero_go_thread.stop_();
		       		}
		       		if(playgame.bullet_go_hero != null){
		       			playgame.bullet_go_hero.stop_();
		       		}
		       		if(playgame.bullet_go_normal1 != null){
		       			playgame.bullet_go_normal1.stop_();
		       		}
		       		if(playgame.bullet_go_normal2 != null){
		       			playgame.bullet_go_normal2.stop_();
		       		}
		       		if(playgame.enemy_tank_go != null){
		       			playgame.enemy_tank_go.stop_();
		       		}
		       		if(playgame.bullet_go_enemyhero != null){
		       			playgame.bullet_go_enemyhero.stop_();
		       		}
		       		
		       	    if(Listener_bluetooth.getflag()){//ֹͣ�߳�
		       			Listener_bluetooth.stop_();
		       		}
		       		if(chage_Info_thread_recive.getflag()){
		       			chage_Info_thread_recive.stop_();
		       			System.out.println("���ڽ�����Ϣ�߳���    �ұ�ͣ�����ס���");
		       		}
		       		
		       		if(chage_Info_thread_send.getflag()){
		       			System.out.println("���Ƿ�����Ϣ�߳�  �ұ�ͣ����");
		       			chage_Info_thread_send.stop_();
		       		}
		       		if(playgame.tank5_thread != null){
		       			playgame.tank5_thread.stop_();
		       		}
		       		if(playgame.tank6_thread != null){
		       			playgame.tank6_thread.stop_();
		       		}
		       		if(playgame.bullet_go_tank5 != null){
		       			playgame.bullet_go_tank5.stop_();
		       		}
		       		if(playgame.bullet_go_tank6 != null){
		       			playgame.bullet_go_tank6.stop_();
		       		}
		       		
		        		Message msg= new Message();
		        		msg.what = 2;
		        		handler.sendMessage(msg);
		        		
		        	}
		        	else{
		        			time = System.currentTimeMillis();
		        		Toast.makeText(getApplicationContext(), "�ٰ�һ���˳���Ϸ", 800).show();
		        	}
		        
		        			            return true;   
		        }   
		        return true;   
		    }   
		
		

}
/**
 * �ڲ���PlayGame������������������
 
 */
 class PlayGame extends SurfaceView implements SurfaceHolder.Callback {
	 
	private SurfaceHolder holder ;
	private Object o ;
    private Paint paint ;
 	Herotank  herotank = null;
 	hero_Tank_Go hero_go_thread = null;
	 NormalTank tank1 = null,tank2= null;
	change_face change ; 
	change_face2 change2;
	 reward reward_send ;
	 hero_Tank_Go enemy_tank_go;
	  enemy_hero_tank enemy_hero;
	  ene_normal_tank  ene_tank5,ene_tank6;
	//�ӵ��ߵ��̶߳���
	Bullet_go bullet_go_hero ;
	Bullet_go bullet_go_normal1;
	Bullet_go bullet_go_normal2;
	Bullet_go bullet_go_enemyhero;
	Bullet_go bullet_go_tank5;
	Bullet_go bullet_go_tank6;
	//�ӵ�����
	Bullet hero_bullet;
	Bullet normal_bullet1;
	Bullet normal_bullet2;
	Bullet enemy_hero_bullet;
	Bullet tank5_bullet;
	Bullet tank6_bullet;
	Normal_tank_go tank1_thread = null;
	Normal_tank_go tank2_thread = null;
	Normal_tank_go tank5_thread = null;
	Normal_tank_go tank6_thread = null;
	
	
	
	private float  getupx,getupy  ,getdownx ,getdowny,getmovex,getmovey;
	public boolean can_start = false;
	private int flag;
	private boolean flag_d = false,flag_u = false;;
   private boolean tank1_shoot , tank2_shoot ;
	 chage_Info_thread_send change_info;
	 chage_Info_thread_recive get_change_info;
	boolean My_loading = false;
  
    private com.entity.loading load = new com.entity.loading();	
	
	public PlayGame(Context context,Handler handler) {
		super(context);
		// TODO Auto-generated constructor stub
		//this.handler = handler;
		this.setFocusableInTouchMode(true);
		holder = this.getHolder();  
        holder.addCallback(this);
    	paint = new Paint();
        o = new Object();
	}

	@Override 
	public void onDraw(Canvas canvas){
		super.onDraw(canvas);

		
	
		if(!My_loading||!Constant.done_loading){
			
			load.Drawself( canvas , paint);

		}
		else if(Constant.fri_lose){
			paint.setTextSize(50);
			paint.setColor(Color.GREEN);
			canvas.drawText("Loser", Constant.Screen_X/2, Constant.Screen_Y/2, paint);
			paint.setTextSize(20);
			paint.setColor(Color.WHITE);
			canvas.drawText("˫�����ؼ��˳���Ϸ", Constant.Screen_X/2+10, Constant.Screen_Y/2+ Constant.Screen_Y/3, paint);
		}
		else if(Constant.ene_lose){
			paint.setTextSize(50);
			paint.setColor(Color.RED);
			canvas.drawText("Winner", Constant.Screen_X/2, Constant.Screen_Y/2, paint);
			paint.setTextSize(20);
			paint.setColor(Color.WHITE);
			canvas.drawText("˫�����ؼ��˳���Ϸ", Constant.Screen_X/2+10, Constant.Screen_Y/2+ Constant.Screen_Y/3, paint);
		}
		else{
			
					canvas.drawColor(Color.argb(255, 0, 0, 0));
					
					Boundary.DrawslefBelow(canvas,paint);
					jineng.DrawfriLandmine(canvas, paint);
				   
					jineng.Draw_ene_Landmine(canvas, paint);
					
					enemy_hero_bullet.Drawself(canvas, paint);
					hero_bullet.Drawself(canvas,paint);
					tank5_bullet.Drawself(canvas, paint);
					tank6_bullet.Drawself(canvas, paint);
					
					tank1.Drawself(canvas,paint);
					tank2.Drawself(canvas,paint);
					 herotank.Drawself(canvas, paint);
					//��Ļ����  �����ӵ�
						
						if(Constant.Random(150) == 0 && !normal_bullet1.flying){
							normal_bullet1.shoot();
							
							Deal_Bluetooth_Info.changed_tank1_shoot();
							normal_bullet1.Drawself(canvas, paint);			
					    }
					
					   else{//����Ѿ������ˡ����ͼ�������***************************
						normal_bullet1.Drawself(canvas, paint);	
					   }
					
						if(Constant.Random(175) == 0&& !normal_bullet2.flying){
							normal_bullet2.shoot();
							Deal_Bluetooth_Info.changed_tank2_shoot();
							normal_bullet2.Drawself(canvas, paint);			
							
					   }
						else{
							normal_bullet2.Drawself(canvas, paint);	
						}
			
					
					ene_tank5.Drawself(canvas, paint);
					
					
					ene_tank6.Drawself(canvas, paint);
					
					enemy_hero.Drawself(canvas, paint);
					
					
					Boundary.DrawselfAbove(canvas, paint);
					reward_send.Drawself(canvas, paint);
					reward_send.Draw_S(canvas, paint);
			}
	}
	
	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		// TODO Auto-generated method stub
		System.out.println(" ����surfacechange��");
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
	    System.out.println("����surfaceviewcreate��");
	    MainActivity.initbitmap_surfaceview.initBitmap();
	    
	   
		paint.setAntiAlias(true);
		paint.setColor(Color.WHITE);
		new loading_(this,holder).start();
	}

	//**************************************************************************************************************************************

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		System.out.println("����destroy��");
	}

		
//**************************************************************************************************************************************
	@Override
	public boolean onTouchEvent(MotionEvent event) {
       
        switch(event.getAction()){
		
		case MotionEvent.ACTION_DOWN:
			
			getdownx=event.getX();
			getdowny=event.getY();
		
			 flag_d = true;
			 flag_u = false;
			break;
		case MotionEvent.ACTION_UP:
			//Log.v("1", "action_up");
			
		    getupx=event.getX();
			getupy=event.getY();
			flag_u = true;
			flag = 0 ;
		    break;
			
		case MotionEvent.ACTION_MOVE:
			 flag ++;
			 getmovex=event.getX();
		     getmovey=event.getY();
		     
		     
		     if(getdownx <= Constant.Operate_width && getmovex <= Constant.Operate_width){//���������¼�
		    	 if(flag > 6){
		    		 
		    		 if(getmovey - getdowny >= 0 ){//���»���
			    		 if(Boundary.get_witch_button() == 1)Boundary.set_whitch_button(2);
			    	 }
			    	 else{
			    		 if(Boundary.get_witch_button() == 2)Boundary.set_whitch_button(1);
			    	 }
			    	 
		    	 }
		    	 
		    	  
		     }
		     
		     else{//��ߴ���Ļ���¼�
		    
		    		if(flag >=4){ 
						
						if(Math.abs(getmovex - getdownx) <= 4 &&  Math.abs(getmovey-getdownx )<= 4 ){

						}
						else{
						//��tank���򡰸ı��ʱ��ŷ���
							
							if(!Deal_Bluetooth_Info.is_herotank_go()) Deal_Bluetooth_Info.chaged_tank_go();//�����ұߵĴ���Ļ   tankû���˶��ٷ��ʹ���Ϣ
							
							if(Math.abs(getmovex-getdownx) > Math.abs(getmovey-getdowny)){//ˮƽλ�ƽϴ�  ���Ǻ�����¼�
								
								if(getmovex-getdownx>=0){//right
									if(( herotank.get_direction()) != 3)	//���if��ֻ֤�������õġ������ظ����͡���
										{
										 Deal_Bluetooth_Info.changed_tank_direction();//Ӣ��tank�˶�
										}
									if(!herotank.get_move()){
										Deal_Bluetooth_Info.chaged_tank_go();
										herotank.move();
									}
									
									herotank.setDirection(3);
									
									
									
								}
								else{//left
									if((herotank.get_direction()) != 2)
										{
										 Deal_Bluetooth_Info.changed_tank_direction();//Ӣ��tank�˶�
										}
									if(!herotank.get_move()){
										Deal_Bluetooth_Info.chaged_tank_go();
										herotank.move();
									}
									herotank.setDirection(2);
									
									
								}
						    }
						    else{
								
						    	if(getmovey-getdowny<=0){//top
						    		if(( herotank.get_direction()) != 0)	
						    			{
						    			 Deal_Bluetooth_Info.changed_tank_direction();//Ӣ��tank�˶�
						    			}
						    		if(!herotank.get_move()){
						    			Deal_Bluetooth_Info.chaged_tank_go();
										herotank.move();
									}
						    		herotank.setDirection(0);
						    		
						    		
									
								}
								else{
									if(( herotank.get_direction()) != 1)	
										{
										 Deal_Bluetooth_Info.changed_tank_direction();//Ӣ��tank�˶�
										}
									if(!herotank.get_move()){
										Deal_Bluetooth_Info.chaged_tank_go();
										herotank.move();
									}
									herotank.setDirection(1);
									
									
									 
								}
						    }
					}
						
				}
		    	
				
		     }
		     
		
		    flag_u = false ;
		    flag_d = false ;
		    break;
		}
		
		
		
		
		
		synchronized(o){
			try {
				o.wait(20);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		{
			deal_click(getdownx,getdowny,getupx,getupy);
			getupx = 0 ; 
			getupy = 0 ;
		}
			
		return true;
		
	}
	
	//**************************************************************************************************************************************
   
	private void deal_click(float downx , float downy,float upx , float upy){
		
		 
		
		if(downx < Constant.Operate_width && upx < Constant.Operate_width){// ������������¼�
			
			
						
				if(
						Constant.pointinarea(downx, downy, 0, Constant.Screen_Y-Boundary.Button_stop.getHeight(),
								Boundary.Button_stop.getWidth(),Boundary.Button_stop.getHeight())&&
						Constant.pointinarea(upx, upy, 0, Constant.Screen_Y-Boundary.Button_stop.getHeight(),
								Boundary.Button_stop.getWidth(),Boundary.Button_stop.getHeight())
				  )
				{
					if(Boundary.get_witch_button() == 1 ){
							herotank.stopmove();
							Deal_Bluetooth_Info.changed_tank_dongo();
					}
					else{
						
						if(Constant.fri_hero_kill >= 3 ){//ɱ�������˲��д˼���
							
							if(Constant.set_boom_end == 0){
								jineng.fri_hero_set_boom();
								Deal_Bluetooth_Info.change_set_landmine();
								Constant.set_boom_end = Boundary.get_now_time();
							}
							else if((Boundary.get_now_time() - Constant.set_boom_end ) >= 30){
								jineng.fri_hero_set_boom();
								Deal_Bluetooth_Info.change_set_landmine();
								Constant.set_boom_end = Boundary.get_now_time();
							}
							else {
								
						
									Boundary.get_warn(2);
								
								
								//����ʹ�øü���
							}
						}
						if(Constant.fri_hero_kill < 3){
							Boundary.get_warn(1);
						}
						
					}
					
		        }
				else if(
						Constant.pointinarea(downx,downy, 0, Constant.Screen_Y-Boundary.Button_stop.getHeight()*2,
								Boundary.Button_stop.getWidth(),Boundary.Button_stop.getHeight())&&
						Constant.pointinarea(upx,upy, 0, Constant.Screen_Y-Boundary.Button_stop.getHeight()*2,
								Boundary.Button_stop.getWidth(),Boundary.Button_stop.getHeight())
						){
					
								if(Boundary.get_witch_button() == 1 ){//�����ӵ�
									hero_bullet.shoot();
								
											Deal_Bluetooth_Info.changed_hero_shoot();
								}
							
								else{
									if(Constant.fri_hero_kill >= 3 ){
										if(Constant.kill_all_end == 0){
											Constant.stop_ene_tank = true;//ͣסȫ���з�tank
											Deal_Bluetooth_Info.change_stop_everone();
											Constant.kill_all_end = Boundary.get_now_time();
										}
										else if((Boundary.get_now_time() -Constant. kill_all_end) >= 40){
											Constant.stop_ene_tank = true;//ͣסȫ���з�tank
											Deal_Bluetooth_Info.change_stop_everone();
											Constant.kill_all_end = Boundary.get_now_time();
										}
										else {
											//����ʹ�øü���
											
											
												Boundary.get_warn(4);
											
										}
										
									}
									if(Constant.fri_hero_kill < 3){
										Boundary.get_warn(3);
									}
									
								}
								
				         }
				else if(
						Constant.pointinarea(downx, downy, 0, Constant.Screen_Y-Boundary.Button_stop.getHeight()*3,
								Boundary.Button_stop.getWidth(),Boundary.Button_stop.getHeight())&&
						Constant.pointinarea(upx, upy, 0, Constant.Screen_Y-Boundary.Button_stop.getHeight()*3,
								Boundary.Button_stop.getWidth(),Boundary.Button_stop.getHeight())
								
						){
							if(Boundary.get_witch_button() == 1 ){
								
								if(Constant.fri_hero_kill >= 2){
									if(Constant.fanshang_end == 0 ){
										herotank.i_m_fanshang();
										Deal_Bluetooth_Info.change_fanshang();
										Constant.fanshang_end = Boundary.get_now_time();
									}
									else if((Boundary.get_now_time() - Constant.fanshang_end ) >=20){
										herotank.i_m_fanshang();
										Deal_Bluetooth_Info.change_fanshang();
										Constant.fanshang_end = Boundary.get_now_time();
									}
									else {
										//����ʹ�øü���
										
										
											Boundary.get_warn(6);
										
									}
								}
								if(Constant.fri_hero_kill < 2){
									Boundary.get_warn(5);
								}
								
							}
							else{
								if(Constant.fri_hero_kill >= 5){
									
									if(Constant.kill_all_end== 0){
										Constant.fri_get_bomb = true;
										Deal_Bluetooth_Info.change_kill_all();
										Constant.kill_all_end = Boundary.get_now_time();
									}
									else if((Boundary.get_now_time() - Constant.kill_all_end ) >= 40){
										Constant.fri_get_bomb = true;
										Deal_Bluetooth_Info.change_kill_all();
										Constant.kill_all_end = Boundary.get_now_time();
									}
									else {
										//����ʹ�øü���
										
										
											Boundary.get_warn(8);
										
									}
								}
								else{
									Boundary.get_warn(7);
								}
								
							}
				         }
				else if(
						
						Constant.pointinarea(downx, downy, 0, Constant.Screen_Y-Boundary.Button_stop.getHeight()*4,
								Boundary.Button_stop.getWidth(),Boundary.Button_stop.getHeight())&&
						Constant.pointinarea(upx, upy, 0, Constant.Screen_Y-Boundary.Button_stop.getHeight()*4,
							    Boundary.Button_stop.getWidth(),Boundary.Button_stop.getHeight())
												
						){
								if(Boundary.get_witch_button() == 1 ){
									if(Constant.protect_end == 0 ){
										herotank.I_m_wudi();
										Deal_Bluetooth_Info.chang_wudi();
										Constant.protect_end  = Boundary.get_now_time();
									}
									else if((Boundary.get_now_time() - Constant.protect_end)>= 30){
										herotank.I_m_wudi();
										Deal_Bluetooth_Info.chang_wudi();
										Constant.protect_end  = Boundary.get_now_time();
									}
									else{
										//����ʹ�øü���
										Boundary.get_warn(9);
									}
									
								}
								else{
									//û�п��Ŵ˼���
									
								}
				         }
				else if(
						Constant.pointinarea(downx, downy, 0, 0,
								Boundary.Button_stop.getWidth(),Boundary.Button_stop.getHeight())&&
						Constant.pointinarea(upx, upy, 0, 0,
								Boundary.Button_stop.getWidth(),Boundary.Button_stop.getHeight())
								
						){
									if(Boundary.get_witch_button() == 1 ){
										if(Constant.hiding_end == 0){
											herotank.I_m_hiding();
											Deal_Bluetooth_Info.change_hiding();
											Constant.hiding_end = Boundary.get_now_time();
										}
										else if((Boundary.get_now_time() - Constant.hiding_end) >20){
											herotank.I_m_hiding();
											Deal_Bluetooth_Info.change_hiding();
											Constant.hiding_end = Boundary.get_now_time();
										}
										else{
											//
											Boundary.get_warn(10);
										}
										
										
									}
									else{
										if(Constant.zheng_shi_end ==0){
											jineng.set_zhengshi(true);//����Ч��
											Constant.zheng_shi_end = Boundary.get_now_time();
										}
										else if((Boundary.get_now_time() - Constant.zheng_shi_end) >= 30){
											jineng.set_zhengshi(true);//����Ч��
											Constant.zheng_shi_end = Boundary.get_now_time();
										}
										else {
											//����ʹ�øü���
											Boundary.get_warn(11);
										}
											
											
									}
				        }
			
				
		}
		else{//��ߵĴ���Ļ�ĵ���¼�
			   
			}
	
	}
	
}


class loading_ extends Thread{
	
	PlayGame playgame ;
	SurfaceHolder holder ;
	public loading_(PlayGame playgame,SurfaceHolder holder ){
		this.playgame = playgame;
		this.holder = holder;
	}
	@Override 
	public void run(){
		// MainActivity.initbitmap_surfaceview.initBitmap();//����ͼƬ

		  

		   
	    new chage_Info_thread_recive().start();
		new chage_Info_thread_send().start();

		//Deal_Bluetooth_Info.change_screen();
		
				Boundary.Boundary_();
				playgame.herotank = new Herotank(null);
				playgame.hero_go_thread = new hero_Tank_Go(playgame.herotank);
				playgame.hero_go_thread.start();
				playgame.tank1 = new NormalTank(1, null);//����1�Ǹ�̹�˱��
				playgame.tank1_thread = new Normal_tank_go(playgame.tank1);
				playgame.tank1_thread.start();
				playgame.tank2 = new NormalTank(2, null);
				playgame.tank2_thread = new Normal_tank_go(playgame.tank2);
				playgame.tank2_thread.start();
				playgame.hero_bullet = new Bullet(playgame.herotank, null);
				playgame.bullet_go_hero = new Bullet_go(playgame.hero_bullet);
				playgame.bullet_go_hero.start();
				playgame.normal_bullet1 = new Bullet(playgame.tank1, null);
				playgame.bullet_go_normal1 = new Bullet_go(playgame.normal_bullet1);
				playgame.bullet_go_normal1.start();
				playgame.normal_bullet2 = new Bullet(playgame.tank2, null);
				playgame.bullet_go_normal2 = new Bullet_go(playgame.normal_bullet2);
				playgame. bullet_go_normal2.start();
				playgame.reward_send = new reward();
				
				playgame.enemy_hero = new enemy_hero_tank();
				playgame.enemy_tank_go = new hero_Tank_Go(playgame.enemy_hero);
				playgame.enemy_tank_go.start();
				playgame.enemy_hero_bullet = new Bullet(playgame.enemy_hero, null);
				playgame.bullet_go_enemyhero = new Bullet_go(playgame.enemy_hero_bullet);
				playgame.bullet_go_enemyhero.start();
				
			    playgame.ene_tank5 = new ene_normal_tank(5);
		        playgame.tank5_thread =new Normal_tank_go(playgame.ene_tank5);
				playgame.tank5_thread.start();
				playgame.tank5_bullet = new Bullet(playgame.ene_tank5, null);
				playgame.bullet_go_tank5 = new Bullet_go(playgame.tank5_bullet);
				playgame.bullet_go_tank5.start();
				
				playgame.ene_tank6 = new ene_normal_tank(6);
				playgame.tank6_thread =new Normal_tank_go(playgame.ene_tank6);
				playgame.tank6_thread.start();
				playgame.tank6_bullet = new Bullet(playgame.ene_tank6, null);
				playgame.bullet_go_tank6 = new Bullet_go(playgame.tank6_bullet);
				playgame.bullet_go_tank6.start();
				
				jineng.jineng_();//��ʼ��������
				
				Deal_Bluetooth_Info.Deal_Bluetooth_Info_(playgame.herotank,playgame.tank1,playgame.tank2,playgame.enemy_hero,
						playgame.enemy_hero_bullet,playgame.tank5_bullet,playgame.tank6_bullet,playgame.ene_tank5,playgame.ene_tank6);
				 
				playgame.My_loading = true;
				
				
				playgame.change2 = new change_face2(playgame,holder);
				playgame.change2.start();

			    playgame.change = new change_face(playgame,holder);
			    playgame.change.start();
				
				
				playgame.can_start = true;
				
		
			
	  
			Deal_Bluetooth_Info.done_loading();
		
	}
}


 class change_face extends Thread {
		
		private Canvas Viewcanvas;
	    private PlayGame for_change ;
		private boolean flag = true ;
		private SurfaceHolder holder ;
		public change_face(PlayGame playGame,SurfaceHolder holder ){
			for_change = playGame ;
			this.holder = holder ;
		}
		
	    @Override  
		public void run(){
	    	setName("change_face");
	    
	    	while(flag ){
	    		 synchronized(for_change){
	    			 
	    			 if(for_change.can_start){
	 	    			try{
	 	    				
	 			    		Viewcanvas = holder.lockCanvas();

	 	    			}
	 	    			catch(Exception e){
	 	    				
	 	    				Viewcanvas = null;
	 	    				e.printStackTrace();
	 	    			}
	 		    		if(Viewcanvas != null){
	 		    				   
	 		    			for_change.onDraw(Viewcanvas);
	 		    	    	holder.unlockCanvasAndPost(Viewcanvas);

	 		    		}
	 		    	
	 	    		}
	    		 }
	    		
	    		
	    	}
		}
	    
	    public void stop_(){
	    	flag = false;
	    }
	}




 class change_face2 extends Thread {
		
		private Canvas Viewcanvas;
	    private PlayGame for_change ;
		private boolean flag = true ;
		private SurfaceHolder holder ;
		public change_face2(PlayGame playGame,SurfaceHolder holder ){
			for_change = playGame ;
			this.holder = holder ;
		}
		
	    @Override  
		public void run(){
	    	setName("change_face");
	    	
	    	while(flag ){
	    		synchronized(for_change){
	    			 
	    			 if(for_change.can_start){
	 	    			try{
	 	    				
	 			    		Viewcanvas = holder.lockCanvas();

	 	    			}
	 	    			catch(Exception e){
	 	    				
	 	    				Viewcanvas = null;
	 	    				e.printStackTrace();
	 	    			}
	 		    		if(Viewcanvas != null){
	 		    				   
	 		    			for_change.onDraw(Viewcanvas);
	 		    	    	holder.unlockCanvasAndPost(Viewcanvas);

	 		    		}
	 		    	
	 	    		}
	    		 }
	    		
	    	}
		}
	    
	    public void stop_(){
	    	flag = false;
	    }
	}







