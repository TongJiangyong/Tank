package com.ACTIVITY;


import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.widget.ImageView;

import com.SurfaceView.welcome_surfaceview;

public class welcome extends Activity/* implements AnimationListener*/{
  private ImageView iv;
  private Animation alphaAnimation = null;  
  private  welcome_surfaceview ws;
	@Override
	public void onCreate(Bundle ow){
		super.onCreate(ow);
	
		DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm); 
        
		requestWindowFeature(Window.FEATURE_NO_TITLE); //û�б���
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);//������Ļ
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);//����
		
		//Constant.Screen_X = dm.widthPixels;//��ȡ��Ļ�ֱ���
	   // Constant.Screen_Y = dm.heightPixels;
	    
	    ws = new welcome_surfaceview (this,mhanlder); 
		setContentView(ws);
	
	}
	
	
	private Handler mhanlder = new Handler(){
	    @Override
	    public void handleMessage(Message msg){
	        switch(msg.what){
	        case 1:
	        	Intent intent = new Intent(welcome.this,menu.class);
	        	startActivity(intent);
	        	break;
	        }
	    }
	};
	@Override
	  public boolean onKeyDown(int keyCode, KeyEvent event) {   
	        //�ڻ�ӭ��������BACK��   
	        if(keyCode==KeyEvent.KEYCODE_BACK) {   
	            return false;   
	        }   
	        return false;   
	    }   
}
	 
	 
	 
	 
	 
	 
	 
	 
	 
